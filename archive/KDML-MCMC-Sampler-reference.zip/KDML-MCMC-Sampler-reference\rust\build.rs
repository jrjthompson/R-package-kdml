use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

fn main() {
    println!("cargo:rustc-check-cfg=cfg(kdml_cuda)");
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rerun-if-changed=src/cuda/kdml_cuda.cu");
    // A previous CPU-only build must be invalidated when CUDA or the MSVC
    // toolchain later becomes available on the machine.
    println!("cargo:rerun-if-env-changed=CUDA_PATH");
    println!("cargo:rerun-if-env-changed=VCToolsInstallDir");
    println!("cargo:rerun-if-env-changed=VCINSTALLDIR");

    let Some(nvcc) = find_nvcc() else {
        println!("cargo:warning=nvcc not found; CUDA benchmark support disabled");
        return;
    };

    let out_dir = PathBuf::from(env::var_os("OUT_DIR").expect("OUT_DIR is set"));
    let out_lib = out_dir.join("kdml_cuda.lib");
    let source = Path::new("src").join("cuda").join("kdml_cuda.cu");

    let args = vec![
        "-lib".to_string(),
        "-O3".to_string(),
        "-std=c++17".to_string(),
        // CUDA 13.1 does not yet recognize the installed Visual Studio 18
        // toolset, although it is ABI-compatible with the supported MSVC
        // toolchain. nvcc otherwise stops before compiling the CUDA source.
        "-allow-unsupported-compiler".to_string(),
        "-Xcompiler".to_string(),
        "/MD".to_string(),
        source.display().to_string(),
        "-o".to_string(),
        out_lib.display().to_string(),
    ];

    let output = match run_nvcc(&nvcc, &args) {
        Ok(output) => output,
        Err(err) => {
            println!("cargo:warning=failed to run nvcc: {err}; CUDA benchmark support disabled");
            return;
        }
    };

    if !output.status.success() {
        println!("cargo:warning=nvcc failed; CUDA benchmark support disabled");
        for line in String::from_utf8_lossy(&output.stdout).lines() {
            println!("cargo:warning=nvcc stdout: {line}");
        }
        for line in String::from_utf8_lossy(&output.stderr).lines() {
            println!("cargo:warning=nvcc stderr: {line}");
        }
        return;
    }

    println!("cargo:rustc-cfg=kdml_cuda");
    println!("cargo:rustc-link-search=native={}", out_dir.display());
    println!("cargo:rustc-link-lib=static=kdml_cuda");
    if let Some(cuda_lib_dir) = find_cuda_lib_dir(&nvcc) {
        println!("cargo:rustc-link-search=native={}", cuda_lib_dir.display());
    }
    println!("cargo:rustc-link-lib=dylib=cudart");
}

fn run_nvcc(nvcc: &Path, args: &[String]) -> std::io::Result<std::process::Output> {
    if cfg!(windows) {
        if let Some(vcvars) = find_vcvars64() {
            let out_dir = PathBuf::from(env::var_os("OUT_DIR").expect("OUT_DIR is set"));
            let batch_path = out_dir.join("run_nvcc.bat");
            let mut script = format!(
                "@echo off\r\ncall {} >nul\r\nif errorlevel 1 exit /b %errorlevel%\r\n{}",
                quote_cmd(&vcvars),
                quote_cmd(nvcc)
            );
            for arg in args {
                script.push(' ');
                script.push_str(&quote_arg(arg));
            }
            script.push_str("\r\nexit /b %errorlevel%\r\n");
            fs::write(&batch_path, script)?;
            return Command::new("cmd").arg("/C").arg(&batch_path).output();
        }
    }

    Command::new(nvcc).args(args).output()
}

fn quote_cmd(path: &Path) -> String {
    quote_arg(&path.display().to_string())
}

fn quote_arg(arg: &str) -> String {
    format!("\"{}\"", arg.replace('"', "\\\""))
}

fn find_nvcc() -> Option<PathBuf> {
    if let Some(cuda_path) = env::var_os("CUDA_PATH") {
        let candidate = PathBuf::from(cuda_path).join("bin").join("nvcc.exe");
        if candidate.exists() {
            return Some(candidate);
        }
    }

    env::var_os("PATH").and_then(|path| {
        env::split_paths(&path)
            .map(|dir| dir.join("nvcc.exe"))
            .find(|candidate| candidate.exists())
    })
}

fn find_cuda_lib_dir(nvcc: &Path) -> Option<PathBuf> {
    if let Some(cuda_path) = env::var_os("CUDA_PATH") {
        let candidate = PathBuf::from(cuda_path).join("lib").join("x64");
        if candidate.exists() {
            return Some(candidate);
        }
    }

    nvcc.parent()
        .and_then(Path::parent)
        .map(|cuda_root| cuda_root.join("lib").join("x64"))
        .filter(|candidate| candidate.exists())
}

fn find_vcvars64() -> Option<PathBuf> {
    let known_locations = [
        r"C:\Program Files\Microsoft Visual Studio\2022\Preview\VC\Auxiliary\Build\vcvars64.bat",
        r"C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat",
        r"C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat",
        r"C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat",
    ];

    if let Some(candidate) = known_locations
        .iter()
        .map(PathBuf::from)
        .find(|candidate| candidate.exists())
    {
        return Some(candidate);
    }

    let vswhere =
        PathBuf::from(r"C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe");
    if vswhere.exists() {
        if let Ok(output) = Command::new(&vswhere)
            .args([
                "-latest",
                "-products",
                "*",
                "-requires",
                "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
                "-property",
                "installationPath",
            ])
            .output()
        {
            if output.status.success() {
                let root = String::from_utf8_lossy(&output.stdout).trim().to_string();
                if !root.is_empty() {
                    let candidate = PathBuf::from(root)
                        .join("VC")
                        .join("Auxiliary")
                        .join("Build")
                        .join("vcvars64.bat");
                    if candidate.exists() {
                        return Some(candidate);
                    }
                }
            }
        }
    }
    None
}
