#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(FALSE), value = TRUE)
this_file <- if (length(script_arg)) sub("^--file=", "", script_arg[[1]]) else
  file.path(getwd(), "tests", "kernel_parity.R")
root <- normalizePath(file.path(dirname(this_file), ".."), winslash = "/", mustWork = TRUE)
source(file.path(root, "R", "analysis.R"))
stopifnot(requireNamespace("kdml", quietly = TRUE))

continuous_names <- c(
  "c_gaussian", "c_epanechnikov", "c_uniform", "c_triangle", "c_biweight",
  "c_triweight", "c_tricube", "c_cosine", "c_logistic", "c_sigmoid", "c_silverman"
)
unordered_names <- c("u_aitken", "u_aitchisonaitken")
ordered_names <- c("o_wangvanryzin", "o_habbema", "o_aitken",
                   "o_aitchisonaitken", "o_liracine")

assert_equal <- function(actual, expected, label, tolerance = 1e-11) {
  error <- max(abs(actual - expected))
  if (!is.finite(error) || error > tolerance) {
    stop(label, " failed; maximum absolute error = ", format(error, digits = 16))
  }
}

for (distance_type in c("dkps", "dkss")) {
  package_distance <- getExportedValue("kdml", distance_type)
  continuous <- data.frame(x = c(-1.2, -0.25, 0, 0.6, 1.7))
  for (code in 0:10) {
    expected <- package_distance(continuous, bw = c(x = 0.8),
                                 cFUN = continuous_names[[code + 1L]],
                                 stan = FALSE)$distances
    actual <- kdml_distance(continuous, 0L, code, 0.8, distance_type,
                            standardize = FALSE)
    assert_equal(actual, expected, paste(distance_type, continuous_names[[code + 1L]]))
  }

  unordered <- data.frame(x = factor(c("a", "b", "c", "a", "b")))
  encoded <- data.frame(x = as.integer(unordered$x))
  for (code in 0:1) {
    expected <- package_distance(unordered, bw = c(x = 0.25),
                                 uFUN = unordered_names[[code + 1L]],
                                 stan = FALSE)$distances
    actual <- kdml_distance(encoded, 1L, code, 0.25, distance_type,
                            standardize = FALSE)
    assert_equal(actual, expected, paste(distance_type, unordered_names[[code + 1L]]))
  }

  # kdml 1.1.1 drops a one-column ordered data frame to an ordered vector
  # before calling data.matrix(), so use two columns to exercise the exported
  # kernel rather than that unrelated single-column package bug.
  ordered <- data.frame(x = ordered(c(1, 2, 4, 3, 1)),
                        y = ordered(c(2, 1, 3, 4, 2)))
  encoded <- data.frame(x = as.integer(ordered$x), y = as.integer(ordered$y))
  for (code in 0:4) {
    expected <- package_distance(ordered, bw = c(x = 0.4, y = 0.4),
                                 oFUN = ordered_names[[code + 1L]],
                                 stan = FALSE)$distances
    actual <- kdml_distance(encoded, c(2L, 2L), c(code, code), c(0.4, 0.4), distance_type,
                            standardize = FALSE)
    assert_equal(actual, expected, paste(distance_type, ordered_names[[code + 1L]]))
  }
}

cat("All DKPS/DKSS kernel parity checks passed.\n")
