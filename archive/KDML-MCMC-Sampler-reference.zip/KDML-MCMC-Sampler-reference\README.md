# KDML MCMC sampler

This repository contains one sampler: a featurewise Metropolis--Hastings
kernel-switch sampler with a separate random-walk bandwidth update. DKPS and
DKSS are fixed run configurations. A chain never switches between them.

The continuous, nominal, and ordinal kernel formulas match the exported
`kdml` 1.1.1 `dkps()` and `dkss()` distance functions. The same selected
distance type and kernels are used in the MCMC score and in downstream
clustering.

## Run the complete analysis

From the repository root:

```powershell
& "C:\Program Files\R\R-4.5.2\bin\Rscript.exe" main.R --install-missing
```

The default analysis runs the ten real datasets and four simulated datasets,
with four chains, 5,000 warmup sweeps, 5,000 retained draws, thinning by five,
and the beta grid `0.3,0.5,1,2,3,5`. It performs:

1. a whole-data beta-one comparison; and
2. a train/validation/test experiment in which beta and clustering method are
   selected by validation ARI and evaluated once on the untouched test split.

DKPS and DKSS are fitted and reported separately. No results copied from the
original paper are included.

Useful options:

```text
--analysis both|whole|validation
--datasets body,wine,iris,...
--simulations 1,2,3,4
--betas 0.3,0.5,1,2,3,5
--chains 4 --burn 5000 --kept 5000 --thin 5
--out results
--skip-build
--overwrite
--no-progress
--smoke
```

`--smoke` limits the run to Iris and Simulation 1 and uses very short chains.
It checks the workflow; its results are not suitable for inference.

## Output layout

New output is written only beneath `results/` (or the directory passed to
`--out`). Existing legacy files beneath `local/` are never read by `main.R`.

```text
results/
  all_method_results.csv
  real/<dataset>/
    whole_data_beta_1/
      mcmc/<dkps|dkss>/
      <dkps|dkss>/clustering/
      <dkps|dkss>/diagnostics/
      method_comparison.csv
    validation_selected/
      mcmc/<dkps|dkss>/beta_<value>/
      final/<dkps|dkss>/clustering/
      final/<dkps|dkss>/diagnostics/
      method_comparison.csv
  simulated/<dataset>/
    ...same layout...
```

The clustering folders contain assignments, confusion matrices, CA/ARI, and
before/after pairs plots. Diagnostic folders contain R-hat/ESS summaries,
score and log-target traces, featurewise trace/ACF/bandwidth plots, kernel
probabilities, and move-acceptance plots.

## Tests

```powershell
Set-Location rust
cargo test --lib
cargo check --bin kdml_sampler
Set-Location ..
& "C:\Program Files\R\R-4.5.2\bin\Rscript.exe" tests/kernel_parity.R
```

The unit tests include CPU--CUDA parity and checks for the package biweight,
Silverman, and Aitchison--Aitken definitions.

The `kdml` package is required only for `tests/kernel_parity.R`; `main.R` does
not call the original KDML estimator or import any of its analysis results.
