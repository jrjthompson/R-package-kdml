#!/usr/bin/env Rscript

# Complete KDML analysis entry point.
#
# Default run:
#   * ten real datasets and four simulated datasets;
#   * separate fixed DKPS and DKSS MH-switch samplers;
#   * a beta=1 whole-data analysis;
#   * validation selection of beta and clustering method, followed by one
#     evaluation on the untouched test partition;
#   * CSV results and PNG plots, with no Quarto/report dependency.

args <- commandArgs(trailingOnly = TRUE)
arg_value <- function(name, default = NULL) {
  hit <- match(name, args)
  if (is.na(hit)) return(default)
  if (hit == length(args)) stop("Missing value for ", name, call. = FALSE)
  args[[hit + 1L]]
}
has_flag <- function(name) name %in% args
csv_character <- function(x) trimws(strsplit(x, ",", fixed = TRUE)[[1]])
csv_numeric <- function(x) {
  out <- suppressWarnings(as.numeric(csv_character(x)))
  if (!length(out) || any(!is.finite(out))) stop("Expected finite comma-separated numbers: ", x)
  out
}

if (has_flag("--help") || has_flag("-h")) {
  cat(paste0(
    "Usage: Rscript main.R [options]\n\n",
    "Runs fixed DKPS and DKSS MH-switch fits on the ten real datasets and ",
    "four simulations. Each fit uses the same KDML distance for estimation ",
    "and clustering.\n\n",
    "Options:\n",
    "  --datasets <csv>       Real datasets, or none\n",
    "  --simulations <csv>    Simulation numbers 1,2,3,4\n",
    "  --analysis <mode>      both, whole, or validation\n",
    "  --betas <csv>          Validation beta grid\n",
    "  --chains <n>           Number of chains\n",
    "  --burn <n>             Warmup sweeps per chain\n",
    "  --kept <n>             Retained draws per chain\n",
    "  --thin <n>             Thinning interval\n",
    "  --simulation-n <n>     Observations per simulation\n",
    "  --seed <n>             Base random seed\n",
    "  --out <directory>      Output root (default: results)\n",
    "  --smoke                Tiny Iris/simulation-1 check\n",
    "  --overwrite            Recompute matching cached fits\n",
    "  --skip-build           Reuse an existing release binary\n",
    "  --no-progress          Hide MCMC progress bars\n",
    "  --install-missing      Install missing R packages\n"
  ))
  quit(save = "no", status = 0L)
}

script_arg <- grep("^--file=", commandArgs(FALSE), value = TRUE)
this_file <- if (length(script_arg)) sub("^--file=", "", script_arg[[1]]) else file.path(getwd(), "main.R")
repo_dir <- normalizePath(dirname(this_file), winslash = "/", mustWork = TRUE)
source(file.path(repo_dir, "R", "analysis.R"))

real_names <- c("body", "wine", "iris", "soybean_small", "soybean_large",
                "zoo", "breast", "vote", "auto", "credit")
requested_real <- csv_character(arg_value("--datasets", paste(real_names, collapse = ",")))
if (identical(requested_real, "none")) requested_real <- character()
unknown <- setdiff(requested_real, real_names)
if (length(unknown)) stop("Unknown real dataset(s): ", paste(unknown, collapse = ", "))
requested_simulations <- as.integer(csv_character(arg_value("--simulations", "1,2,3,4")))
if (length(requested_simulations) == 1L && is.na(requested_simulations)) requested_simulations <- integer()
if (any(!requested_simulations %in% 1:4)) stop("--simulations must contain values from 1 to 4.")

output_root <- normalizePath(arg_value("--out", file.path(repo_dir, "results")),
                             winslash = "/", mustWork = FALSE)
analysis_mode <- match.arg(arg_value("--analysis", "both"), c("both", "whole", "validation"))
beta_grid <- unique(csv_numeric(arg_value("--betas", "0.3,0.5,1,2,3,5")))
chains <- as.integer(arg_value("--chains", "4"))
burn <- as.integer(arg_value("--burn", "5000"))
kept <- as.integer(arg_value("--kept", "5000"))
thin <- as.integer(arg_value("--thin", "5"))
seed <- as.integer(arg_value("--seed", "20260721"))
simulation_n <- as.integer(arg_value("--simulation-n", "300"))
overwrite <- has_flag("--overwrite")
progress <- !has_flag("--no-progress")

if (has_flag("--smoke")) {
  requested_real <- intersect(requested_real, "iris")
  requested_simulations <- intersect(requested_simulations, 1L)
  beta_grid <- 1
  chains <- 2L; burn <- 25L; kept <- 25L; thin <- 1L; simulation_n <- 80L
}
if (any(beta_grid <= 0) || chains < 1L || burn < 0L || kept < 1L || thin < 1L) {
  stop("Invalid beta or MCMC run length.")
}

required <- c("cluster", "mvtnorm")
if (length(requested_real)) required <- c(required, "gclus", "ucimlrepo")
require_packages(unique(required), install = has_flag("--install-missing"))

rust_dir <- file.path(repo_dir, "rust")
executable <- file.path(rust_dir, "target", "release",
                        paste0("kdml_sampler", if (.Platform$OS.type == "windows") ".exe" else ""))
if (!has_flag("--skip-build") || !file.exists(executable)) {
  message("Building the fixed-distance MH-switch sampler.")
  old <- setwd(rust_dir)
  status <- system2("cargo", c("build", "--release", "--bin", "kdml_sampler"),
                    stdout = "", stderr = "")
  setwd(old)
  if (is.null(status)) status <- 0L
  if (status != 0L || !file.exists(executable)) stop("Rust sampler build failed.")
}

dir.create(output_root, recursive = TRUE, showWarnings = FALSE)
utils::write.csv(data.frame(
  analysis_mode = analysis_mode, beta_grid = paste(beta_grid, collapse = ";"),
  chains = chains, burn = burn, kept = kept, thin = thin, seed = seed,
  sampler = "mh-switch", kernel_definition = "kdml-1.1.1-exported-distance",
  stringsAsFactors = FALSE
), file.path(output_root, "analysis_config.csv"), row.names = FALSE, quote = FALSE)

load_real <- function() {
  if (!length(requested_real)) return(list())
  cache_path <- file.path(output_root, "real_dataset_cache.rds")
  cached <- if (file.exists(cache_path)) tryCatch(readRDS(cache_path), error = function(e) NULL) else NULL
  if (is.null(cached) || !all(requested_real %in% names(cached))) {
    environment <- new.env(parent = globalenv())
    environment$requested_datasets <- requested_real
    sys.source(file.path(repo_dir, "R", "study10_real_data_loader.R"), envir = environment)
    cached <- environment$load_datasets()
    saveRDS(cached, cache_path)
  }
  cached[requested_real]
}

load_simulated <- function() {
  if (!length(requested_simulations)) return(list())
  environment <- new.env(parent = globalenv())
  sys.source(file.path(repo_dir, "MixedTypeDatasets", "MixedTypeDatasets",
                       "MixedTypeSimulationData.R"), envir = environment)
  setNames(lapply(requested_simulations, function(simulation) {
    generated <- environment$genMixedData(simulation, numPTS = simulation_n,
                                           seed = seed + 10000L * simulation)
    list(data = generated$data, labels = factor(generated$yTRUE))
  }), paste0("simulation_", requested_simulations))
}

real_descriptions <- c(
  body = "Body measurements: 24 continuous anthropometric variables; classes are sex/gender.",
  wine = "Wine recognition: 13 continuous chemical measurements and three cultivars.",
  iris = "Iris flowers: four continuous measurements and three species.",
  soybean_small = "Soybean small: categorical symptoms with disease classes.",
  soybean_large = "Soybean large: categorical symptoms with disease classes.",
  zoo = "Zoo animals: primarily nominal attributes, ordered leg count, and animal classes.",
  breast = "Original breast cancer: nine ordered cytological scores and diagnostic classes.",
  vote = "Congressional voting records: nominal vote attributes and political party.",
  auto = "Auto MPG: continuous, nominal, and ordered vehicle attributes; MPG is dichotomized.",
  credit = "Australian credit approval: continuous and nominal applicant attributes.")
simulation_descriptions <- c(
  simulation_1 = "Simulation 1: two clusters with informative continuous, nominal, and ordered variables.",
  simulation_2 = "Simulation 2: Simulation 1 plus continuous and nominal noise variables.",
  simulation_3 = "Simulation 3: four nonlinear hyperbolic clusters with continuous and nominal variables.",
  simulation_4 = "Simulation 4: three mixed-type Gaussian clusters with noise variables.")

datasets <- c(
  lapply(load_real(), function(x) list(data = x$data, labels = factor(x$labels))),
  load_simulated()
)
descriptions <- c(real_descriptions, simulation_descriptions)
distance_types <- c("dkps", "dkss")
summary_rows <- list()

plot_beta_selection <- function(results, path, distance_type) {
  best <- do.call(rbind, lapply(split(results, results$beta), function(x) best_result(x)))
  best <- best[order(best$beta), ]
  safe_png(path, {
    graphics::plot(best$beta, best$ari, type = "b", pch = 19, log = "x",
                   ylim = range(c(0, best$ari), finite = TRUE),
                   xlab = expression(beta), ylab = "Best validation ARI",
                   main = paste(toupper(distance_type), "beta selection"))
    graphics::text(best$beta, best$ari, labels = best$method, pos = 3, cex = 0.7)
  }, width = 1400, height = 900)
}

analyze_dataset <- function(name, entry, kind, dataset_seed) {
  message("\n=== ", name, " ===")
  data <- as.data.frame(entry$data, check.names = FALSE)
  labels <- factor(entry$labels)
  encoded_result <- encode_dataset(data)
  encoded <- encoded_result$data
  attr(encoded, "type_codes") <- encoded_result$type_codes
  type_codes <- encoded_result$type_codes
  k <- nlevels(labels)
  dataset_dir <- file.path(output_root, kind, name)
  dir.create(dataset_dir, recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(data.frame(
    dataset = name, description = unname(descriptions[[name]]), n = nrow(data),
    p = ncol(data), clusters = k, continuous = sum(type_codes == 0L),
    nominal = sum(type_codes == 1L), ordered = sum(type_codes == 2L)
  ), file.path(dataset_dir, "dataset_info.csv"), row.names = FALSE)
  saveRDS(list(data = data, labels = labels, encoded = encoded, type_codes = type_codes),
          file.path(dataset_dir, "data.rds"))

  if (analysis_mode %in% c("both", "whole")) {
    whole_dir <- file.path(dataset_dir, "whole_data_beta_1")
    method_rows <- list()
    for (distance_type in distance_types) {
      fit_dir <- file.path(whole_dir, "mcmc", distance_type)
      run_sampler(executable, encoded, type_codes, fit_dir, distance_type, beta = 1,
                  chains, burn, kept, thin, dataset_seed + match(distance_type, distance_types),
                  overwrite, progress)
      map <- extract_map_state(fit_dir, names(encoded), type_codes)
      D <- kdml_distance(encoded, type_codes, map$kernel_codes, map$bandwidths, distance_type)
      candidates <- evaluate_distance_clusterers(D, labels)
      selected <- best_result(candidates)
      utils::write.csv(candidates, file.path(whole_dir, paste0(distance_type, "_clusterers.csv")),
                       row.names = FALSE)
      clustering <- evaluate_selected_fit(data, encoded, labels, seq_len(nrow(data)), map,
                                          distance_type, selected$method,
                                          file.path(whole_dir, distance_type, "clustering"),
                                          paste(name, "whole data"))
      write_diagnostics(fit_dir, file.path(whole_dir, distance_type, "diagnostics"),
                        names(encoded), type_codes)
      utils::write.csv(data.frame(feature = names(encoded), type_code = type_codes,
                                  kernel_code = map$kernel_codes, bandwidth = map$bandwidths),
                       file.path(whole_dir, distance_type, "map_state.csv"), row.names = FALSE)
      method_rows[[distance_type]] <- data.frame(
        dataset = name, experiment = "whole_data_beta_1",
        method = paste0("MCMC-", toupper(distance_type), " (", selected$method, ")"),
        distance_type = distance_type, beta = 1, clustering_method = selected$method,
        ca = clustering$metric$ca, ari = clustering$metric$ari,
        selection = "best clustering method selected on the evaluated whole data",
        stringsAsFactors = FALSE
      )
    }
    competitor <- select_and_evaluate_competitors(data, labels, seq_len(nrow(data)),
                                                   seq_len(nrow(data)), dataset_seed,
                                                   file.path(whole_dir, "competitors"))
    competitor_rows <- transform(competitor, dataset = name, experiment = "whole_data_beta_1",
                                 distance_type = NA_character_, beta = NA_real_,
                                 clustering_method = setting,
                                 selection = "tuning selected on the evaluated whole data")
    competitor_rows <- competitor_rows[, names(method_rows[[1]]), drop = FALSE]
    table <- rbind(do.call(rbind, method_rows), competitor_rows)
    utils::write.csv(table, file.path(whole_dir, "method_comparison.csv"), row.names = FALSE)
    summary_rows[[paste(name, "whole", sep = "::")]] <<- table
  }

  if (analysis_mode %in% c("both", "validation")) {
    split <- stratified_split(labels, seed = dataset_seed)
    validation_dir <- file.path(dataset_dir, "validation_selected")
    dir.create(validation_dir, recursive = TRUE, showWarnings = FALSE)
    utils::write.csv(data.frame(row = seq_len(nrow(data)), split = {
      x <- rep(NA_character_, nrow(data)); x[split$train] <- "train"
      x[split$validation] <- "validation"; x[split$test] <- "test"; x
    }), file.path(validation_dir, "split.csv"), row.names = FALSE)
    mcmc_test_rows <- list()
    for (distance_type in distance_types) {
      mode_results <- list()
      map_states <- list()
      fit_dirs <- list()
      for (beta in beta_grid) {
        beta_name <- paste0("beta_", gsub("\\.", "_", format(beta, scientific = FALSE)))
        fit_dir <- file.path(validation_dir, "mcmc", distance_type, beta_name)
        run_sampler(executable, encoded[split$train, , drop = FALSE], type_codes,
                    fit_dir, distance_type, beta, chains, burn, kept, thin,
                    dataset_seed + 100L * match(distance_type, distance_types) +
                      as.integer(round(1000 * beta)), overwrite, progress)
        map <- extract_map_state(fit_dir, names(encoded), type_codes)
        D_validation <- kdml_distance(encoded[split$validation, , drop = FALSE], type_codes,
                                      map$kernel_codes, map$bandwidths, distance_type)
        results <- evaluate_distance_clusterers(D_validation, labels[split$validation])
        results$beta <- beta
        results$distance_type <- distance_type
        mode_results[[beta_name]] <- results
        map_states[[beta_name]] <- map
        fit_dirs[[beta_name]] <- fit_dir
      }
      mode_results <- do.call(rbind, mode_results)
      rownames(mode_results) <- NULL
      utils::write.csv(mode_results,
                       file.path(validation_dir, paste0(distance_type, "_validation_results.csv")),
                       row.names = FALSE)
      plot_beta_selection(mode_results,
                          file.path(validation_dir, paste0(distance_type, "_beta_selection.png")),
                          distance_type)
      selected <- mode_results[order(-mode_results$ari, -mode_results$ca,
                                     mode_results$beta, mode_results$method), , drop = FALSE][1L, ]
      beta_name <- paste0("beta_", gsub("\\.", "_", format(selected$beta, scientific = FALSE)))
      map <- map_states[[beta_name]]
      fit_dir <- fit_dirs[[beta_name]]
      final_dir <- file.path(validation_dir, "final", distance_type)
      evaluation <- evaluate_selected_fit(data, encoded, labels, split$test, map,
                                          distance_type, selected$method,
                                          file.path(final_dir, "clustering"),
                                          paste(name, "held-out test"))
      write_diagnostics(fit_dir, file.path(final_dir, "diagnostics"),
                        names(encoded), type_codes)
      utils::write.csv(data.frame(
        distance_type = distance_type, selected_beta = selected$beta,
        selected_clustering_method = selected$method,
        validation_ca = selected$ca, validation_ari = selected$ari,
        test_ca = evaluation$metric$ca, test_ari = evaluation$metric$ari
      ), file.path(final_dir, "selected_configuration.csv"), row.names = FALSE)
      utils::write.csv(data.frame(feature = names(encoded), type_code = type_codes,
                                  kernel_code = map$kernel_codes, bandwidth = map$bandwidths),
                       file.path(final_dir, "map_state.csv"), row.names = FALSE)
      mcmc_test_rows[[distance_type]] <- data.frame(
        dataset = name, experiment = "validation_selected_test",
        method = paste0("MCMC-", toupper(distance_type), " (", selected$method, ")"),
        distance_type = distance_type, beta = selected$beta,
        clustering_method = selected$method, ca = evaluation$metric$ca,
        ari = evaluation$metric$ari,
        selection = "beta and clustering method selected by validation ARI; evaluated once on test",
        stringsAsFactors = FALSE
      )
    }
    competitors <- select_and_evaluate_competitors(data, labels, split$validation, split$test,
                                                    dataset_seed + 50000L,
                                                    file.path(validation_dir, "competitors"))
    competitor_rows <- transform(
      competitors, dataset = name, experiment = "validation_selected_test",
      distance_type = NA_character_, beta = NA_real_, clustering_method = setting,
      selection = "tuning selected by validation ARI; evaluated once on test"
    )
    competitor_rows <- competitor_rows[, names(mcmc_test_rows[[1]]), drop = FALSE]
    table <- rbind(do.call(rbind, mcmc_test_rows), competitor_rows)
    utils::write.csv(table, file.path(validation_dir, "method_comparison.csv"), row.names = FALSE)
    summary_rows[[paste(name, "validation", sep = "::")]] <<- table
  }
  invisible(TRUE)
}

for (i in seq_along(datasets)) {
  name <- names(datasets)[[i]]
  kind <- if (name %in% real_names) "real" else "simulated"
  analyze_dataset(name, datasets[[i]], kind, seed + i * 100000L)
}

if (length(summary_rows)) {
  summary <- do.call(rbind, summary_rows)
  rownames(summary) <- NULL
  utils::write.csv(summary, file.path(output_root, "all_method_results.csv"), row.names = FALSE)
}
message("\nAnalysis complete. Results: ", output_root)
