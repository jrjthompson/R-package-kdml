use crate::{ColumnType, KdmlData, ScoreVersion};
use std::ffi::c_void;
use std::ptr;

type CudaWorkspace = c_void;

unsafe extern "C" {
    fn kdml_cuda_workspace_create(
        n: usize,
        p: usize,
        pair_count: usize,
        pair_diffs: *const f64,
        rows_a: *const usize,
        rows_b: *const usize,
        type_codes: *const i32,
        mins: *const f64,
        maxs: *const f64,
        out_workspace: *mut *mut CudaWorkspace,
    ) -> i32;

    fn kdml_cuda_workspace_destroy(workspace: *mut CudaWorkspace);

    #[cfg(any())]
    fn kdml_cuda_mscv_score_f32(
        workspace: *mut CudaWorkspace,
        bw: *const f32,
        score_version: i32,
        out_score: *mut f32,
    ) -> i32;

    #[allow(dead_code)]
    fn kdml_cuda_mscv_score_f32_with_kernels(
        workspace: *mut CudaWorkspace,
        bw: *const f32,
        distance_code: i32,
        ckernel_code: i32,
        ukernel_code: i32,
        okernel_code: i32,
        score_version: i32,
        out_score: *mut f32,
    ) -> i32;

    fn kdml_cuda_mscv_score_f32_with_column_kernels(
        workspace: *mut CudaWorkspace,
        bw: *const f32,
        distance_code: i32,
        ckernel_codes: *const i32,
        ukernel_codes: *const i32,
        okernel_codes: *const i32,
        score_version: i32,
        out_score: *mut f32,
    ) -> i32;
}

pub(crate) struct CudaMscvScore {
    workspace: *mut CudaWorkspace,
    score_version: ScoreVersion,
}

impl CudaMscvScore {
    #[cfg(any())]
    pub(crate) fn new(data: &KdmlData<'_>) -> Result<Self, String> {
        Self::new_with_score_version(data, ScoreVersion::Corrected)
    }

    pub(crate) fn new_with_score_version(
        data: &KdmlData<'_>,
        score_version: ScoreVersion,
    ) -> Result<Self, String> {
        let type_codes: Vec<i32> = data
            .types
            .iter()
            .map(|col_type| match col_type {
                ColumnType::Continuous => 0,
                ColumnType::Unordered => 1,
                ColumnType::Ordered => 2,
            })
            .collect();

        let mut workspace = ptr::null_mut();
        let status = unsafe {
            kdml_cuda_workspace_create(
                data.n,
                data.p,
                data.pair_count(),
                data.pair_diffs.as_ptr(),
                data.pair_rows_a.as_ptr(),
                data.pair_rows_b.as_ptr(),
                type_codes.as_ptr(),
                data.mins.as_ptr(),
                data.maxs.as_ptr(),
                &mut workspace,
            )
        };
        if status != 0 {
            return Err(format!(
                "CUDA workspace creation failed with status {status}"
            ));
        }
        if workspace.is_null() {
            return Err("CUDA workspace creation returned a null workspace".to_string());
        }

        Ok(Self {
            workspace,
            score_version,
        })
    }

    fn score_version_code(&self) -> i32 {
        match self.score_version {
            ScoreVersion::Legacy => 0,
            ScoreVersion::Corrected => 1,
        }
    }

    #[cfg(any())]
    pub(crate) fn score_f32(&self, bw: &[f32]) -> Result<f32, String> {
        let mut score = f32::NEG_INFINITY;
        let status = unsafe {
            kdml_cuda_mscv_score_f32(
                self.workspace,
                bw.as_ptr(),
                self.score_version_code(),
                &mut score,
            )
        };
        if status != 0 {
            return Err(format!("CUDA f32 score failed with status {status}"));
        }
        Ok(score)
    }

    #[allow(dead_code)]
    pub(crate) fn score_f32_with_kernels(
        &self,
        bw: &[f32],
        distance_code: i32,
        ckernel_code: i32,
        ukernel_code: i32,
        okernel_code: i32,
    ) -> Result<f32, String> {
        let mut score = f32::NEG_INFINITY;
        let status = unsafe {
            kdml_cuda_mscv_score_f32_with_kernels(
                self.workspace,
                bw.as_ptr(),
                distance_code,
                ckernel_code,
                ukernel_code,
                okernel_code,
                self.score_version_code(),
                &mut score,
            )
        };
        if status != 0 {
            return Err(format!(
                "CUDA f32 score failed with kernels ({distance_code}, {ckernel_code}, {ukernel_code}, {okernel_code}) and status {status}"
            ));
        }
        Ok(score)
    }

    pub(crate) fn score_f32_with_column_kernels(
        &self,
        bw: &[f32],
        distance_code: i32,
        ckernel_codes: &[i32],
        ukernel_codes: &[i32],
        okernel_codes: &[i32],
    ) -> Result<f32, String> {
        let mut score = f32::NEG_INFINITY;
        let status = unsafe {
            kdml_cuda_mscv_score_f32_with_column_kernels(
                self.workspace,
                bw.as_ptr(),
                distance_code,
                ckernel_codes.as_ptr(),
                ukernel_codes.as_ptr(),
                okernel_codes.as_ptr(),
                self.score_version_code(),
                &mut score,
            )
        };
        if status != 0 {
            return Err(format!(
                "CUDA f32 score failed with per-column kernels and status {status}"
            ));
        }
        Ok(score)
    }
}

impl Drop for CudaMscvScore {
    fn drop(&mut self) {
        unsafe {
            kdml_cuda_workspace_destroy(self.workspace);
        }
        self.workspace = ptr::null_mut();
    }
}
