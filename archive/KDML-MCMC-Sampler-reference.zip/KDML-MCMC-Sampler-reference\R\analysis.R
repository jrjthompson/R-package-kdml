# Analysis utilities for the fixed-distance KDML MH-switch sampler.
#
# The Rust sampler and this file deliberately use the kernels exported by
# kdml 1.1.1.  DKPS and DKSS are separate fits: the distance type selected for
# estimation is also used to construct the clustering dissimilarity.

slug <- function(x) gsub("[^a-z0-9]+", "_", tolower(x))

require_packages <- function(packages, install = FALSE) {
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing) && install) {
    repos <- getOption("repos")
    if (is.null(repos[["CRAN"]]) || !nzchar(repos[["CRAN"]]) || repos[["CRAN"]] == "@CRAN@") {
      repos[["CRAN"]] <- "https://cloud.r-project.org"
    }
    utils::install.packages(missing, repos = repos, dependencies = NA)
    missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  }
  if (length(missing)) {
    stop("Missing required R package(s): ", paste(missing, collapse = ", "),
         ". Re-run with --install-missing.", call. = FALSE)
  }
}

encode_dataset <- function(data) {
  encoded <- data
  type_codes <- integer(ncol(data))
  for (j in seq_along(data)) {
    x <- data[[j]]
    if (is.ordered(x)) {
      type_codes[[j]] <- 2L
      encoded[[j]] <- as.integer(x)
    } else if (is.factor(x) || is.character(x) || is.logical(x)) {
      type_codes[[j]] <- 1L
      encoded[[j]] <- as.integer(factor(x))
    } else {
      type_codes[[j]] <- 0L
      encoded[[j]] <- as.numeric(x)
    }
  }
  encoded <- as.data.frame(encoded, check.names = FALSE)
  if (is.null(names(encoded)) || any(!nzchar(names(encoded)))) {
    names(encoded) <- paste0("V", seq_len(ncol(encoded)))
  }
  names(encoded) <- make.unique(gsub("[^A-Za-z0-9_.]", "_", names(encoded)))
  if (any(!is.finite(as.matrix(encoded)))) stop("Encoded data contain non-finite values.")
  list(data = encoded, type_codes = type_codes)
}

stratified_split <- function(labels, train_frac = 0.60, validation_frac = 0.20, seed = 1L) {
  labels <- factor(labels)
  set.seed(seed)
  train <- validation <- test <- integer()
  for (level in levels(labels)) {
    idx <- sample(which(labels == level))
    n <- length(idx)
    if (n < 3L) stop("Every class needs at least three observations for train/validation/test.")
    n_train <- max(1L, floor(train_frac * n))
    n_validation <- max(1L, floor(validation_frac * n))
    if (n_train + n_validation >= n) n_train <- max(1L, n - n_validation - 1L)
    if (n_train + n_validation >= n) n_validation <- max(1L, n - n_train - 1L)
    train <- c(train, idx[seq_len(n_train)])
    validation <- c(validation, idx[n_train + seq_len(n_validation)])
    test <- c(test, idx[(n_train + n_validation + 1L):n])
  }
  list(train = sort(train), validation = sort(validation), test = sort(test))
}

write_sampler_input <- function(encoded, type_codes, directory) {
  dir.create(directory, recursive = TRUE, showWarnings = FALSE)
  data_path <- file.path(directory, "data.csv")
  types_path <- file.path(directory, "types.csv")
  utils::write.csv(encoded, data_path, row.names = FALSE, quote = FALSE)
  utils::write.csv(
    data.frame(column = names(encoded), type_code = type_codes),
    types_path, row.names = FALSE, quote = FALSE
  )
  list(data = data_path, types = types_path)
}

run_sampler <- function(executable, encoded, type_codes, output_dir, distance_type,
                        beta, chains, burn, kept, thin, seed, overwrite = FALSE,
                        progress = TRUE) {
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  prepared <- write_sampler_input(encoded, type_codes, file.path(output_dir, "input"))
  manifest_path <- file.path(output_dir, "run_config.csv")
  expected <- data.frame(
    sampler = "mh-switch", kernel_definition = "kdml-1.1.1-exported-distance",
    distance_type = distance_type, beta = beta, chains = chains, burn = burn,
    kept = kept, thin = thin, seed = seed, n = nrow(encoded), p = ncol(encoded),
    data_md5 = unname(tools::md5sum(prepared$data)),
    types_md5 = unname(tools::md5sum(prepared$types)),
    stringsAsFactors = FALSE
  )
  manifest_matches <- if (!file.exists(manifest_path)) FALSE else tryCatch({
    observed <- utils::read.csv(manifest_path, stringsAsFactors = FALSE,
                                check.names = FALSE)
    nrow(observed) == 1L && identical(names(observed), names(expected)) &&
      all(vapply(names(expected), function(field) {
        isTRUE(all.equal(observed[[field]][[1L]], expected[[field]][[1L]],
                         check.attributes = FALSE))
      }, logical(1)))
  }, error = function(e) FALSE)
  complete <- manifest_matches && all(vapply(seq_len(chains), function(chain) {
    directory <- if (chains == 1L) output_dir else file.path(output_dir, paste0("chain", chain))
    all(file.exists(file.path(directory, c("kept_trace.csv", "kernel_draws.csv",
                                           "bandwidth_draws.csv", "theta_draws.csv",
                                           "move_diagnostics.csv", "summary.csv"))))
  }, logical(1)))
  if (complete && !overwrite) return(invisible(output_dir))

  command_args <- c(
    "--data", prepared$data, "--types", prepared$types, "--out", output_dir,
    "--distance-type", distance_type, "--beta", format(beta, scientific = FALSE),
    "--chains", chains, "--burn", burn, "--kept", kept, "--thin", thin,
    "--seed", seed, "--proposal-sd", 0.15,
    if (progress) "--progress" else "--no-progress"
  )
  status <- system2(executable, command_args, stdout = "", stderr = "")
  if (is.null(status)) status <- 0L
  if (status != 0L) stop("Sampler failed with status ", status, " in ", output_dir)
  utils::write.csv(expected, manifest_path, row.names = FALSE, quote = FALSE)
  invisible(output_dir)
}

chain_directories <- function(fit_dir) {
  dirs <- list.dirs(fit_dir, recursive = FALSE, full.names = TRUE)
  dirs <- dirs[grepl("chain[0-9]+$", basename(dirs))]
  if (!length(dirs) && file.exists(file.path(fit_dir, "kept_trace.csv"))) dirs <- fit_dir
  dirs[order(as.integer(sub("chain", "", basename(dirs))))]
}

extract_map_state <- function(fit_dir, feature_names, type_codes) {
  dirs <- chain_directories(fit_dir)
  if (!length(dirs)) stop("No sampler chains found in ", fit_dir)
  candidates <- lapply(seq_along(dirs), function(chain) {
    trace <- read.csv(file.path(dirs[[chain]], "kept_trace.csv"), check.names = FALSE)
    row <- which.max(trace$log_post)
    data.frame(chain = chain, row = row, log_post = trace$log_post[[row]],
               score = trace$score[[row]])
  })
  candidates <- do.call(rbind, candidates)
  winner <- candidates[which.max(candidates$log_post), ]
  directory <- dirs[[winner$chain]]
  kernel <- read.csv(file.path(directory, "kernel_draws.csv"), check.names = FALSE)
  bandwidth <- read.csv(file.path(directory, "bandwidth_draws.csv"), check.names = FALSE)
  row <- winner$row
  codes <- integer(length(feature_names))
  for (j in seq_along(feature_names)) {
    prefix <- c("ckernel_", "ukernel_", "okernel_")[[type_codes[[j]] + 1L]]
    codes[[j]] <- kernel[[paste0(prefix, feature_names[[j]])]][[row]]
  }
  bw <- as.numeric(bandwidth[row, feature_names, drop = TRUE])
  names(bw) <- feature_names
  list(kernel_codes = codes, bandwidths = bw, chain = winner$chain,
       draw = row, score = winner$score, log_post = winner$log_post)
}

continuous_kernel <- function(diff, bandwidth, code, distance_type) {
  z <- diff / bandwidth
  a <- abs(z)
  scale <- if (distance_type == "dkps" || code == 10L) 1 / bandwidth else 1
  switch(as.character(code),
    "0" = scale * (2 * pi)^(-0.5) * exp(-z^2 / 2),
    "1" = scale * ifelse(a <= 1, 3 / 4 * (1 - z^2), 0),
    "2" = scale * ifelse(a <= 1, 1 / 2, 0),
    "3" = scale * ifelse(a <= 1, 1 - a, 0),
    "4" = scale * ifelse(a <= 1, 15 / 32 * (3 - z^2)^2, 0),
    "5" = scale * ifelse(a <= 1, 35 / 32 * (1 - z^2)^3, 0),
    "6" = scale * ifelse(a <= 1, 70 / 81 * (1 - abs(z)^3)^3, 0),
    "7" = scale * ifelse(a <= 1, pi / 4 * cos(pi * z / 2), 0),
    "8" = scale / (exp(z) + 2 + exp(-z)),
    "9" = scale * 2 / (pi * (exp(z) + exp(-z))),
    "10" = scale * 0.5 * exp(-a / sqrt(2)) * sin(a / sqrt(2) + pi / 4),
    stop("Unknown continuous kernel code: ", code)
  )
}

unordered_kernel <- function(same, bandwidth, code, level_count) {
  switch(as.character(code),
    "0" = ifelse(same, 1, bandwidth),
    "1" = ifelse(same, 1 - bandwidth, bandwidth / (level_count - 1)),
    stop("Unknown unordered kernel code: ", code)
  )
}

ordered_kernel <- function(diff, bandwidth, code, dkss_wang_all_same = NULL) {
  a <- abs(diff)
  switch(as.character(code),
    "0" = if (!is.null(dkss_wang_all_same)) {
      ifelse(dkss_wang_all_same, 1 - bandwidth,
             0.5 * (1 - bandwidth) * bandwidth^a)
    } else {
      ifelse(diff == 0, 1 - bandwidth, 0.5 * (1 - bandwidth) * bandwidth^a)
    },
    "1" = bandwidth^(a^2),
    "2" = ifelse(diff == 0, bandwidth, (1 - bandwidth) / 2^a),
    "3" = ifelse(diff == 0, 1, bandwidth^a),
    "4" = ifelse(diff == 0, 1, bandwidth^a),
    stop("Unknown ordered kernel code: ", code)
  )
}

kdml_distance <- function(encoded, type_codes, kernel_codes, bandwidths,
                          distance_type, standardize = TRUE) {
  stopifnot(distance_type %in% c("dkps", "dkss"))
  n <- nrow(encoded)
  D <- matrix(0, n, n)
  level_counts <- vapply(encoded, function(x) length(unique(x)), integer(1))
  for (i in seq_len(n - 1L)) {
    for (r in (i + 1L):n) {
      value <- 0
      ordered_columns <- which(type_codes == 2L)
      first_dkss_wang <- if (distance_type == "dkss")
        head(which(type_codes == 2L & kernel_codes == 0L), 1L) else integer()
      dkss_wang_all_same <- distance_type == "dkss" && length(ordered_columns) &&
        all(vapply(ordered_columns, function(j) encoded[[j]][[i]] == encoded[[j]][[r]], logical(1)))
      for (j in seq_len(ncol(encoded))) {
        difference <- encoded[[j]][[i]] - encoded[[j]][[r]]
        kernel <- switch(as.character(type_codes[[j]]),
          "0" = continuous_kernel(c(0, difference), bandwidths[[j]],
                                  kernel_codes[[j]], distance_type),
          "1" = unordered_kernel(c(TRUE, difference == 0), bandwidths[[j]],
                                 kernel_codes[[j]], level_counts[[j]]),
          "2" = if (distance_type == "dkss" && kernel_codes[[j]] == 0L &&
                     (length(first_dkss_wang) == 0L || j != first_dkss_wang)) {
            c(0, 0)
          } else {
            ordered_kernel(
              c(0, difference), bandwidths[[j]], kernel_codes[[j]],
              if (distance_type == "dkss" && kernel_codes[[j]] == 0L)
                c(TRUE, dkss_wang_all_same) else NULL
            )
          }
        )
        value <- value + 2 * (kernel[[1]] - kernel[[2]])
      }
      D[i, r] <- D[r, i] <- value
    }
  }
  if (standardize) {
    limits <- range(D, finite = TRUE)
    if (diff(limits) > 0) D <- (D - limits[[1]]) / diff(limits)
  }
  D
}

adjusted_rand_index <- function(truth, prediction) {
  tab <- table(factor(truth), factor(prediction))
  choose2 <- function(x) x * (x - 1) / 2
  n <- sum(tab)
  if (n < 2) return(NA_real_)
  index <- sum(choose2(tab))
  row_sum <- sum(choose2(rowSums(tab)))
  col_sum <- sum(choose2(colSums(tab)))
  total <- choose2(n)
  expected <- row_sum * col_sum / total
  maximum <- (row_sum + col_sum) / 2
  if (maximum == expected) return(1)
  (index - expected) / (maximum - expected)
}

matched_labels <- function(truth, prediction) {
  truth <- factor(truth)
  prediction <- factor(prediction)
  tab <- table(prediction, truth)
  size <- max(dim(tab))
  weights <- matrix(0, size, size)
  weights[seq_len(nrow(tab)), seq_len(ncol(tab))] <- unclass(tab)
  cost <- max(weights) - weights

  # Hungarian assignment, written here to keep the analysis self-contained.
  u <- numeric(size)
  v <- numeric(size + 1L)
  p <- integer(size + 1L)
  way <- integer(size + 1L)
  for (i in seq_len(size)) {
    p[[1L]] <- i
    j0 <- 0L
    minv <- rep(Inf, size + 1L)
    used <- rep(FALSE, size + 1L)
    repeat {
      used[[j0 + 1L]] <- TRUE
      i0 <- p[[j0 + 1L]]
      delta <- Inf
      j1 <- 0L
      for (j in seq_len(size)) {
        if (!used[[j + 1L]]) {
          current <- cost[i0, j] - u[[i0]] - v[[j + 1L]]
          if (current < minv[[j + 1L]]) {
            minv[[j + 1L]] <- current
            way[[j + 1L]] <- j0
          }
          if (minv[[j + 1L]] < delta) {
            delta <- minv[[j + 1L]]
            j1 <- j
          }
        }
      }
      for (j in 0:size) {
        if (used[[j + 1L]]) {
          if (p[[j + 1L]] > 0L) u[[p[[j + 1L]]]] <- u[[p[[j + 1L]]]] + delta
          v[[j + 1L]] <- v[[j + 1L]] - delta
        } else if (j > 0L) {
          minv[[j + 1L]] <- minv[[j + 1L]] - delta
        }
      }
      j0 <- j1
      if (p[[j0 + 1L]] == 0L) break
    }
    repeat {
      j1 <- way[[j0 + 1L]]
      p[[j0 + 1L]] <- p[[j1 + 1L]]
      j0 <- j1
      if (j0 == 0L) break
    }
  }
  assignment <- integer(size)
  for (j in seq_len(size)) if (p[[j + 1L]] > 0L) assignment[[p[[j + 1L]]]] <- j
  assigned_truth <- assignment[seq_len(nrow(tab))]
  assigned_truth[assigned_truth > ncol(tab)] <- 1L
  map <- setNames(colnames(tab)[assigned_truth], rownames(tab))
  factor(unname(map[as.character(prediction)]), levels = levels(truth))
}

clustering_metrics <- function(truth, prediction) {
  matched <- matched_labels(truth, prediction)
  list(
    ca = mean(as.character(matched) == as.character(factor(truth))),
    ari = adjusted_rand_index(truth, prediction),
    matched = matched,
    confusion = table(Truth = factor(truth), Cluster = matched)
  )
}

distance_clusterers <- function() {
  c("PAM", paste0("HC-", c("average", "complete", "single", "ward.D", "ward.D2",
                            "mcquitty", "centroid", "median")),
    "AGNES-flexible-0.625", "DIANA")
}

cluster_distance <- function(D, k, method) {
  d <- stats::as.dist(D)
  if (method == "PAM") return(cluster::pam(d, k = k, diss = TRUE)$clustering)
  if (startsWith(method, "HC-")) {
    linkage <- sub("^HC-", "", method)
    return(stats::cutree(stats::hclust(d, method = linkage), k = k))
  }
  if (method == "AGNES-flexible-0.625") {
    fit <- cluster::agnes(d, diss = TRUE, method = "flexible", par.method = 0.625)
    return(stats::cutree(stats::as.hclust(fit), k = k))
  }
  if (method == "DIANA") {
    fit <- cluster::diana(d, diss = TRUE)
    return(stats::cutree(stats::as.hclust(fit), k = k))
  }
  stop("Unknown distance clusterer: ", method)
}

evaluate_distance_clusterers <- function(D, truth) {
  k <- nlevels(factor(truth))
  rows <- lapply(distance_clusterers(), function(method) {
    prediction <- tryCatch(cluster_distance(D, k, method), error = function(e) NULL)
    if (is.null(prediction)) return(NULL)
    metric <- clustering_metrics(truth, prediction)
    data.frame(method = method, ca = metric$ca, ari = metric$ari,
               stringsAsFactors = FALSE)
  })
  do.call(rbind, Filter(Negate(is.null), rows))
}

best_result <- function(results) {
  results[order(-results$ari, -results$ca, results$method), , drop = FALSE][1L, , drop = FALSE]
}

safe_png <- function(path, expression, width = 1800, height = 1200) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  grDevices::png(path, width = width, height = height, res = 150)
  on.exit(grDevices::dev.off(), add = TRUE)
  force(expression)
  invisible(path)
}

plot_pairs <- function(data, groups, path, title) {
  numeric <- as.data.frame(lapply(data, function(x) if (is.numeric(x)) x else as.integer(x)))
  keep <- seq_len(min(ncol(numeric), 8L))
  colors <- grDevices::hcl.colors(nlevels(factor(groups)), "Dark 3")[as.integer(factor(groups))]
  safe_png(path, {
    graphics::pairs(numeric[keep], col = colors, pch = 19, cex = 0.55,
                    main = title, gap = 0.25)
  }, width = 1800, height = 1800)
}

plot_confusion <- function(confusion, path, title) {
  safe_png(path, {
    graphics::mosaicplot(confusion, color = grDevices::hcl.colors(length(confusion), "Blues 3"),
                         main = title, xlab = "Truth", ylab = "Matched cluster")
  })
}

split_rhat <- function(chains) {
  chains <- lapply(chains, as.numeric)
  n <- min(vapply(chains, length, integer(1)))
  half <- floor(n / 2)
  if (length(chains) < 2L || half < 2L) return(NA_real_)
  split <- unlist(lapply(chains, function(x) list(x[seq_len(half)], x[(n - half + 1L):n])),
                  recursive = FALSE)
  matrix <- do.call(cbind, split)
  within <- mean(apply(matrix, 2, stats::var))
  between <- nrow(matrix) * stats::var(colMeans(matrix))
  sqrt((((nrow(matrix) - 1) / nrow(matrix)) * within + between / nrow(matrix)) / within)
}

ess_basic <- function(chains) {
  chains <- lapply(chains, as.numeric)
  n <- min(vapply(chains, length, integer(1)))
  if (n < 4L) return(NA_real_)
  max_lag <- min(n - 1L, 1000L)
  rho <- Reduce(`+`, lapply(chains, function(x) {
    as.numeric(stats::acf(x[seq_len(n)], plot = FALSE, lag.max = max_lag)$acf)[-1L]
  })) / length(chains)
  positive <- rho > 0
  first_negative <- match(FALSE, positive)
  if (!is.na(first_negative)) rho <- rho[seq_len(max(0L, first_negative - 1L))]
  length(chains) * n / (1 + 2 * sum(rho))
}

read_chain_draws <- function(fit_dir, filename) {
  lapply(chain_directories(fit_dir), function(directory) {
    read.csv(file.path(directory, filename), check.names = FALSE)
  })
}

write_diagnostics <- function(fit_dir, output_dir, feature_names, type_codes) {
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  theta <- read_chain_draws(fit_dir, "theta_draws.csv")
  bandwidth <- read_chain_draws(fit_dir, "bandwidth_draws.csv")
  kernel <- read_chain_draws(fit_dir, "kernel_draws.csv")
  traces <- read_chain_draws(fit_dir, "kept_trace.csv")
  moves <- lapply(chain_directories(fit_dir), function(directory) {
    read.csv(file.path(directory, "move_diagnostics.csv"), check.names = FALSE)
  })

  sampler_diagnostics <- file.path(fit_dir, "chain_diagnostics.csv")
  if (file.exists(sampler_diagnostics)) {
    diagnostics <- utils::read.csv(sampler_diagnostics, check.names = FALSE)
  } else {
    diagnostics <- do.call(rbind, lapply(feature_names, function(feature) {
      values <- lapply(theta, `[[`, feature)
      data.frame(
        column = feature,
        rank_rhat = split_rhat(values), folded_rhat = NA_real_,
        bulk_ess = ess_basic(values), tail_ess = NA_real_, mcse_mean = NA_real_,
        lag1_autocorrelation = mean(vapply(values, function(x) {
          if (length(x) < 2L) return(NA_real_)
          stats::cor(x[-length(x)], x[-1L])
        }, numeric(1)), na.rm = TRUE),
        extreme_theta_fraction = mean(abs(unlist(values)) >= 29)
      )
    }))
  }
  utils::write.csv(diagnostics, file.path(output_dir, "mcmc_diagnostics.csv"), row.names = FALSE)
  safe_png(file.path(output_dir, "rhat_ess.png"), {
    graphics::par(mfrow = c(2, 3), mar = c(8, 4, 3, 1))
    labels <- diagnostics$column
    rhat <- pmax(diagnostics$rank_rhat, diagnostics$folded_rhat, na.rm = TRUE)
    rhat[!is.finite(rhat)] <- NA_real_
    graphics::barplot(rhat, names.arg = labels, las = 2,
                      main = "Maximum rank R-hat", ylab = "R-hat")
    graphics::abline(h = 1.01, col = "red", lty = 2)
    graphics::barplot(rbind(diagnostics$bulk_ess, diagnostics$tail_ess), beside = TRUE,
                      names.arg = labels, las = 2, main = "Effective sample size",
                      ylab = "ESS", col = c("#4477AA", "#CC6677"))
    graphics::legend("topright", c("Bulk", "Tail"), fill = c("#4477AA", "#CC6677"),
                     bty = "n")
    graphics::barplot(diagnostics$mcse_mean, names.arg = labels, las = 2,
                      main = "MCSE of theta mean", ylab = "MCSE")
    graphics::barplot(diagnostics$lag1_autocorrelation, names.arg = labels, las = 2,
                      main = "Lag-one autocorrelation", ylab = "Correlation")
    graphics::barplot(diagnostics$extreme_theta_fraction, names.arg = labels, las = 2,
                      main = "Extreme theta occupancy", ylab = "Fraction")
    graphics::plot.new()
  }, width = 2500, height = 1800)

  safe_png(file.path(output_dir, "score_log_target_traces.png"), {
    graphics::par(mfrow = c(2, 1), mar = c(4, 4, 3, 1))
    colors <- grDevices::hcl.colors(length(traces), "Dark 3")
    for (field in c("score", "log_post")) {
      limits <- range(unlist(lapply(traces, `[[`, field)), finite = TRUE)
      graphics::plot(traces[[1]]$iter, traces[[1]][[field]], type = "l", col = colors[[1]],
                     ylim = limits, xlab = "Iteration", ylab = field,
                     main = paste("MCMC", field, "trace"))
      if (length(traces) > 1L) for (chain in 2:length(traces)) {
        graphics::lines(traces[[chain]]$iter, traces[[chain]][[field]], col = colors[[chain]])
      }
    }
  })

  parameter_dir <- file.path(output_dir, "parameters")
  dir.create(parameter_dir, recursive = TRUE, showWarnings = FALSE)
  for (feature in feature_names) {
    safe_png(file.path(parameter_dir, paste0(slug(feature), ".png")), {
      graphics::par(mfrow = c(1, 3), mar = c(4, 4, 3, 1))
      colors <- grDevices::hcl.colors(length(theta), "Dark 3")
      limits <- range(unlist(lapply(theta, `[[`, feature)), finite = TRUE)
      graphics::plot(theta[[1]]$iter, theta[[1]][[feature]], type = "l", col = colors[[1]],
                     ylim = limits, xlab = "Iteration", ylab = expression(theta),
                     main = paste(feature, "trace"))
      if (length(theta) > 1L) for (chain in 2:length(theta)) {
        graphics::lines(theta[[chain]]$iter, theta[[chain]][[feature]], col = colors[[chain]])
      }
      stats::acf(unlist(lapply(theta, `[[`, feature)), main = paste(feature, "ACF"))
      graphics::hist(unlist(lapply(bandwidth, `[[`, feature)), breaks = 40,
                     main = paste(feature, "bandwidth"), xlab = "Bandwidth", col = "grey75")
    }, width = 2200, height = 750)
  }

  kernel_dir <- file.path(output_dir, "kernel_probabilities")
  dir.create(kernel_dir, recursive = TRUE, showWarnings = FALSE)
  for (j in seq_along(feature_names)) {
    feature <- feature_names[[j]]
    prefix <- c("ckernel_", "ukernel_", "okernel_")[[type_codes[[j]] + 1L]]
    column <- paste0(prefix, feature)
    values <- unlist(lapply(kernel, `[[`, column))
    probabilities <- prop.table(table(values))
    safe_png(file.path(kernel_dir, paste0(slug(feature), ".png")), {
      graphics::barplot(probabilities, main = paste(feature, "kernel probabilities"),
                        xlab = "Kernel code", ylab = "Posterior probability", col = "steelblue")
    }, width = 1100, height = 800)
  }

  move_summary <- Reduce(`+`, lapply(moves, function(x) {
    x[, c("sampling_kernel_acceptance_rate", "sampling_bandwidth_acceptance_rate")]
  })) / length(moves)
  rownames(move_summary) <- moves[[1]]$column
  utils::write.csv(cbind(column = rownames(move_summary), move_summary),
                   file.path(output_dir, "move_acceptance.csv"), row.names = FALSE)
  safe_png(file.path(output_dir, "move_acceptance.png"), {
    graphics::barplot(t(as.matrix(move_summary)), beside = TRUE, names.arg = rownames(move_summary),
                      las = 2, ylim = c(0, 1), ylab = "Acceptance rate",
                      main = "Post-warmup move acceptance", col = c("#4477AA", "#CC6677"))
    graphics::legend("topright", legend = c("Kernel", "Bandwidth"),
                     fill = c("#4477AA", "#CC6677"), bty = "n")
  }, width = 1900, height = 1100)
  invisible(diagnostics)
}

evaluate_selected_fit <- function(data, encoded, labels, indices, map_state,
                                  distance_type, cluster_method, output_dir, title) {
  D <- kdml_distance(encoded[indices, , drop = FALSE], type_codes = attr(encoded, "type_codes"),
                     kernel_codes = map_state$kernel_codes,
                     bandwidths = map_state$bandwidths, distance_type = distance_type)
  prediction <- cluster_distance(D, nlevels(factor(labels[indices])), cluster_method)
  metric <- clustering_metrics(labels[indices], prediction)
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(data.frame(row = indices, truth = labels[indices],
                              cluster = prediction, matched_cluster = metric$matched),
                   file.path(output_dir, "assignments.csv"), row.names = FALSE)
  utils::write.csv(as.data.frame.matrix(metric$confusion),
                   file.path(output_dir, "confusion_matrix.csv"))
  utils::write.csv(data.frame(distance_type = distance_type, method = cluster_method,
                              ca = metric$ca, ari = metric$ari),
                   file.path(output_dir, "metrics.csv"), row.names = FALSE)
  plot_pairs(data[indices, , drop = FALSE], labels[indices],
             file.path(output_dir, "pairs_before_clustering.png"),
             paste(title, "true classes"))
  plot_pairs(data[indices, , drop = FALSE], metric$matched,
             file.path(output_dir, "pairs_after_clustering.png"),
             paste(title, distance_type, cluster_method))
  plot_confusion(metric$confusion, file.path(output_dir, "confusion_matrix.png"),
                 paste(title, distance_type, "confusion matrix"))
  list(prediction = prediction, metric = metric, distance = D)
}

competitor_grid <- function(data) {
  continuous <- names(data)[vapply(data, is.numeric, logical(1))]
  categorical <- setdiff(names(data), continuous)
  linkages <- c("average", "complete", "single", "ward.D", "ward.D2")
  if (!length(categorical)) {
    return(rbind(
      data.frame(family = "PAM-E", setting = "PAM-E"),
      data.frame(family = "k-means", setting = "k-means"),
      data.frame(family = "HC-E", setting = paste0("HC-E:", linkages)),
      data.frame(family = "GMM", setting = "GMM")
    ))
  }
  if (!length(continuous)) {
    return(rbind(
      data.frame(family = "PAM-G", setting = "PAM-G"),
      data.frame(family = "k-modes", setting = "k-modes"),
      data.frame(family = "HC-G", setting = paste0("HC-G:", linkages)),
      data.frame(family = "ROCK", setting = paste0("ROCK:", c(0.3, 0.5, 0.7, 0.9)))
    ))
  }
  rbind(
    data.frame(family = "PAM-G", setting = "PAM-G"),
    data.frame(family = "k-prototypes", setting = "k-prototypes"),
    data.frame(family = "HC-G", setting = paste0("HC-G:", linkages)),
    data.frame(family = "clustMD", setting = "clustMD")
  )
}

extract_cluster_vector <- function(fit) {
  if (is.atomic(fit) && length(fit) > 1L) return(as.integer(factor(fit)))
  for (name in c("cluster", "clustering", "classification", "class", "partition", "cl")) {
    if (!is.null(fit[[name]]) && is.atomic(fit[[name]])) return(as.integer(factor(fit[[name]])))
  }
  stop("Could not extract cluster labels from competitor fit.")
}

run_competitor <- function(data, k, setting, seed) {
  set.seed(seed)
  continuous <- names(data)[vapply(data, is.numeric, logical(1))]
  categorical <- setdiff(names(data), continuous)
  numeric_data <- if (length(continuous)) {
    out <- as.data.frame(scale(as.data.frame(lapply(data[continuous], as.numeric))))
    out[] <- lapply(out, function(x) { x[!is.finite(x)] <- 0; x })
    out
  } else NULL
  gower <- function() cluster::daisy(data, metric = "gower")

  if (setting == "PAM-E") return(cluster::pam(stats::dist(numeric_data), k = k)$clustering)
  if (setting == "k-means") return(stats::kmeans(numeric_data, centers = k, nstart = 50)$cluster)
  if (startsWith(setting, "HC-E:")) {
    return(stats::cutree(stats::hclust(stats::dist(numeric_data),
                                      method = sub("^HC-E:", "", setting)), k = k))
  }
  if (setting == "GMM") {
    if (!requireNamespace("mclust", quietly = TRUE)) stop("Package mclust is unavailable.")
    return(mclust::Mclust(numeric_data, G = k)$classification)
  }
  if (setting == "PAM-G") return(cluster::pam(gower(), k = k, diss = TRUE)$clustering)
  if (startsWith(setting, "HC-G:")) {
    return(stats::cutree(stats::hclust(gower(), method = sub("^HC-G:", "", setting)), k = k))
  }
  categorical_data <- as.data.frame(lapply(data[categorical], function(x) factor(as.integer(factor(x)))))
  if (setting == "k-modes") {
    if (!requireNamespace("klaR", quietly = TRUE)) stop("Package klaR is unavailable.")
    return(extract_cluster_vector(klaR::kmodes(categorical_data, modes = k, iter.max = 50,
                                               weighted = FALSE, fast = TRUE)))
  }
  if (startsWith(setting, "ROCK:")) {
    if (!requireNamespace("cba", quietly = TRUE)) stop("Package cba is unavailable.")
    theta <- as.numeric(sub("^ROCK:", "", setting))
    return(extract_cluster_vector(cba::rockCluster(categorical_data, n = k,
                                                   theta = theta, debug = FALSE)))
  }
  if (setting == "k-prototypes") {
    if (!requireNamespace("clustMixType", quietly = TRUE)) stop("Package clustMixType is unavailable.")
    mixed <- data
    mixed[] <- lapply(mixed, function(x) if (is.ordered(x)) factor(as.integer(x)) else x)
    return(extract_cluster_vector(clustMixType::kproto(mixed, k = k, nstart = 10,
                                                       verbose = FALSE)))
  }
  if (setting == "clustMD") {
    if (!requireNamespace("clustMD", quietly = TRUE)) stop("Package clustMD is unavailable.")
    ordered <- names(data)[vapply(data, is.ordered, logical(1))]
    nominal <- setdiff(categorical, ordered)
    columns <- c(continuous, ordered, nominal)
    matrix <- as.matrix(as.data.frame(lapply(data[columns], function(x) {
      if (is.numeric(x)) as.numeric(x) else as.integer(x)
    })))
    fit <- clustMD::clustMD(matrix, G = k, CnsIndx = length(continuous),
                            OrdIndx = length(continuous) + length(ordered),
                            Nnorms = 10000, MaxIter = 100, model = "EII",
                            scale = TRUE, autoStop = TRUE)
    return(extract_cluster_vector(fit))
  }
  stop("Unknown competitor setting: ", setting)
}

select_and_evaluate_competitors <- function(data, labels, validation_indices,
                                            test_indices, seed, output_dir) {
  grid <- competitor_grid(data)
  k <- nlevels(factor(labels))
  validation_rows <- lapply(seq_len(nrow(grid)), function(i) {
    prediction <- tryCatch(
      run_competitor(data[validation_indices, , drop = FALSE], k, grid$setting[[i]], seed + i),
      error = function(e) e
    )
    if (inherits(prediction, "error")) {
      return(data.frame(family = grid$family[[i]], setting = grid$setting[[i]],
                        ca = NA_real_, ari = NA_real_, status = "skipped",
                        note = conditionMessage(prediction)))
    }
    metric <- clustering_metrics(labels[validation_indices], prediction)
    data.frame(family = grid$family[[i]], setting = grid$setting[[i]],
               ca = metric$ca, ari = metric$ari, status = "ok", note = "")
  })
  validation <- do.call(rbind, validation_rows)
  selected <- do.call(rbind, lapply(unique(validation$family), function(family) {
    candidates <- validation[validation$family == family & validation$status == "ok", , drop = FALSE]
    if (!nrow(candidates)) return(validation[validation$family == family, , drop = FALSE][1L, ])
    candidates[order(-candidates$ari, -candidates$ca, candidates$setting), , drop = FALSE][1L, ]
  }))
  test <- do.call(rbind, lapply(seq_len(nrow(selected)), function(i) {
    if (selected$status[[i]] != "ok") {
      return(data.frame(method = selected$family[[i]], setting = selected$setting[[i]],
                        ca = NA_real_, ari = NA_real_, status = "skipped",
                        note = selected$note[[i]]))
    }
    prediction <- tryCatch(
      run_competitor(data[test_indices, , drop = FALSE], k, selected$setting[[i]], seed + 1000L + i),
      error = function(e) e
    )
    if (inherits(prediction, "error")) {
      return(data.frame(method = selected$family[[i]], setting = selected$setting[[i]],
                        ca = NA_real_, ari = NA_real_, status = "failed",
                        note = conditionMessage(prediction)))
    }
    metric <- clustering_metrics(labels[test_indices], prediction)
    display <- selected$family[[i]]
    if (startsWith(selected$setting[[i]], "HC-")) {
      display <- paste0(display, " (", sub("^HC-[EG]:", "", selected$setting[[i]]), ")")
    } else if (startsWith(selected$setting[[i]], "ROCK:")) {
      display <- paste0(display, " (theta=", sub("^ROCK:", "", selected$setting[[i]]), ")")
    }
    data.frame(method = display, setting = selected$setting[[i]], ca = metric$ca,
               ari = metric$ari, status = "ok", note = "")
  }))
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(validation, file.path(output_dir, "validation_results.csv"), row.names = FALSE)
  utils::write.csv(selected, file.path(output_dir, "selected_settings.csv"), row.names = FALSE)
  utils::write.csv(test, file.path(output_dir, "test_results.csv"), row.names = FALSE)
  test
}
