use std::f64::consts::PI;
use std::io::{IsTerminal, Write};
use std::panic;
use std::slice;
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

#[cfg(kdml_cuda)]
mod cuda;

const INV_SQRT_2PI: f64 = 0.398_942_280_401_432_7;
const SQRT_2: f64 = 1.414_213_562_373_095_1;
pub const SAMPLER_VERSION: &str = "kdml-package-v1";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ScoreVersion {
    Legacy,
    Corrected,
}

impl ScoreVersion {
    pub fn from_name(value: &str) -> Option<Self> {
        match value.trim().to_ascii_lowercase().as_str() {
            "legacy" | "legacy-v1" | "v1" => Some(Self::Legacy),
            "corrected" | "corrected-v2" | "v2" => Some(Self::Corrected),
            _ => None,
        }
    }

    pub fn name(self) -> &'static str {
        match self {
            Self::Legacy => "legacy-v1",
            Self::Corrected => "corrected-v2",
        }
    }
}

pub struct CudaBlockSyntheticData {
    pub n: usize,
    pub p: usize,
    pub values: Vec<f64>,
    pub type_codes: Vec<i32>,
}

pub struct CudaBlockSyntheticConfig {
    pub chains: usize,
    pub kept_samples: usize,
    pub burn_in: usize,
    pub thin: usize,
    pub pilot_iter: usize,
    pub pilot_cores: usize,
    pub seed: u64,
    pub beta: f64,
    pub bandwidth_proposal_sd: f64,
    pub adapt: bool,
    pub adapt_bandwidth_target: f64,
    pub random_init: bool,
    pub initial_bandwidths: Option<Vec<f64>>,
    pub mscv_init: bool,
    pub mscv_init_starts: usize,
    pub mscv_init_steps: usize,
    pub prior_mu: f64,
    pub prior_sd: f64,
    pub progress: bool,
    /// Fixed KDML objective for the entire fit. Distance types are compared
    /// with separate sampler runs and are never switched within a chain.
    pub distance_type: DistanceType,
}

impl Default for CudaBlockSyntheticConfig {
    fn default() -> Self {
        Self {
            chains: 1,
            kept_samples: 5000,
            burn_in: 10_000,
            thin: 5,
            pilot_iter: 0,
            pilot_cores: std::thread::available_parallelism()
                .map(|n| n.get())
                .unwrap_or(1),
            seed: 20260703,
            beta: 20.0,
            bandwidth_proposal_sd: 0.15,
            adapt: true,
            adapt_bandwidth_target: 0.44,
            random_init: true,
            initial_bandwidths: None,
            mscv_init: false,
            mscv_init_starts: 1,
            mscv_init_steps: 8,
            prior_mu: 0.0,
            prior_sd: 4.0,
            progress: true,
            distance_type: DistanceType::Dkps,
        }
    }
}

#[derive(Clone)]
pub struct CudaBlockPilotSummary {
    pub model_id: usize,
    pub ckernel_code: i32,
    pub ukernel_code: i32,
    pub okernel_code: i32,
    pub acceptance_rate: f64,
    pub best_score: f64,
    pub last_score: f64,
    pub elapsed_ms: f64,
}

pub struct CudaBlockSyntheticReport {
    pub n_iter: usize,
    pub kept_indices: Vec<usize>,
    pub active_init: usize,
    pub beta: f64,
    pub distance_type: DistanceType,
    pub initialization_attempts: usize,
    pub initialization_fallback: bool,
    pub invalid_proposals: usize,
    pub initial_ckernel: Vec<i32>,
    pub initial_ukernel: Vec<i32>,
    pub initial_okernel: Vec<i32>,
    pub initial_theta: Vec<f64>,
    pub initial_score: f64,
    pub initial_log_post: f64,
    pub type_codes: Vec<i32>,
    pub continuous_reference_scales: Vec<f64>,
    pub external_init: bool,
    pub mscv_init: bool,
    pub mscv_init_starts: usize,
    pub mscv_init_steps: usize,
    pub kernel_codes: Vec<i32>,
    pub ukernel_codes: Vec<i32>,
    pub okernel_codes: Vec<i32>,
    pub pilot_summaries: Vec<CudaBlockPilotSummary>,
    pub samples_model: Vec<i32>,
    pub samples_ckernel: Vec<i32>,
    pub samples_ukernel: Vec<i32>,
    pub samples_okernel: Vec<i32>,
    pub samples_theta: Vec<f64>,
    pub samples_bw: Vec<f64>,
    pub samples_score: Vec<f64>,
    pub samples_log_post: Vec<f64>,
    pub accepted: Vec<i32>,
    pub acceptance_rate: f64,
    pub final_bandwidth_proposal_sds: [f64; 3],
    pub final_bandwidth_proposal_sds_by_col: Vec<f64>,
    pub kernel_attempts_by_col: Vec<usize>,
    pub kernel_accepts_by_col: Vec<usize>,
    pub bandwidth_attempts_by_col: Vec<usize>,
    pub bandwidth_accepts_by_col: Vec<usize>,
    pub sampling_kernel_attempts_by_col: Vec<usize>,
    pub sampling_kernel_accepts_by_col: Vec<usize>,
    pub sampling_bandwidth_attempts_by_col: Vec<usize>,
    pub sampling_bandwidth_accepts_by_col: Vec<usize>,
    pub elapsed_ms: f64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DistanceType {
    Dkps,
    Dkss,
}

impl DistanceType {
    pub fn from_code(code: i32) -> Option<Self> {
        match code {
            0 => Some(Self::Dkps),
            1 => Some(Self::Dkss),
            _ => None,
        }
    }

    pub fn from_name(value: &str) -> Option<Self> {
        match value.trim().to_ascii_lowercase().as_str() {
            "dkps" => Some(Self::Dkps),
            "dkss" => Some(Self::Dkss),
            _ => None,
        }
    }

    pub fn name(self) -> &'static str {
        match self {
            Self::Dkps => "dkps",
            Self::Dkss => "dkss",
        }
    }

    pub fn code(self) -> i32 {
        match self {
            Self::Dkps => 0,
            Self::Dkss => 1,
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum ColumnType {
    Continuous,
    Unordered,
    Ordered,
}

impl ColumnType {
    fn from_code(code: i32) -> Option<Self> {
        match code {
            0 => Some(Self::Continuous),
            1 => Some(Self::Unordered),
            2 => Some(Self::Ordered),
            _ => None,
        }
    }
}

#[derive(Clone, Copy)]
enum ContinuousKernel {
    Gaussian,
    Epanechnikov,
    Uniform,
    Triangle,
    Biweight,
    Triweight,
    Tricube,
    Cosine,
    Logistic,
    Sigmoid,
    Silverman,
}

impl ContinuousKernel {
    fn from_code(code: i32) -> Option<Self> {
        match code {
            0 => Some(Self::Gaussian),
            1 => Some(Self::Epanechnikov),
            2 => Some(Self::Uniform),
            3 => Some(Self::Triangle),
            4 => Some(Self::Biweight),
            5 => Some(Self::Triweight),
            6 => Some(Self::Tricube),
            7 => Some(Self::Cosine),
            8 => Some(Self::Logistic),
            9 => Some(Self::Sigmoid),
            10 => Some(Self::Silverman),
            _ => None,
        }
    }
}

#[derive(Clone, Copy)]
enum UnorderedKernel {
    Aitken,
    AitchisonAitken,
}

impl UnorderedKernel {
    fn from_code(code: i32) -> Option<Self> {
        match code {
            0 => Some(Self::Aitken),
            1 => Some(Self::AitchisonAitken),
            _ => None,
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum OrderedKernel {
    WangVanRyzin,
    Habbema,
    Aitken,
    AitchisonAitken,
    LiRacine,
}

impl OrderedKernel {
    fn from_code(code: i32) -> Option<Self> {
        match code {
            0 => Some(Self::WangVanRyzin),
            1 => Some(Self::Habbema),
            2 => Some(Self::Aitken),
            3 => Some(Self::AitchisonAitken),
            4 => Some(Self::LiRacine),
            _ => None,
        }
    }
}

struct KdmlData<'a> {
    n: usize,
    p: usize,
    values: &'a [f64],
    types: Vec<ColumnType>,
    mins: Vec<f64>,
    maxs: Vec<f64>,
    continuous_scales: Vec<f64>,
    level_counts: Vec<usize>,
    pair_rows_a: Vec<usize>,
    pair_rows_b: Vec<usize>,
    pair_diffs: Vec<f64>,
}

impl<'a> KdmlData<'a> {
    fn new(n: usize, p: usize, values: &'a [f64], type_codes: &[i32]) -> Option<Self> {
        if n == 0 || p == 0 || values.len() < n.checked_mul(p)? || type_codes.len() < p {
            return None;
        }

        let mut types = Vec::with_capacity(p);
        let mut mins = vec![f64::INFINITY; p];
        let mut maxs = vec![f64::NEG_INFINITY; p];
        let mut level_counts = vec![0usize; p];
        let mut continuous_scales = vec![1.0; p];

        for j in 0..p {
            let col_type = ColumnType::from_code(type_codes[j])?;
            types.push(col_type);

            let mut codes = Vec::new();
            for i in 0..n {
                let v = values[j * n + i];
                if !v.is_finite() {
                    return None;
                }
                mins[j] = mins[j].min(v);
                maxs[j] = maxs[j].max(v);
                if !matches!(col_type, ColumnType::Continuous) {
                    codes.push(v.round() as i64);
                }
            }

            if matches!(col_type, ColumnType::Continuous) {
                level_counts[j] = 0;
                let mean = (0..n).map(|i| values[j * n + i]).sum::<f64>() / n as f64;
                let sum_squares = (0..n)
                    .map(|i| (values[j * n + i] - mean).powi(2))
                    .sum::<f64>();
                let sd = if n > 1 {
                    (sum_squares / (n - 1) as f64).sqrt()
                } else {
                    0.0
                };
                continuous_scales[j] = if sd.is_finite() && sd > 1e-12 {
                    sd
                } else {
                    let range = maxs[j] - mins[j];
                    if range.is_finite() && range > 1e-12 {
                        range
                    } else {
                        1.0
                    }
                };
            } else {
                codes.sort_unstable();
                codes.dedup();
                level_counts[j] = codes.len().max(1);
            }
        }

        let pair_count = n.checked_mul(n.saturating_sub(1))? / 2;
        let pair_diff_count = pair_count.checked_mul(p)?;
        let mut pair_rows_a = Vec::with_capacity(pair_count);
        let mut pair_rows_b = Vec::with_capacity(pair_count);
        let mut pair_diffs = Vec::with_capacity(pair_diff_count);

        for i in 0..n {
            for j in (i + 1)..n {
                pair_rows_a.push(i);
                pair_rows_b.push(j);
                for col in 0..p {
                    pair_diffs.push(values[col * n + i] - values[col * n + j]);
                }
            }
        }

        Some(Self {
            n,
            p,
            values,
            types,
            mins,
            maxs,
            continuous_scales,
            level_counts,
            pair_rows_a,
            pair_rows_b,
            pair_diffs,
        })
    }

    #[inline]
    fn at(&self, row: usize, col: usize) -> f64 {
        self.values[col * self.n + row]
    }

    #[inline]
    fn pair_count(&self) -> usize {
        self.pair_rows_a.len()
    }

    #[inline]
    fn pair_diff(&self, pair_idx: usize, col: usize) -> f64 {
        self.pair_diffs[pair_idx * self.p + col]
    }

    fn valid_bandwidths(&self, bw: &[f64], _ukernel: UnorderedKernel) -> bool {
        if bw.len() < self.p {
            return false;
        }

        for j in 0..self.p {
            let b = bw[j];
            if !b.is_finite() || b <= 0.0 {
                return false;
            }

            match self.types[j] {
                ColumnType::Continuous => {}
                ColumnType::Unordered | ColumnType::Ordered => {
                    // The logit parameterization has open support (0, 1).
                    if b >= 1.0 {
                        return false;
                    }
                }
            }
        }

        true
    }
}

#[inline]
fn finite_or_neg_inf(x: f64) -> f64 {
    if x.is_finite() {
        x
    } else {
        f64::NEG_INFINITY
    }
}

fn continuous_kernel_mscv(
    diff: f64,
    lambda: f64,
    distance: DistanceType,
    kernel: ContinuousKernel,
    _score_version: ScoreVersion,
) -> f64 {
    // Estimation and clustering deliberately share the exported kdml package
    // kernel definitions. This prevents the fitted target from optimizing a
    // different kernel than the one used to build the final dissimilarity.
    continuous_kernel_distance(diff, lambda, distance, kernel)
}

fn unordered_kernel_mscv(
    diff: f64,
    lambda: f64,
    level_count: usize,
    kernel: UnorderedKernel,
    _score_version: ScoreVersion,
) -> f64 {
    unordered_kernel_distance(diff == 0.0, lambda, level_count, kernel)
}

fn ordered_kernel_mscv(diff: f64, lambda: f64, _max_diff: f64, kernel: OrderedKernel) -> f64 {
    ordered_kernel_distance(diff, lambda, kernel)
}

fn pair_similarity(
    data: &KdmlData<'_>,
    pair_idx: usize,
    distance: DistanceType,
    ckernel: ContinuousKernel,
    ukernel: UnorderedKernel,
    okernel: OrderedKernel,
    bw: &[f64],
    score_version: ScoreVersion,
) -> f64 {
    let mut continuous_part = 0.0;
    let mut unordered_part = 0.0;
    let mut ordered_part = 0.0;
    let dkss_all_ordered_same = distance == DistanceType::Dkss
        && (0..data.p)
            .filter(|&j| data.types[j] == ColumnType::Ordered)
            .all(|j| data.pair_diff(pair_idx, j) == 0.0);
    let first_ordered = (0..data.p).find(|&j| data.types[j] == ColumnType::Ordered);

    for j in 0..data.p {
        let diff = data.pair_diff(pair_idx, j);
        match data.types[j] {
            ColumnType::Continuous => {
                let value = continuous_kernel_mscv(diff, bw[j], distance, ckernel, score_version);
                continuous_part += value;
            }
            ColumnType::Unordered => {
                unordered_part += unordered_kernel_mscv(
                    diff,
                    bw[j],
                    data.level_counts[j],
                    ukernel,
                    score_version,
                );
            }
            ColumnType::Ordered => {
                let max_diff = data.maxs[j] - data.mins[j];
                ordered_part +=
                    if distance == DistanceType::Dkss && okernel == OrderedKernel::WangVanRyzin {
                        if Some(j) != first_ordered {
                            0.0
                        } else if dkss_all_ordered_same {
                            1.0 - bw[j]
                        } else {
                            0.5 * (1.0 - bw[j]) * bw[j].powf(diff.abs())
                        }
                    } else {
                        ordered_kernel_mscv(diff, bw[j], max_diff, okernel)
                    };
            }
        }
    }

    continuous_part + unordered_part + ordered_part
}

fn mscv_score(
    data: &KdmlData<'_>,
    distance: DistanceType,
    ckernel: ContinuousKernel,
    ukernel: UnorderedKernel,
    okernel: OrderedKernel,
    bw: &[f64],
) -> f64 {
    mscv_score_with_version(
        data,
        distance,
        ckernel,
        ukernel,
        okernel,
        bw,
        ScoreVersion::Corrected,
    )
}

fn mscv_score_with_version(
    data: &KdmlData<'_>,
    distance: DistanceType,
    ckernel: ContinuousKernel,
    ukernel: UnorderedKernel,
    okernel: OrderedKernel,
    bw: &[f64],
    score_version: ScoreVersion,
) -> f64 {
    if data.n < 2 || !data.valid_bandwidths(bw, ukernel) {
        return f64::NEG_INFINITY;
    }

    let mut col_sums = vec![0.0; data.n];
    for pair_idx in 0..data.pair_count() {
        let d = pair_similarity(
            data,
            pair_idx,
            distance,
            ckernel,
            ukernel,
            okernel,
            bw,
            score_version,
        );
        if !d.is_finite() {
            return f64::NEG_INFINITY;
        }
        let i = data.pair_rows_a[pair_idx];
        let j = data.pair_rows_b[pair_idx];
        col_sums[i] += d;
        col_sums[j] += d;
    }

    let log_n_minus_1 = ((data.n - 1) as f64).ln();
    let mut total = 0.0;
    for value in col_sums {
        if !value.is_finite() || value <= 0.0 {
            return f64::NEG_INFINITY;
        }
        total += value.ln() - log_n_minus_1;
    }

    total / data.n as f64
}

fn continuous_kernel_distance(
    diff: f64,
    lambda: f64,
    distance: DistanceType,
    kernel: ContinuousKernel,
) -> f64 {
    let z = diff / lambda;
    let az = z.abs();
    let dkps_scale = if distance == DistanceType::Dkps {
        1.0 / lambda
    } else {
        1.0
    };

    match kernel {
        ContinuousKernel::Gaussian => dkps_scale * INV_SQRT_2PI * (-0.5 * z * z).exp(),
        ContinuousKernel::Uniform => {
            if az <= 1.0 {
                dkps_scale * 0.5
            } else {
                0.0
            }
        }
        ContinuousKernel::Epanechnikov => {
            if az <= 1.0 {
                dkps_scale * 0.75 * (1.0 - z * z)
            } else {
                0.0
            }
        }
        ContinuousKernel::Triangle => {
            if az <= 1.0 {
                dkps_scale * (1.0 - az)
            } else {
                0.0
            }
        }
        ContinuousKernel::Biweight => {
            if az <= 1.0 {
                dkps_scale * (15.0 / 32.0) * (3.0 - z * z).powi(2)
            } else {
                0.0
            }
        }
        ContinuousKernel::Triweight => {
            if az <= 1.0 {
                dkps_scale * (35.0 / 32.0) * (1.0 - z * z).powi(3)
            } else {
                0.0
            }
        }
        ContinuousKernel::Tricube => {
            if az <= 1.0 {
                dkps_scale * (70.0 / 81.0) * (1.0 - az.powi(3)).powi(3)
            } else {
                0.0
            }
        }
        ContinuousKernel::Cosine => {
            if az <= 1.0 {
                dkps_scale * (PI / 4.0) * ((PI / 2.0) * z).cos()
            } else {
                0.0
            }
        }
        ContinuousKernel::Logistic => dkps_scale / (z.exp() + 2.0 + (-z).exp()),
        ContinuousKernel::Sigmoid => dkps_scale * 2.0 / (PI * (z.exp() + (-z).exp())),
        ContinuousKernel::Silverman => {
            let scale = if distance == DistanceType::Dkps {
                1.0 / lambda
            } else {
                // kdml's dkss distance implementation also includes 1 / bw
                // for Silverman.
                1.0 / lambda
            };
            scale * 0.5 * (-(az / SQRT_2)).exp() * (az / SQRT_2 + PI / 4.0).sin()
        }
    }
}

fn unordered_kernel_distance(
    same: bool,
    lambda: f64,
    level_count: usize,
    kernel: UnorderedKernel,
) -> f64 {
    match kernel {
        UnorderedKernel::Aitken => {
            if same {
                1.0
            } else {
                lambda
            }
        }
        UnorderedKernel::AitchisonAitken => {
            if same {
                1.0 - lambda
            } else if level_count > 1 {
                lambda / (level_count as f64 - 1.0)
            } else {
                f64::INFINITY
            }
        }
    }
}

fn ordered_kernel_distance(diff: f64, lambda: f64, kernel: OrderedKernel) -> f64 {
    let ad = diff.abs();
    match kernel {
        OrderedKernel::WangVanRyzin => {
            if diff == 0.0 {
                1.0 - lambda
            } else {
                0.5 * (1.0 - lambda) * lambda.powf(ad)
            }
        }
        OrderedKernel::AitchisonAitken | OrderedKernel::LiRacine => {
            if diff == 0.0 {
                1.0
            } else {
                lambda.powf(ad)
            }
        }
        OrderedKernel::Aitken => {
            if diff == 0.0 {
                lambda
            } else {
                (1.0 - lambda) / 2.0_f64.powf(ad)
            }
        }
        OrderedKernel::Habbema => lambda.powf(ad * ad),
    }
}

fn pair_kdml_distance(
    data: &KdmlData<'_>,
    pair_idx: usize,
    distance: DistanceType,
    ckernel: ContinuousKernel,
    ukernel: UnorderedKernel,
    okernel: OrderedKernel,
    bw: &[f64],
) -> f64 {
    let mut out = 0.0;
    let dkss_all_ordered_same = distance == DistanceType::Dkss
        && (0..data.p)
            .filter(|&j| data.types[j] == ColumnType::Ordered)
            .all(|j| data.pair_diff(pair_idx, j) == 0.0);
    let first_ordered = (0..data.p).find(|&j| data.types[j] == ColumnType::Ordered);

    for j in 0..data.p {
        let diff = data.pair_diff(pair_idx, j);

        let contribution = match data.types[j] {
            ColumnType::Continuous => {
                let self_a = continuous_kernel_distance(0.0, bw[j], distance, ckernel);
                let self_b = self_a;
                let cross_ab = continuous_kernel_distance(diff, bw[j], distance, ckernel);
                let cross_ba = continuous_kernel_distance(-diff, bw[j], distance, ckernel);
                self_a + self_b - cross_ab - cross_ba
            }
            ColumnType::Unordered => {
                let same = diff == 0.0;
                let self_a = unordered_kernel_distance(true, bw[j], data.level_counts[j], ukernel);
                let self_b = self_a;
                let cross_ab =
                    unordered_kernel_distance(same, bw[j], data.level_counts[j], ukernel);
                let cross_ba = cross_ab;
                self_a + self_b - cross_ab - cross_ba
            }
            ColumnType::Ordered => {
                let self_a = ordered_kernel_distance(0.0, bw[j], okernel);
                let self_b = self_a;
                let (cross_ab, cross_ba) =
                    if distance == DistanceType::Dkss && okernel == OrderedKernel::WangVanRyzin {
                        let cross = if Some(j) != first_ordered {
                            self_a
                        } else if dkss_all_ordered_same {
                            1.0 - bw[j]
                        } else {
                            0.5 * (1.0 - bw[j]) * bw[j].powf(diff.abs())
                        };
                        (cross, cross)
                    } else {
                        (
                            ordered_kernel_distance(diff, bw[j], okernel),
                            ordered_kernel_distance(-diff, bw[j], okernel),
                        )
                    };
                self_a + self_b - cross_ab - cross_ba
            }
        };

        out += contribution;
    }

    out
}

fn log_normal_sum(theta: &[f64], mean: f64, sd: f64) -> f64 {
    if sd <= 0.0 || !sd.is_finite() {
        return f64::NEG_INFINITY;
    }
    let constant = -0.5 * (2.0 * PI).ln() - sd.ln();
    let mut total = 0.0;
    for &x in theta {
        if !x.is_finite() {
            return f64::NEG_INFINITY;
        }
        let z = (x - mean) / sd;
        total += constant - 0.5 * z * z;
    }
    total
}

#[cfg(any())]
fn log_normal_sum_model(theta: &[f64], k: usize, k_count: usize, mu: &[f64], sd: &[f64]) -> f64 {
    let constant = -0.5 * (2.0 * PI).ln();
    let mut total = 0.0;
    for j in 0..theta.len() {
        let idx = j * k_count + k;
        let s = sd[idx];
        if !theta[j].is_finite() || !mu[idx].is_finite() || !s.is_finite() || s <= 0.0 {
            return f64::NEG_INFINITY;
        }
        let z = (theta[j] - mu[idx]) / s;
        total += constant - s.ln() - 0.5 * z * z;
    }
    total
}

#[cfg(any())]
fn log_posterior(
    data: &KdmlData<'_>,
    distance: DistanceType,
    ckernel: ContinuousKernel,
    ukernel: UnorderedKernel,
    okernel: OrderedKernel,
    theta: &[f64],
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    model_count: usize,
) -> f64 {
    if theta.iter().any(|x| !x.is_finite()) {
        return f64::NEG_INFINITY;
    }
    let bw = theta_to_bandwidth(data, ukernel, theta);
    let score = mscv_score(data, distance, ckernel, ukernel, okernel, &bw);
    if !score.is_finite() {
        return f64::NEG_INFINITY;
    }
    beta * score - (model_count as f64).ln() + log_normal_sum(theta, prior_mu, prior_sd)
}

struct Rng64 {
    state: u64,
    spare: Option<f64>,
}

impl Rng64 {
    fn new(seed: u64) -> Self {
        Self {
            state: seed ^ 0x9e37_79b9_7f4a_7c15,
            spare: None,
        }
    }

    fn next_u64(&mut self) -> u64 {
        self.state = self.state.wrapping_add(0x9e37_79b9_7f4a_7c15);
        let mut z = self.state;
        z = (z ^ (z >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
        z ^ (z >> 31)
    }

    fn uniform(&mut self) -> f64 {
        let v = self.next_u64() >> 11;
        ((v as f64) + 0.5) * (1.0 / ((1u64 << 53) as f64))
    }

    fn normal(&mut self) -> f64 {
        if let Some(x) = self.spare.take() {
            return x;
        }
        let u1 = self.uniform().max(f64::MIN_POSITIVE);
        let u2 = self.uniform();
        let radius = (-2.0 * u1.ln()).sqrt();
        let angle = 2.0 * PI * u2;
        let z0 = radius * angle.cos();
        let z1 = radius * angle.sin();
        self.spare = Some(z1);
        z0
    }
}

#[inline]
fn theta_idx(k: usize, j: usize, k_count: usize) -> usize {
    j * k_count + k
}

#[derive(Clone, Copy)]
struct KernelSlot<K> {
    code: i32,
    kernel: K,
}

fn unique_continuous_slots(codes: &[i32]) -> Option<Vec<KernelSlot<ContinuousKernel>>> {
    let mut out = Vec::new();
    for &code in codes {
        if out
            .iter()
            .any(|slot: &KernelSlot<ContinuousKernel>| slot.code == code)
        {
            continue;
        }
        out.push(KernelSlot {
            code,
            kernel: ContinuousKernel::from_code(code)?,
        });
    }
    Some(out)
}

fn unique_unordered_slots(codes: &[i32]) -> Option<Vec<KernelSlot<UnorderedKernel>>> {
    let mut out = Vec::new();
    for &code in codes {
        if out
            .iter()
            .any(|slot: &KernelSlot<UnorderedKernel>| slot.code == code)
        {
            continue;
        }
        out.push(KernelSlot {
            code,
            kernel: UnorderedKernel::from_code(code)?,
        });
    }
    Some(out)
}

fn unique_ordered_slots(codes: &[i32]) -> Option<Vec<KernelSlot<OrderedKernel>>> {
    let mut out = Vec::new();
    for &code in codes {
        if out
            .iter()
            .any(|slot: &KernelSlot<OrderedKernel>| slot.code == code)
        {
            continue;
        }
        out.push(KernelSlot {
            code,
            kernel: OrderedKernel::from_code(code)?,
        });
    }
    Some(out)
}

fn first_model_with_codes(
    kernel_codes: &[i32],
    ukernel_codes: &[i32],
    okernel_codes: &[i32],
    c_code: i32,
    u_code: i32,
    o_code: i32,
) -> Option<usize> {
    (0..kernel_codes.len()).find(|&idx| {
        kernel_codes[idx] == c_code && ukernel_codes[idx] == u_code && okernel_codes[idx] == o_code
    })
}

#[cfg(any())]
fn assemble_type_theta(
    data: &KdmlData<'_>,
    c_theta: &[f64],
    u_theta: &[f64],
    o_theta: &[f64],
    out: &mut [f64],
) {
    for j in 0..data.p {
        out[j] = match data.types[j] {
            ColumnType::Continuous => c_theta[j],
            ColumnType::Unordered => u_theta[j],
            ColumnType::Ordered => o_theta[j],
        };
    }
}

#[cfg(any())]
fn copy_slot_theta(theta: &[f64], slot: usize, slot_count: usize, p: usize, out: &mut [f64]) {
    for j in 0..p {
        out[j] = theta[theta_idx(slot, j, slot_count)];
    }
}

#[cfg(any())]
fn set_slot_theta(theta: &mut [f64], slot: usize, slot_count: usize, values: &[f64]) {
    for (j, &value) in values.iter().enumerate() {
        theta[theta_idx(slot, j, slot_count)] = value;
    }
}

fn sample_log_weights(log_w: &mut [f64], rng: &mut Rng64) -> Result<usize, i32> {
    let mut any_finite = false;
    let mut max_log_w = f64::NEG_INFINITY;
    for &value in log_w.iter() {
        if value.is_finite() {
            any_finite = true;
            max_log_w = max_log_w.max(value);
        }
    }
    if !any_finite {
        return Err(-9);
    }

    let mut total_w = 0.0;
    for value in log_w.iter_mut() {
        if value.is_finite() {
            *value = (*value - max_log_w).exp();
            total_w += *value;
        } else {
            *value = 0.0;
        }
    }
    if !total_w.is_finite() || total_w <= 0.0 {
        return Err(-10);
    }

    let mut draw = rng.uniform() * total_w;
    let mut active = log_w.len() - 1;
    for (idx, &weight) in log_w.iter().enumerate() {
        draw -= weight;
        if draw <= 0.0 {
            active = idx;
            break;
        }
    }
    Ok(active)
}

#[cfg(any())]
fn run_mcmc_impl(
    n: usize,
    p: usize,
    k_count: usize,
    data_values: &[f64],
    type_codes: &[i32],
    distance_code: i32,
    kernel_codes: &[i32],
    ukernel_codes: &[i32],
    okernel_codes: &[i32],
    init_theta: &[f64],
    pseudo_mu: &[f64],
    pseudo_sd: &[f64],
    n_iter: usize,
    beta: f64,
    proposal_sd: f64,
    active_init: usize,
    prior_mu: f64,
    prior_sd: f64,
    seed: u64,
    mut progress: Option<&mut dyn FnMut(usize)>,
    samples_model: &mut [i32],
    samples_theta: &mut [f64],
    samples_bw: &mut [f64],
    samples_score: &mut [f64],
    samples_log_post: &mut [f64],
    accepted: &mut [i32],
    mh_model: &mut [i32],
) -> Result<f64, i32> {
    let data = KdmlData::new(n, p, data_values, type_codes).ok_or(-2)?;
    let distance = DistanceType::from_code(distance_code).ok_or(-3)?;
    if kernel_codes.len() < k_count
        || ukernel_codes.len() < k_count
        || okernel_codes.len() < k_count
    {
        return Err(-7);
    }
    let kernel_codes = &kernel_codes[..k_count];
    let ukernel_codes = &ukernel_codes[..k_count];
    let okernel_codes = &okernel_codes[..k_count];
    let c_slots = unique_continuous_slots(kernel_codes).ok_or(-6)?;
    let u_slots = unique_unordered_slots(ukernel_codes).ok_or(-4)?;
    let o_slots = unique_ordered_slots(okernel_codes).ok_or(-5)?;
    let c_count = c_slots.len();
    let u_count = u_slots.len();
    let o_count = o_slots.len();
    if c_count == 0 || u_count == 0 || o_count == 0 {
        return Err(-7);
    }

    let kp = k_count.checked_mul(p).ok_or(-7)?;
    if active_init == 0
        || active_init > k_count
        || init_theta.len() < kp
        || pseudo_mu.len() < kp
        || pseudo_sd.len() < kp
        || samples_model.len() < n_iter
        || samples_theta.len() < n_iter * p
        || samples_bw.len() < n_iter * p
        || samples_score.len() < n_iter
        || samples_log_post.len() < n_iter
        || accepted.len() < n_iter
        || mh_model.len() < n_iter
    {
        return Err(-7);
    }
    if !proposal_sd.is_finite() || proposal_sd <= 0.0 || !prior_sd.is_finite() || prior_sd <= 0.0 {
        return Err(-8);
    }

    let mut rng = Rng64::new(seed);
    let init_model = active_init - 1;
    let mut active_c = c_slots
        .iter()
        .position(|slot| slot.code == kernel_codes[init_model])
        .ok_or(-7)?;
    let mut active_u = u_slots
        .iter()
        .position(|slot| slot.code == ukernel_codes[init_model])
        .ok_or(-7)?;
    let mut active_o = o_slots
        .iter()
        .position(|slot| slot.code == okernel_codes[init_model])
        .ok_or(-7)?;

    let mut c_theta = vec![0.0; c_count * p];
    let mut u_theta = vec![0.0; u_count * p];
    let mut o_theta = vec![0.0; o_count * p];
    let mut c_mu = vec![0.0; c_count * p];
    let mut u_mu = vec![0.0; u_count * p];
    let mut o_mu = vec![0.0; o_count * p];
    let mut c_sd = vec![1.0; c_count * p];
    let mut u_sd = vec![1.0; u_count * p];
    let mut o_sd = vec![1.0; o_count * p];

    for (slot_idx, slot) in c_slots.iter().enumerate() {
        let model_idx = kernel_codes
            .iter()
            .position(|&code| code == slot.code)
            .ok_or(-7)?;
        for j in 0..p {
            c_theta[theta_idx(slot_idx, j, c_count)] = init_theta[theta_idx(model_idx, j, k_count)];
            c_mu[theta_idx(slot_idx, j, c_count)] = pseudo_mu[theta_idx(model_idx, j, k_count)];
            c_sd[theta_idx(slot_idx, j, c_count)] = pseudo_sd[theta_idx(model_idx, j, k_count)];
        }
    }
    for (slot_idx, slot) in u_slots.iter().enumerate() {
        let model_idx = ukernel_codes
            .iter()
            .position(|&code| code == slot.code)
            .ok_or(-7)?;
        for j in 0..p {
            u_theta[theta_idx(slot_idx, j, u_count)] = init_theta[theta_idx(model_idx, j, k_count)];
            u_mu[theta_idx(slot_idx, j, u_count)] = pseudo_mu[theta_idx(model_idx, j, k_count)];
            u_sd[theta_idx(slot_idx, j, u_count)] = pseudo_sd[theta_idx(model_idx, j, k_count)];
        }
    }
    for (slot_idx, slot) in o_slots.iter().enumerate() {
        let model_idx = okernel_codes
            .iter()
            .position(|&code| code == slot.code)
            .ok_or(-7)?;
        for j in 0..p {
            o_theta[theta_idx(slot_idx, j, o_count)] = init_theta[theta_idx(model_idx, j, k_count)];
            o_mu[theta_idx(slot_idx, j, o_count)] = pseudo_mu[theta_idx(model_idx, j, k_count)];
            o_sd[theta_idx(slot_idx, j, o_count)] = pseudo_sd[theta_idx(model_idx, j, k_count)];
        }
    }

    let mut current_theta = vec![0.0; p];
    let mut proposal_theta = vec![0.0; p];
    let mut c_part = vec![0.0; p];
    let mut u_part = vec![0.0; p];
    let mut o_part = vec![0.0; p];
    let mut proposal_c = vec![0.0; p];
    let mut proposal_u = vec![0.0; p];
    let mut proposal_o = vec![0.0; p];
    let mut c_log_w = vec![f64::NEG_INFINITY; c_count];
    let mut u_log_w = vec![f64::NEG_INFINITY; u_count];
    let mut o_log_w = vec![f64::NEG_INFINITY; o_count];
    let mut accept_count = 0usize;
    let progress_stride = if progress.is_some() {
        (n_iter / 200).max(1)
    } else {
        usize::MAX
    };

    for iter in 0..n_iter {
        let current_model = first_model_with_codes(
            kernel_codes,
            ukernel_codes,
            okernel_codes,
            c_slots[active_c].code,
            u_slots[active_u].code,
            o_slots[active_o].code,
        )
        .ok_or(-11)?;
        mh_model[iter] = (current_model + 1) as i32;
        copy_slot_theta(&c_theta, active_c, c_count, p, &mut c_part);
        copy_slot_theta(&u_theta, active_u, u_count, p, &mut u_part);
        copy_slot_theta(&o_theta, active_o, o_count, p, &mut o_part);
        assemble_type_theta(&data, &c_part, &u_part, &o_part, &mut current_theta);
        proposal_c.copy_from_slice(&c_part);
        proposal_u.copy_from_slice(&u_part);
        proposal_o.copy_from_slice(&o_part);
        for j in 0..p {
            match data.types[j] {
                ColumnType::Continuous => proposal_c[j] += proposal_sd * rng.normal(),
                ColumnType::Unordered => proposal_u[j] += proposal_sd * rng.normal(),
                ColumnType::Ordered => proposal_o[j] += proposal_sd * rng.normal(),
            }
        }
        assemble_type_theta(
            &data,
            &proposal_c,
            &proposal_u,
            &proposal_o,
            &mut proposal_theta,
        );

        let log_post_current = log_posterior(
            &data,
            distance,
            c_slots[active_c].kernel,
            u_slots[active_u].kernel,
            o_slots[active_o].kernel,
            &current_theta,
            beta,
            prior_mu,
            prior_sd,
            c_count * u_count * o_count,
        );
        let log_post_proposal = log_posterior(
            &data,
            distance,
            c_slots[active_c].kernel,
            u_slots[active_u].kernel,
            o_slots[active_o].kernel,
            &proposal_theta,
            beta,
            prior_mu,
            prior_sd,
            c_count * u_count * o_count,
        );
        let log_alpha = log_post_proposal - log_post_current;

        if log_alpha.is_finite() && rng.uniform().ln() < log_alpha {
            set_slot_theta(&mut c_theta, active_c, c_count, &proposal_c);
            set_slot_theta(&mut u_theta, active_u, u_count, &proposal_u);
            set_slot_theta(&mut o_theta, active_o, o_count, &proposal_o);
            current_theta.copy_from_slice(&proposal_theta);
            accepted[iter] = 1;
            accept_count += 1;
        } else {
            accepted[iter] = 0;
        }

        for k in 0..c_count {
            if k != active_c {
                for j in 0..p {
                    let idx = theta_idx(k, j, c_count);
                    c_theta[idx] = c_mu[idx] + c_sd[idx] * rng.normal();
                }
            }
        }
        for k in 0..u_count {
            if k != active_u {
                for j in 0..p {
                    let idx = theta_idx(k, j, u_count);
                    u_theta[idx] = u_mu[idx] + u_sd[idx] * rng.normal();
                }
            }
        }
        for k in 0..o_count {
            if k != active_o {
                for j in 0..p {
                    let idx = theta_idx(k, j, o_count);
                    o_theta[idx] = o_mu[idx] + o_sd[idx] * rng.normal();
                }
            }
        }

        copy_slot_theta(&u_theta, active_u, u_count, p, &mut u_part);
        copy_slot_theta(&o_theta, active_o, o_count, p, &mut o_part);
        for k in 0..c_count {
            copy_slot_theta(&c_theta, k, c_count, p, &mut c_part);
            assemble_type_theta(&data, &c_part, &u_part, &o_part, &mut current_theta);
            let lp = log_posterior(
                &data,
                distance,
                c_slots[k].kernel,
                u_slots[active_u].kernel,
                o_slots[active_o].kernel,
                &current_theta,
                beta,
                prior_mu,
                prior_sd,
                c_count * u_count * o_count,
            );
            c_log_w[k] = lp - log_normal_sum_model(&c_part, k, c_count, &c_mu, &c_sd);
        }
        active_c = sample_log_weights(&mut c_log_w, &mut rng)?;

        copy_slot_theta(&c_theta, active_c, c_count, p, &mut c_part);
        for k in 0..u_count {
            copy_slot_theta(&u_theta, k, u_count, p, &mut u_part);
            assemble_type_theta(&data, &c_part, &u_part, &o_part, &mut current_theta);
            let lp = log_posterior(
                &data,
                distance,
                c_slots[active_c].kernel,
                u_slots[k].kernel,
                o_slots[active_o].kernel,
                &current_theta,
                beta,
                prior_mu,
                prior_sd,
                c_count * u_count * o_count,
            );
            u_log_w[k] = lp - log_normal_sum_model(&u_part, k, u_count, &u_mu, &u_sd);
        }
        active_u = sample_log_weights(&mut u_log_w, &mut rng)?;

        copy_slot_theta(&u_theta, active_u, u_count, p, &mut u_part);
        for k in 0..o_count {
            copy_slot_theta(&o_theta, k, o_count, p, &mut o_part);
            assemble_type_theta(&data, &c_part, &u_part, &o_part, &mut current_theta);
            let lp = log_posterior(
                &data,
                distance,
                c_slots[active_c].kernel,
                u_slots[active_u].kernel,
                o_slots[k].kernel,
                &current_theta,
                beta,
                prior_mu,
                prior_sd,
                c_count * u_count * o_count,
            );
            o_log_w[k] = lp - log_normal_sum_model(&o_part, k, o_count, &o_mu, &o_sd);
        }
        active_o = sample_log_weights(&mut o_log_w, &mut rng)?;

        copy_slot_theta(&c_theta, active_c, c_count, p, &mut c_part);
        copy_slot_theta(&u_theta, active_u, u_count, p, &mut u_part);
        copy_slot_theta(&o_theta, active_o, o_count, p, &mut o_part);
        assemble_type_theta(&data, &c_part, &u_part, &o_part, &mut current_theta);
        let active_model = first_model_with_codes(
            kernel_codes,
            ukernel_codes,
            okernel_codes,
            c_slots[active_c].code,
            u_slots[active_u].code,
            o_slots[active_o].code,
        )
        .ok_or(-11)?;
        let active_bw = theta_to_bandwidth(&data, u_slots[active_u].kernel, &current_theta);
        let active_score = mscv_score(
            &data,
            distance,
            c_slots[active_c].kernel,
            u_slots[active_u].kernel,
            o_slots[active_o].kernel,
            &active_bw,
        );
        let active_log_post = log_posterior(
            &data,
            distance,
            c_slots[active_c].kernel,
            u_slots[active_u].kernel,
            o_slots[active_o].kernel,
            &current_theta,
            beta,
            prior_mu,
            prior_sd,
            c_count * u_count * o_count,
        );

        samples_model[iter] = (active_model + 1) as i32;
        samples_score[iter] = active_score;
        samples_log_post[iter] = active_log_post;
        for j in 0..p {
            samples_theta[j * n_iter + iter] = current_theta[j];
            samples_bw[j * n_iter + iter] = active_bw[j];
        }

        let completed = iter + 1;
        if (completed == 1 || completed == n_iter || completed % progress_stride == 0)
            && progress.is_some()
        {
            if let Some(callback) = progress.as_deref_mut() {
                callback(completed);
            }
        }
    }

    Ok(accept_count as f64 / n_iter as f64)
}

#[cfg(kdml_cuda)]
#[derive(Clone, Copy)]
struct CudaF32LogPost {
    score: f32,
    log_post: f64,
}

#[cfg(kdml_cuda)]
#[allow(dead_code)]
fn log_posterior_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    ckernel_code: i32,
    ukernel_code: i32,
    okernel_code: i32,
    ukernel: UnorderedKernel,
    bw: &[f64],
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    model_count: usize,
) -> Result<CudaF32LogPost, i32> {
    if !data.valid_bandwidths(bw, ukernel) {
        return Ok(CudaF32LogPost {
            score: f32::NEG_INFINITY,
            log_post: f64::NEG_INFINITY,
        });
    }

    let bw_f32: Vec<f32> = bw.iter().map(|&value| value as f32).collect();
    let score = cuda
        .score_f32_with_kernels(
            &bw_f32,
            distance_code,
            ckernel_code,
            ukernel_code,
            okernel_code,
        )
        .map_err(|_| -30)?;
    if !score.is_finite() {
        return Ok(CudaF32LogPost {
            score,
            log_post: f64::NEG_INFINITY,
        });
    }

    let theta = bandwidth_to_theta(data, ukernel, bw);
    let log_prior = log_normal_sum(&theta, prior_mu, prior_sd);
    if !log_prior.is_finite() {
        return Ok(CudaF32LogPost {
            score,
            log_post: f64::NEG_INFINITY,
        });
    }

    Ok(CudaF32LogPost {
        score,
        log_post: beta * score as f64 - (model_count as f64).ln() + log_prior,
    })
}

#[cfg(any())]
fn type_column_indices(data: &KdmlData<'_>, target_type: ColumnType) -> Vec<usize> {
    data.types
        .iter()
        .enumerate()
        .filter_map(|(idx, &col_type)| (col_type == target_type).then_some(idx))
        .collect()
}

#[cfg(any())]
fn sampled_column(candidates: &[usize], rng: &mut Rng64) -> Option<usize> {
    if candidates.is_empty() {
        None
    } else {
        Some(candidates[(rng.uniform() * candidates.len() as f64).floor() as usize])
    }
}

#[cfg(kdml_cuda)]
#[allow(dead_code)]
fn initial_column_kernel_codes(
    data: &KdmlData<'_>,
    ckernel_code: i32,
    ukernel_code: i32,
    okernel_code: i32,
) -> (Vec<i32>, Vec<i32>, Vec<i32>) {
    let mut c_codes = vec![ckernel_code; data.p];
    let mut u_codes = vec![ukernel_code; data.p];
    let mut o_codes = vec![okernel_code; data.p];
    for j in 0..data.p {
        match data.types[j] {
            ColumnType::Continuous => {
                u_codes[j] = 0;
                o_codes[j] = 0;
            }
            ColumnType::Unordered => {
                c_codes[j] = 0;
                o_codes[j] = 0;
            }
            ColumnType::Ordered => {
                c_codes[j] = 0;
                u_codes[j] = 0;
            }
        }
    }
    (c_codes, u_codes, o_codes)
}

#[cfg(kdml_cuda)]
fn log_model_count_for_column_kernels(
    data: &KdmlData<'_>,
    c_slots: &[KernelSlot<ContinuousKernel>],
    u_slots: &[KernelSlot<UnorderedKernel>],
    o_slots: &[KernelSlot<OrderedKernel>],
) -> f64 {
    let mut total = 0.0;
    for &col_type in &data.types {
        total += match col_type {
            ColumnType::Continuous => (c_slots.len() as f64).ln(),
            ColumnType::Unordered => (u_slots.len() as f64).ln(),
            ColumnType::Ordered => (o_slots.len() as f64).ln(),
        };
    }
    total
}

#[cfg(kdml_cuda)]
fn unordered_kernel_for_col(code: i32) -> Option<UnorderedKernel> {
    UnorderedKernel::from_code(code)
}

#[cfg(kdml_cuda)]
fn valid_bandwidths_column_kernels(
    data: &KdmlData<'_>,
    ukernel_codes_by_col: &[i32],
    bw: &[f64],
) -> bool {
    if bw.len() < data.p || ukernel_codes_by_col.len() < data.p {
        return false;
    }
    for j in 0..data.p {
        if !bw[j].is_finite() || bw[j] <= 0.0 {
            return false;
        }
        match data.types[j] {
            ColumnType::Continuous => {}
            ColumnType::Unordered => {
                if unordered_kernel_for_col(ukernel_codes_by_col[j]).is_none() || bw[j] >= 1.0 {
                    return false;
                }
            }
            ColumnType::Ordered => {
                if bw[j] >= 1.0 {
                    return false;
                }
            }
        }
    }
    true
}

#[cfg(kdml_cuda)]
fn bandwidth_to_theta_column_kernels(
    data: &KdmlData<'_>,
    ukernel_codes_by_col: &[i32],
    bw: &[f64],
) -> Option<Vec<f64>> {
    let mut theta = vec![0.0; data.p];
    for j in 0..data.p {
        theta[j] = match data.types[j] {
            ColumnType::Continuous => {
                (bw[j].max(f64::MIN_POSITIVE) / data.continuous_scales[j]).ln()
            }
            ColumnType::Unordered => {
                unordered_kernel_for_col(*ukernel_codes_by_col.get(j)?)?;
                logit(bw[j].clamp(1e-8, 1.0 - 1e-8))
            }
            ColumnType::Ordered => logit(bw[j].clamp(1e-8, 1.0 - 1e-8)),
        };
    }
    Some(theta)
}

#[cfg(kdml_cuda)]
fn theta_to_bandwidth_column_kernels(
    data: &KdmlData<'_>,
    ukernel_codes_by_col: &[i32],
    theta: &[f64],
) -> Option<Vec<f64>> {
    let mut bw = vec![1.0; data.p];
    for j in 0..data.p {
        if !theta[j].is_finite() {
            return None;
        }
        bw[j] = match data.types[j] {
            ColumnType::Continuous => data.continuous_scales[j] * theta[j].exp(),
            ColumnType::Unordered => {
                unordered_kernel_for_col(*ukernel_codes_by_col.get(j)?)?;
                sigmoid(theta[j])
            }
            ColumnType::Ordered => sigmoid(theta[j]),
        };
        if !bw[j].is_finite() || bw[j] <= 0.0 {
            return None;
        }
    }
    Some(bw)
}

#[cfg(kdml_cuda)]
fn log_posterior_cuda_f32_columns(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    ckernel_codes_by_col: &[i32],
    ukernel_codes_by_col: &[i32],
    okernel_codes_by_col: &[i32],
    theta: &[f64],
    bw: &[f64],
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    log_model_count: f64,
) -> Result<CudaF32LogPost, i32> {
    if ckernel_codes_by_col.len() < data.p
        || ukernel_codes_by_col.len() < data.p
        || okernel_codes_by_col.len() < data.p
        || !valid_bandwidths_column_kernels(data, ukernel_codes_by_col, bw)
    {
        return Ok(CudaF32LogPost {
            score: f32::NEG_INFINITY,
            log_post: f64::NEG_INFINITY,
        });
    }

    let bw_f32: Vec<f32> = bw.iter().map(|&value| value as f32).collect();
    let score = cuda
        .score_f32_with_column_kernels(
            &bw_f32,
            distance_code,
            ckernel_codes_by_col,
            ukernel_codes_by_col,
            okernel_codes_by_col,
        )
        .map_err(|_| -30)?;
    if !score.is_finite() {
        return Ok(CudaF32LogPost {
            score,
            log_post: f64::NEG_INFINITY,
        });
    }

    let log_prior = log_normal_sum(theta, prior_mu, prior_sd);
    if !log_prior.is_finite() {
        return Ok(CudaF32LogPost {
            score,
            log_post: f64::NEG_INFINITY,
        });
    }

    Ok(CudaF32LogPost {
        score,
        log_post: beta * score as f64 - log_model_count + log_prior,
    })
}

#[cfg(kdml_cuda)]
#[allow(dead_code)]
fn propose_type_bandwidth_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    c_slot: KernelSlot<ContinuousKernel>,
    u_slot: KernelSlot<UnorderedKernel>,
    o_slot: KernelSlot<OrderedKernel>,
    bw: &mut [f64],
    current: &mut CudaF32LogPost,
    target_type: ColumnType,
    beta: f64,
    proposal_sd: f64,
    prior_mu: f64,
    prior_sd: f64,
    model_count: usize,
    rng: &mut Rng64,
) -> Result<bool, i32> {
    let mut proposal_theta = bandwidth_to_theta(data, u_slot.kernel, bw);
    for j in 0..data.p {
        if std::mem::discriminant(&data.types[j]) == std::mem::discriminant(&target_type) {
            proposal_theta[j] += proposal_sd * rng.normal();
        }
    }
    let proposal_bw = theta_to_bandwidth(data, u_slot.kernel, &proposal_theta);
    let proposal = log_posterior_cuda_f32(
        cuda,
        data,
        distance_code,
        c_slot.code,
        u_slot.code,
        o_slot.code,
        u_slot.kernel,
        &proposal_bw,
        beta,
        prior_mu,
        prior_sd,
        model_count,
    )?;
    let log_alpha = proposal.log_post - current.log_post;
    if log_alpha.is_finite() && rng.uniform().ln() < log_alpha {
        bw.copy_from_slice(&proposal_bw);
        *current = proposal;
        Ok(true)
    } else {
        Ok(false)
    }
}

#[cfg(kdml_cuda)]
#[allow(dead_code)]
fn propose_type_bandwidth_cuda_f32_columns(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    ckernel_codes_by_col: &[i32],
    ukernel_codes_by_col: &[i32],
    okernel_codes_by_col: &[i32],
    bw: &mut [f64],
    current: &mut CudaF32LogPost,
    target_type: ColumnType,
    beta: f64,
    proposal_sd: f64,
    prior_mu: f64,
    prior_sd: f64,
    log_model_count: f64,
    rng: &mut Rng64,
) -> Result<bool, i32> {
    let Some(mut proposal_theta) =
        bandwidth_to_theta_column_kernels(data, ukernel_codes_by_col, bw)
    else {
        return Err(-12);
    };
    for j in 0..data.p {
        if data.types[j] == target_type {
            proposal_theta[j] += proposal_sd * rng.normal();
        }
    }
    let Some(proposal_bw) =
        theta_to_bandwidth_column_kernels(data, ukernel_codes_by_col, &proposal_theta)
    else {
        return Err(-12);
    };
    let proposal = log_posterior_cuda_f32_columns(
        cuda,
        data,
        distance_code,
        ckernel_codes_by_col,
        ukernel_codes_by_col,
        okernel_codes_by_col,
        &proposal_theta,
        &proposal_bw,
        beta,
        prior_mu,
        prior_sd,
        log_model_count,
    )?;
    let log_alpha = proposal.log_post - current.log_post;
    if log_alpha.is_finite() && rng.uniform().ln() < log_alpha {
        bw.copy_from_slice(&proposal_bw);
        *current = proposal;
        Ok(true)
    } else {
        Ok(false)
    }
}

#[cfg(kdml_cuda)]
#[allow(dead_code)]
fn sample_continuous_column_kernel_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    target_col: usize,
    c_slots: &[KernelSlot<ContinuousKernel>],
    ckernel_codes_by_col: &mut [i32],
    ukernel_codes_by_col: &[i32],
    okernel_codes_by_col: &[i32],
    bw: &[f64],
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    log_model_count: f64,
    rng: &mut Rng64,
    log_w: &mut [f64],
) -> Result<CudaF32LogPost, i32> {
    let old_code = ckernel_codes_by_col[target_col];
    let mut posts = Vec::with_capacity(c_slots.len());
    for (idx, slot) in c_slots.iter().enumerate() {
        ckernel_codes_by_col[target_col] = slot.code;
        let post = log_posterior_cuda_f32_columns(
            cuda,
            data,
            distance_code,
            ckernel_codes_by_col,
            ukernel_codes_by_col,
            okernel_codes_by_col,
            &bandwidth_to_theta_column_kernels(data, ukernel_codes_by_col, bw).ok_or(-12)?,
            bw,
            beta,
            prior_mu,
            prior_sd,
            log_model_count,
        )?;
        log_w[idx] = post.log_post;
        posts.push(post);
    }
    ckernel_codes_by_col[target_col] = old_code;
    let active = sample_log_weights(&mut log_w[..c_slots.len()], rng)?;
    ckernel_codes_by_col[target_col] = c_slots[active].code;
    Ok(posts[active])
}

#[cfg(kdml_cuda)]
#[allow(dead_code)]
fn sample_unordered_column_kernel_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    target_col: usize,
    u_slots: &[KernelSlot<UnorderedKernel>],
    ckernel_codes_by_col: &[i32],
    ukernel_codes_by_col: &mut [i32],
    okernel_codes_by_col: &[i32],
    bw: &[f64],
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    log_model_count: f64,
    rng: &mut Rng64,
    log_w: &mut [f64],
) -> Result<CudaF32LogPost, i32> {
    let old_code = ukernel_codes_by_col[target_col];
    let mut posts = Vec::with_capacity(u_slots.len());
    for (idx, slot) in u_slots.iter().enumerate() {
        ukernel_codes_by_col[target_col] = slot.code;
        let post = log_posterior_cuda_f32_columns(
            cuda,
            data,
            distance_code,
            ckernel_codes_by_col,
            ukernel_codes_by_col,
            okernel_codes_by_col,
            &bandwidth_to_theta_column_kernels(data, ukernel_codes_by_col, bw).ok_or(-12)?,
            bw,
            beta,
            prior_mu,
            prior_sd,
            log_model_count,
        )?;
        log_w[idx] = post.log_post;
        posts.push(post);
    }
    ukernel_codes_by_col[target_col] = old_code;
    let active = sample_log_weights(&mut log_w[..u_slots.len()], rng)?;
    ukernel_codes_by_col[target_col] = u_slots[active].code;
    Ok(posts[active])
}

#[cfg(kdml_cuda)]
#[allow(dead_code)]
fn sample_ordered_column_kernel_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    target_col: usize,
    o_slots: &[KernelSlot<OrderedKernel>],
    ckernel_codes_by_col: &[i32],
    ukernel_codes_by_col: &[i32],
    okernel_codes_by_col: &mut [i32],
    bw: &[f64],
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    log_model_count: f64,
    rng: &mut Rng64,
    log_w: &mut [f64],
) -> Result<CudaF32LogPost, i32> {
    let old_code = okernel_codes_by_col[target_col];
    let mut posts = Vec::with_capacity(o_slots.len());
    for (idx, slot) in o_slots.iter().enumerate() {
        okernel_codes_by_col[target_col] = slot.code;
        let post = log_posterior_cuda_f32_columns(
            cuda,
            data,
            distance_code,
            ckernel_codes_by_col,
            ukernel_codes_by_col,
            okernel_codes_by_col,
            &bandwidth_to_theta_column_kernels(data, ukernel_codes_by_col, bw).ok_or(-12)?,
            bw,
            beta,
            prior_mu,
            prior_sd,
            log_model_count,
        )?;
        log_w[idx] = post.log_post;
        posts.push(post);
    }
    okernel_codes_by_col[target_col] = old_code;
    let active = sample_log_weights(&mut log_w[..o_slots.len()], rng)?;
    okernel_codes_by_col[target_col] = o_slots[active].code;
    Ok(posts[active])
}

#[cfg(any())]
fn log_normal_density(value: f64, mean: f64, sd: f64) -> f64 {
    if !value.is_finite() || !mean.is_finite() || !sd.is_finite() || sd <= 0.0 {
        return f64::NEG_INFINITY;
    }
    let z = (value - mean) / sd;
    -0.5 * (2.0 * PI).ln() - sd.ln() - 0.5 * z * z
}

#[cfg(any())]
fn fill_product_space_params<K: Copy>(
    slots: &[KernelSlot<K>],
    grid_codes: &[i32],
    init_theta: &[f64],
    k_count: usize,
    p: usize,
    prior_sd: f64,
    theta: &mut [f64],
    mu: &mut [f64],
    sd: &mut [f64],
) -> Result<(), i32> {
    for (slot_idx, slot) in slots.iter().enumerate() {
        let model_idx = grid_codes
            .iter()
            .position(|&code| code == slot.code)
            .ok_or(-7)?;
        for j in 0..p {
            let value = init_theta[theta_idx(model_idx, j, k_count)];
            let idx = theta_idx(slot_idx, j, slots.len());
            theta[idx] = value;
            mu[idx] = value;
            sd[idx] = prior_sd;
        }
    }
    Ok(())
}

#[cfg(any())]
fn active_theta_from_product_space(
    data: &KdmlData<'_>,
    active_c_by_col: &[usize],
    active_u_by_col: &[usize],
    active_o_by_col: &[usize],
    c_theta: &[f64],
    u_theta: &[f64],
    o_theta: &[f64],
    c_count: usize,
    u_count: usize,
    o_count: usize,
) -> Vec<f64> {
    let mut theta = vec![0.0; data.p];
    for j in 0..data.p {
        theta[j] = match data.types[j] {
            ColumnType::Continuous => c_theta[theta_idx(active_c_by_col[j], j, c_count)],
            ColumnType::Unordered => u_theta[theta_idx(active_u_by_col[j], j, u_count)],
            ColumnType::Ordered => o_theta[theta_idx(active_o_by_col[j], j, o_count)],
        };
    }
    theta
}

#[cfg(kdml_cuda)]
fn active_kernel_codes_from_product_space(
    data: &KdmlData<'_>,
    c_slots: &[KernelSlot<ContinuousKernel>],
    u_slots: &[KernelSlot<UnorderedKernel>],
    o_slots: &[KernelSlot<OrderedKernel>],
    active_c_by_col: &[usize],
    active_u_by_col: &[usize],
    active_o_by_col: &[usize],
) -> (Vec<i32>, Vec<i32>, Vec<i32>) {
    let mut c_codes = vec![0; data.p];
    let mut u_codes = vec![0; data.p];
    let mut o_codes = vec![0; data.p];
    for j in 0..data.p {
        match data.types[j] {
            ColumnType::Continuous => c_codes[j] = c_slots[active_c_by_col[j]].code,
            ColumnType::Unordered => u_codes[j] = u_slots[active_u_by_col[j]].code,
            ColumnType::Ordered => o_codes[j] = o_slots[active_o_by_col[j]].code,
        }
    }
    (c_codes, u_codes, o_codes)
}

#[cfg(any())]
fn log_posterior_product_space_state(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    c_slots: &[KernelSlot<ContinuousKernel>],
    u_slots: &[KernelSlot<UnorderedKernel>],
    o_slots: &[KernelSlot<OrderedKernel>],
    active_c_by_col: &[usize],
    active_u_by_col: &[usize],
    active_o_by_col: &[usize],
    c_theta: &[f64],
    u_theta: &[f64],
    o_theta: &[f64],
    log_model_count: f64,
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
) -> Result<
    (
        CudaF32LogPost,
        Vec<f64>,
        Vec<f64>,
        Vec<i32>,
        Vec<i32>,
        Vec<i32>,
    ),
    i32,
> {
    let (c_codes, u_codes, o_codes) = active_kernel_codes_from_product_space(
        data,
        c_slots,
        u_slots,
        o_slots,
        active_c_by_col,
        active_u_by_col,
        active_o_by_col,
    );
    let theta = active_theta_from_product_space(
        data,
        active_c_by_col,
        active_u_by_col,
        active_o_by_col,
        c_theta,
        u_theta,
        o_theta,
        c_slots.len(),
        u_slots.len(),
        o_slots.len(),
    );
    let bw = theta_to_bandwidth_column_kernels(data, &u_codes, &theta).ok_or(-12)?;
    let post = log_posterior_cuda_f32_columns(
        cuda,
        data,
        distance_code,
        &c_codes,
        &u_codes,
        &o_codes,
        &theta,
        &bw,
        beta,
        prior_mu,
        prior_sd,
        log_model_count,
    )?;
    Ok((post, theta, bw, c_codes, u_codes, o_codes))
}

#[cfg(any())]
fn refresh_inactive_product_space_thetas(
    data: &KdmlData<'_>,
    active_c_by_col: &[usize],
    active_u_by_col: &[usize],
    active_o_by_col: &[usize],
    c_theta: &mut [f64],
    u_theta: &mut [f64],
    o_theta: &mut [f64],
    c_mu: &[f64],
    u_mu: &[f64],
    o_mu: &[f64],
    c_sd: &[f64],
    u_sd: &[f64],
    o_sd: &[f64],
    c_count: usize,
    u_count: usize,
    o_count: usize,
    rng: &mut Rng64,
) {
    for j in 0..data.p {
        match data.types[j] {
            ColumnType::Continuous => {
                for k in 0..c_count {
                    if k != active_c_by_col[j] {
                        let idx = theta_idx(k, j, c_count);
                        c_theta[idx] = c_mu[idx] + c_sd[idx] * rng.normal();
                    }
                }
            }
            ColumnType::Unordered => {
                for k in 0..u_count {
                    if k != active_u_by_col[j] {
                        let idx = theta_idx(k, j, u_count);
                        u_theta[idx] = u_mu[idx] + u_sd[idx] * rng.normal();
                    }
                }
            }
            ColumnType::Ordered => {
                for k in 0..o_count {
                    if k != active_o_by_col[j] {
                        let idx = theta_idx(k, j, o_count);
                        o_theta[idx] = o_mu[idx] + o_sd[idx] * rng.normal();
                    }
                }
            }
        }
    }
}

#[cfg(any())]
fn sample_continuous_kernel_product_space_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    target_col: usize,
    c_slots: &[KernelSlot<ContinuousKernel>],
    u_slots: &[KernelSlot<UnorderedKernel>],
    o_slots: &[KernelSlot<OrderedKernel>],
    active_c_by_col: &mut [usize],
    active_u_by_col: &[usize],
    active_o_by_col: &[usize],
    c_theta: &[f64],
    u_theta: &[f64],
    o_theta: &[f64],
    c_mu: &[f64],
    c_sd: &[f64],
    log_model_count: f64,
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    rng: &mut Rng64,
    log_w: &mut [f64],
) -> Result<CudaF32LogPost, i32> {
    let old_active = active_c_by_col[target_col];
    let mut posts = Vec::with_capacity(c_slots.len());
    for k in 0..c_slots.len() {
        active_c_by_col[target_col] = k;
        let (post, _, _, _, _, _) = log_posterior_product_space_state(
            cuda,
            data,
            distance_code,
            c_slots,
            u_slots,
            o_slots,
            active_c_by_col,
            active_u_by_col,
            active_o_by_col,
            c_theta,
            u_theta,
            o_theta,
            log_model_count,
            beta,
            prior_mu,
            prior_sd,
        )?;
        let idx = theta_idx(k, target_col, c_slots.len());
        log_w[k] = post.log_post - log_normal_density(c_theta[idx], c_mu[idx], c_sd[idx]);
        posts.push(post);
    }
    active_c_by_col[target_col] = old_active;
    let active = sample_log_weights(&mut log_w[..c_slots.len()], rng)?;
    active_c_by_col[target_col] = active;
    Ok(posts[active])
}

#[cfg(any())]
fn sample_unordered_kernel_product_space_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    target_col: usize,
    c_slots: &[KernelSlot<ContinuousKernel>],
    u_slots: &[KernelSlot<UnorderedKernel>],
    o_slots: &[KernelSlot<OrderedKernel>],
    active_c_by_col: &[usize],
    active_u_by_col: &mut [usize],
    active_o_by_col: &[usize],
    c_theta: &[f64],
    u_theta: &[f64],
    o_theta: &[f64],
    u_mu: &[f64],
    u_sd: &[f64],
    log_model_count: f64,
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    rng: &mut Rng64,
    log_w: &mut [f64],
) -> Result<CudaF32LogPost, i32> {
    let old_active = active_u_by_col[target_col];
    let mut posts = Vec::with_capacity(u_slots.len());
    for k in 0..u_slots.len() {
        active_u_by_col[target_col] = k;
        let (post, _, _, _, _, _) = log_posterior_product_space_state(
            cuda,
            data,
            distance_code,
            c_slots,
            u_slots,
            o_slots,
            active_c_by_col,
            active_u_by_col,
            active_o_by_col,
            c_theta,
            u_theta,
            o_theta,
            log_model_count,
            beta,
            prior_mu,
            prior_sd,
        )?;
        let idx = theta_idx(k, target_col, u_slots.len());
        log_w[k] = post.log_post - log_normal_density(u_theta[idx], u_mu[idx], u_sd[idx]);
        posts.push(post);
    }
    active_u_by_col[target_col] = old_active;
    let active = sample_log_weights(&mut log_w[..u_slots.len()], rng)?;
    active_u_by_col[target_col] = active;
    Ok(posts[active])
}

#[cfg(any())]
fn sample_ordered_kernel_product_space_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    target_col: usize,
    c_slots: &[KernelSlot<ContinuousKernel>],
    u_slots: &[KernelSlot<UnorderedKernel>],
    o_slots: &[KernelSlot<OrderedKernel>],
    active_c_by_col: &[usize],
    active_u_by_col: &[usize],
    active_o_by_col: &mut [usize],
    c_theta: &[f64],
    u_theta: &[f64],
    o_theta: &[f64],
    o_mu: &[f64],
    o_sd: &[f64],
    log_model_count: f64,
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    rng: &mut Rng64,
    log_w: &mut [f64],
) -> Result<CudaF32LogPost, i32> {
    let old_active = active_o_by_col[target_col];
    let mut posts = Vec::with_capacity(o_slots.len());
    for k in 0..o_slots.len() {
        active_o_by_col[target_col] = k;
        let (post, _, _, _, _, _) = log_posterior_product_space_state(
            cuda,
            data,
            distance_code,
            c_slots,
            u_slots,
            o_slots,
            active_c_by_col,
            active_u_by_col,
            active_o_by_col,
            c_theta,
            u_theta,
            o_theta,
            log_model_count,
            beta,
            prior_mu,
            prior_sd,
        )?;
        let idx = theta_idx(k, target_col, o_slots.len());
        log_w[k] = post.log_post - log_normal_density(o_theta[idx], o_mu[idx], o_sd[idx]);
        posts.push(post);
    }
    active_o_by_col[target_col] = old_active;
    let active = sample_log_weights(&mut log_w[..o_slots.len()], rng)?;
    active_o_by_col[target_col] = active;
    Ok(posts[active])
}

#[cfg(any())]
fn propose_type_bandwidth_product_space_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    c_slots: &[KernelSlot<ContinuousKernel>],
    u_slots: &[KernelSlot<UnorderedKernel>],
    o_slots: &[KernelSlot<OrderedKernel>],
    active_c_by_col: &[usize],
    active_u_by_col: &[usize],
    active_o_by_col: &[usize],
    c_theta: &mut [f64],
    u_theta: &mut [f64],
    o_theta: &mut [f64],
    current: &mut CudaF32LogPost,
    target_type: ColumnType,
    log_model_count: f64,
    beta: f64,
    proposal_sd: f64,
    prior_mu: f64,
    prior_sd: f64,
    rng: &mut Rng64,
) -> Result<bool, i32> {
    let mut proposal_c = c_theta.to_vec();
    let mut proposal_u = u_theta.to_vec();
    let mut proposal_o = o_theta.to_vec();
    for j in 0..data.p {
        match data.types[j] {
            ColumnType::Continuous if target_type == ColumnType::Continuous => {
                let idx = theta_idx(active_c_by_col[j], j, c_slots.len());
                proposal_c[idx] += proposal_sd * rng.normal();
            }
            ColumnType::Unordered if target_type == ColumnType::Unordered => {
                let idx = theta_idx(active_u_by_col[j], j, u_slots.len());
                proposal_u[idx] += proposal_sd * rng.normal();
            }
            ColumnType::Ordered if target_type == ColumnType::Ordered => {
                let idx = theta_idx(active_o_by_col[j], j, o_slots.len());
                proposal_o[idx] += proposal_sd * rng.normal();
            }
            _ => {}
        }
    }

    let (proposal, _, _, _, _, _) = log_posterior_product_space_state(
        cuda,
        data,
        distance_code,
        c_slots,
        u_slots,
        o_slots,
        active_c_by_col,
        active_u_by_col,
        active_o_by_col,
        &proposal_c,
        &proposal_u,
        &proposal_o,
        log_model_count,
        beta,
        prior_mu,
        prior_sd,
    )?;
    let log_alpha = proposal.log_post - current.log_post;
    if log_alpha.is_finite() && rng.uniform().ln() < log_alpha {
        c_theta.copy_from_slice(&proposal_c);
        u_theta.copy_from_slice(&proposal_u);
        o_theta.copy_from_slice(&proposal_o);
        *current = proposal;
        Ok(true)
    } else {
        Ok(false)
    }
}

#[cfg(kdml_cuda)]
fn log_posterior_mh_switch_state(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    c_slots: &[KernelSlot<ContinuousKernel>],
    u_slots: &[KernelSlot<UnorderedKernel>],
    o_slots: &[KernelSlot<OrderedKernel>],
    active_c_by_col: &[usize],
    active_u_by_col: &[usize],
    active_o_by_col: &[usize],
    theta: &[f64],
    log_model_count: f64,
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
) -> Result<(CudaF32LogPost, Vec<f64>, Vec<i32>, Vec<i32>, Vec<i32>), i32> {
    let (c_codes, u_codes, o_codes) = active_kernel_codes_from_product_space(
        data,
        c_slots,
        u_slots,
        o_slots,
        active_c_by_col,
        active_u_by_col,
        active_o_by_col,
    );
    let bw = theta_to_bandwidth_column_kernels(data, &u_codes, theta).ok_or(-12)?;
    let post = log_posterior_cuda_f32_columns(
        cuda,
        data,
        distance_code,
        &c_codes,
        &u_codes,
        &o_codes,
        theta,
        &bw,
        beta,
        prior_mu,
        prior_sd,
        log_model_count,
    )?;
    Ok((post, bw, c_codes, u_codes, o_codes))
}

#[cfg(kdml_cuda)]
fn propose_distinct_slot(count: usize, active: usize, rng: &mut Rng64) -> Option<usize> {
    if count <= 1 {
        return None;
    }
    let draw = (rng.uniform() * (count - 1) as f64).floor() as usize;
    Some(if draw >= active { draw + 1 } else { draw })
}

#[cfg(kdml_cuda)]
fn invalid_candidate_is_rejection<T>(
    result: Result<T, i32>,
    invalid_proposals: &mut usize,
) -> Result<Option<T>, i32> {
    match result {
        Ok(value) => Ok(Some(value)),
        Err(-12) => {
            *invalid_proposals += 1;
            Ok(None)
        }
        Err(code) => Err(code),
    }
}

#[cfg(kdml_cuda)]
fn sample_continuous_kernel_mh_switch_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    target_col: usize,
    c_slots: &[KernelSlot<ContinuousKernel>],
    u_slots: &[KernelSlot<UnorderedKernel>],
    o_slots: &[KernelSlot<OrderedKernel>],
    active_c_by_col: &mut [usize],
    active_u_by_col: &[usize],
    active_o_by_col: &[usize],
    theta: &[f64],
    current: &mut CudaF32LogPost,
    log_model_count: f64,
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    rng: &mut Rng64,
    invalid_proposals: &mut usize,
) -> Result<bool, i32> {
    let old_active = active_c_by_col[target_col];
    let Some(new_active) = propose_distinct_slot(c_slots.len(), old_active, rng) else {
        return Ok(false);
    };
    let mut proposal_active = active_c_by_col.to_vec();
    proposal_active[target_col] = new_active;
    let Some((proposal, _, _, _, _)) = invalid_candidate_is_rejection(
        log_posterior_mh_switch_state(
            cuda,
            data,
            distance_code,
            c_slots,
            u_slots,
            o_slots,
            &proposal_active,
            active_u_by_col,
            active_o_by_col,
            theta,
            log_model_count,
            beta,
            prior_mu,
            prior_sd,
        ),
        invalid_proposals,
    )?
    else {
        return Ok(false);
    };

    if !proposal.score.is_finite() || !proposal.log_post.is_finite() {
        *invalid_proposals += 1;
        return Ok(false);
    }
    let log_alpha = proposal.log_post - current.log_post;
    if log_alpha.is_finite() && rng.uniform().ln() < log_alpha {
        active_c_by_col.copy_from_slice(&proposal_active);
        *current = proposal;
        Ok(true)
    } else {
        Ok(false)
    }
}

#[cfg(kdml_cuda)]
fn sample_unordered_kernel_mh_switch_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    target_col: usize,
    c_slots: &[KernelSlot<ContinuousKernel>],
    u_slots: &[KernelSlot<UnorderedKernel>],
    o_slots: &[KernelSlot<OrderedKernel>],
    active_c_by_col: &[usize],
    active_u_by_col: &mut [usize],
    active_o_by_col: &[usize],
    theta: &[f64],
    current: &mut CudaF32LogPost,
    log_model_count: f64,
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    rng: &mut Rng64,
    invalid_proposals: &mut usize,
) -> Result<bool, i32> {
    let old_active = active_u_by_col[target_col];
    let Some(new_active) = propose_distinct_slot(u_slots.len(), old_active, rng) else {
        return Ok(false);
    };
    let mut proposal_active = active_u_by_col.to_vec();
    proposal_active[target_col] = new_active;
    let Some((proposal, _, _, _, _)) = invalid_candidate_is_rejection(
        log_posterior_mh_switch_state(
            cuda,
            data,
            distance_code,
            c_slots,
            u_slots,
            o_slots,
            active_c_by_col,
            &proposal_active,
            active_o_by_col,
            theta,
            log_model_count,
            beta,
            prior_mu,
            prior_sd,
        ),
        invalid_proposals,
    )?
    else {
        return Ok(false);
    };

    if !proposal.score.is_finite() || !proposal.log_post.is_finite() {
        *invalid_proposals += 1;
        return Ok(false);
    }
    let log_alpha = proposal.log_post - current.log_post;
    if log_alpha.is_finite() && rng.uniform().ln() < log_alpha {
        active_u_by_col.copy_from_slice(&proposal_active);
        *current = proposal;
        Ok(true)
    } else {
        Ok(false)
    }
}

#[cfg(kdml_cuda)]
fn sample_ordered_kernel_mh_switch_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    target_col: usize,
    c_slots: &[KernelSlot<ContinuousKernel>],
    u_slots: &[KernelSlot<UnorderedKernel>],
    o_slots: &[KernelSlot<OrderedKernel>],
    active_c_by_col: &[usize],
    active_u_by_col: &[usize],
    active_o_by_col: &mut [usize],
    theta: &[f64],
    current: &mut CudaF32LogPost,
    log_model_count: f64,
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    rng: &mut Rng64,
    invalid_proposals: &mut usize,
) -> Result<bool, i32> {
    let old_active = active_o_by_col[target_col];
    let Some(new_active) = propose_distinct_slot(o_slots.len(), old_active, rng) else {
        return Ok(false);
    };
    let mut proposal_active = active_o_by_col.to_vec();
    proposal_active[target_col] = new_active;
    let Some((proposal, _, _, _, _)) = invalid_candidate_is_rejection(
        log_posterior_mh_switch_state(
            cuda,
            data,
            distance_code,
            c_slots,
            u_slots,
            o_slots,
            active_c_by_col,
            active_u_by_col,
            &proposal_active,
            theta,
            log_model_count,
            beta,
            prior_mu,
            prior_sd,
        ),
        invalid_proposals,
    )?
    else {
        return Ok(false);
    };

    if !proposal.score.is_finite() || !proposal.log_post.is_finite() {
        *invalid_proposals += 1;
        return Ok(false);
    }
    let log_alpha = proposal.log_post - current.log_post;
    if log_alpha.is_finite() && rng.uniform().ln() < log_alpha {
        active_o_by_col.copy_from_slice(&proposal_active);
        *current = proposal;
        Ok(true)
    } else {
        Ok(false)
    }
}

#[cfg(kdml_cuda)]
#[allow(dead_code)]
fn propose_type_bandwidth_mh_switch_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    c_slots: &[KernelSlot<ContinuousKernel>],
    u_slots: &[KernelSlot<UnorderedKernel>],
    o_slots: &[KernelSlot<OrderedKernel>],
    active_c_by_col: &[usize],
    active_u_by_col: &[usize],
    active_o_by_col: &[usize],
    theta: &mut [f64],
    current: &mut CudaF32LogPost,
    target_type: ColumnType,
    log_model_count: f64,
    beta: f64,
    proposal_sd: f64,
    prior_mu: f64,
    prior_sd: f64,
    rng: &mut Rng64,
    invalid_proposals: &mut usize,
) -> Result<bool, i32> {
    let mut proposal_theta = theta.to_vec();
    for j in 0..data.p {
        if data.types[j] == target_type {
            proposal_theta[j] += proposal_sd * rng.normal();
        }
    }
    let Some((proposal, _, _, _, _)) = invalid_candidate_is_rejection(
        log_posterior_mh_switch_state(
            cuda,
            data,
            distance_code,
            c_slots,
            u_slots,
            o_slots,
            active_c_by_col,
            active_u_by_col,
            active_o_by_col,
            &proposal_theta,
            log_model_count,
            beta,
            prior_mu,
            prior_sd,
        ),
        invalid_proposals,
    )?
    else {
        return Ok(false);
    };
    if !proposal.score.is_finite() || !proposal.log_post.is_finite() {
        *invalid_proposals += 1;
        return Ok(false);
    }
    let log_alpha = proposal.log_post - current.log_post;
    if log_alpha.is_finite() && rng.uniform().ln() < log_alpha {
        theta.copy_from_slice(&proposal_theta);
        *current = proposal;
        Ok(true)
    } else {
        Ok(false)
    }
}

#[cfg(kdml_cuda)]
fn propose_column_bandwidth_mh_switch_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    c_slots: &[KernelSlot<ContinuousKernel>],
    u_slots: &[KernelSlot<UnorderedKernel>],
    o_slots: &[KernelSlot<OrderedKernel>],
    active_c_by_col: &[usize],
    active_u_by_col: &[usize],
    active_o_by_col: &[usize],
    theta: &mut [f64],
    current: &mut CudaF32LogPost,
    target_col: usize,
    log_model_count: f64,
    beta: f64,
    proposal_sd: f64,
    prior_mu: f64,
    prior_sd: f64,
    rng: &mut Rng64,
    invalid_proposals: &mut usize,
) -> Result<bool, i32> {
    if target_col >= data.p {
        return Err(-7);
    }
    let old_theta = theta[target_col];
    let mut proposal_theta = theta.to_vec();
    proposal_theta[target_col] = old_theta + proposal_sd * rng.normal();
    let Some((proposal, _, _, _, _)) = invalid_candidate_is_rejection(
        log_posterior_mh_switch_state(
            cuda,
            data,
            distance_code,
            c_slots,
            u_slots,
            o_slots,
            active_c_by_col,
            active_u_by_col,
            active_o_by_col,
            &proposal_theta,
            log_model_count,
            beta,
            prior_mu,
            prior_sd,
        ),
        invalid_proposals,
    )?
    else {
        return Ok(false);
    };
    if !proposal.score.is_finite() || !proposal.log_post.is_finite() {
        *invalid_proposals += 1;
        return Ok(false);
    }
    let log_alpha = proposal.log_post - current.log_post;
    if log_alpha.is_finite() && rng.uniform().ln() < log_alpha {
        theta.copy_from_slice(&proposal_theta);
        *current = proposal;
        Ok(true)
    } else {
        Ok(false)
    }
}

#[cfg(kdml_cuda)]
fn column_type_index(column_type: ColumnType) -> usize {
    match column_type {
        ColumnType::Continuous => 0,
        ColumnType::Unordered => 1,
        ColumnType::Ordered => 2,
    }
}

#[cfg(kdml_cuda)]
fn adapt_log_scale(log_scale: &mut f64, count: &mut usize, accepted: bool, target: f64) {
    *count += 1;
    // A conservative diminishing gain avoids the large early scale swings
    // produced by 1/sqrt(t), while still allowing column-specific correction
    // over a typical 500--10,000 iteration warmup.
    let gamma = 0.25 / (*count as f64).powf(0.6);
    let observed = if accepted { 1.0 } else { 0.0 };
    *log_scale += gamma * (observed - target);
    *log_scale = (*log_scale).clamp((1.0e-3_f64).ln(), 10.0_f64.ln());
}

#[cfg(kdml_cuda)]
#[allow(dead_code)]
fn sample_continuous_kernel_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    c_slots: &[KernelSlot<ContinuousKernel>],
    active_u: KernelSlot<UnorderedKernel>,
    active_o: KernelSlot<OrderedKernel>,
    bw: &[f64],
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    model_count: usize,
    rng: &mut Rng64,
    log_w: &mut [f64],
) -> Result<(usize, CudaF32LogPost), i32> {
    let mut posts = Vec::with_capacity(c_slots.len());
    for (idx, slot) in c_slots.iter().enumerate() {
        let post = log_posterior_cuda_f32(
            cuda,
            data,
            distance_code,
            slot.code,
            active_u.code,
            active_o.code,
            active_u.kernel,
            bw,
            beta,
            prior_mu,
            prior_sd,
            model_count,
        )?;
        log_w[idx] = post.log_post;
        posts.push(post);
    }
    let active = sample_log_weights(&mut log_w[..c_slots.len()], rng)?;
    Ok((active, posts.swap_remove(active)))
}

#[cfg(kdml_cuda)]
#[allow(dead_code)]
fn sample_unordered_kernel_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    active_c: KernelSlot<ContinuousKernel>,
    u_slots: &[KernelSlot<UnorderedKernel>],
    active_o: KernelSlot<OrderedKernel>,
    bw: &[f64],
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    model_count: usize,
    rng: &mut Rng64,
    log_w: &mut [f64],
) -> Result<(usize, CudaF32LogPost), i32> {
    let mut posts = Vec::with_capacity(u_slots.len());
    for (idx, slot) in u_slots.iter().enumerate() {
        let post = log_posterior_cuda_f32(
            cuda,
            data,
            distance_code,
            active_c.code,
            slot.code,
            active_o.code,
            slot.kernel,
            bw,
            beta,
            prior_mu,
            prior_sd,
            model_count,
        )?;
        log_w[idx] = post.log_post;
        posts.push(post);
    }
    let active = sample_log_weights(&mut log_w[..u_slots.len()], rng)?;
    Ok((active, posts.swap_remove(active)))
}

#[cfg(kdml_cuda)]
#[allow(dead_code)]
fn sample_ordered_kernel_cuda_f32(
    cuda: &crate::cuda::CudaMscvScore,
    data: &KdmlData<'_>,
    distance_code: i32,
    active_c: KernelSlot<ContinuousKernel>,
    active_u: KernelSlot<UnorderedKernel>,
    o_slots: &[KernelSlot<OrderedKernel>],
    bw: &[f64],
    beta: f64,
    prior_mu: f64,
    prior_sd: f64,
    model_count: usize,
    rng: &mut Rng64,
    log_w: &mut [f64],
) -> Result<(usize, CudaF32LogPost), i32> {
    let mut posts = Vec::with_capacity(o_slots.len());
    for (idx, slot) in o_slots.iter().enumerate() {
        let post = log_posterior_cuda_f32(
            cuda,
            data,
            distance_code,
            active_c.code,
            active_u.code,
            slot.code,
            active_u.kernel,
            bw,
            beta,
            prior_mu,
            prior_sd,
            model_count,
        )?;
        log_w[idx] = post.log_post;
        posts.push(post);
    }
    let active = sample_log_weights(&mut log_w[..o_slots.len()], rng)?;
    Ok((active, posts.swap_remove(active)))
}

#[cfg(any())]
fn run_mcmc_block_cuda_f32_alloc_with_progress(
    n: usize,
    p: usize,
    k_count: usize,
    data_values: &[f64],
    type_codes: &[i32],
    distance_code: i32,
    kernel_codes: &[i32],
    ukernel_codes: &[i32],
    okernel_codes: &[i32],
    init_theta: &[f64],
    n_iter: usize,
    beta: f64,
    proposal_sd: f64,
    active_init: usize,
    prior_mu: f64,
    prior_sd: f64,
    seed: u64,
    score_version: ScoreVersion,
    mut progress: Option<&mut dyn FnMut(usize)>,
) -> Result<ChainRunOutput, i32> {
    let data = KdmlData::new(n, p, data_values, type_codes).ok_or(-2)?;
    DistanceType::from_code(distance_code).ok_or(-3)?;
    if kernel_codes.len() < k_count
        || ukernel_codes.len() < k_count
        || okernel_codes.len() < k_count
        || init_theta.len() < k_count * p
        || active_init == 0
        || active_init > k_count
    {
        return Err(-7);
    }
    if !proposal_sd.is_finite() || proposal_sd <= 0.0 || !prior_sd.is_finite() || prior_sd <= 0.0 {
        return Err(-8);
    }

    let kernel_codes = &kernel_codes[..k_count];
    let ukernel_codes = &ukernel_codes[..k_count];
    let okernel_codes = &okernel_codes[..k_count];
    let c_slots = unique_continuous_slots(kernel_codes).ok_or(-6)?;
    let u_slots = unique_unordered_slots(ukernel_codes).ok_or(-4)?;
    let o_slots = unique_ordered_slots(okernel_codes).ok_or(-5)?;
    if c_slots.is_empty() || u_slots.is_empty() || o_slots.is_empty() {
        return Err(-7);
    }

    let init_model = active_init - 1;
    let active_c_init = c_slots
        .iter()
        .position(|slot| slot.code == kernel_codes[init_model])
        .ok_or(-7)?;
    let active_u_init = u_slots
        .iter()
        .position(|slot| slot.code == ukernel_codes[init_model])
        .ok_or(-7)?;
    let active_o_init = o_slots
        .iter()
        .position(|slot| slot.code == okernel_codes[init_model])
        .ok_or(-7)?;
    let mut active_c_by_col = vec![active_c_init; p];
    let mut active_u_by_col = vec![active_u_init; p];
    let mut active_o_by_col = vec![active_o_init; p];
    for j in 0..p {
        match data.types[j] {
            ColumnType::Continuous => {
                active_u_by_col[j] = 0;
                active_o_by_col[j] = 0;
            }
            ColumnType::Unordered => {
                active_c_by_col[j] = 0;
                active_o_by_col[j] = 0;
            }
            ColumnType::Ordered => {
                active_c_by_col[j] = 0;
                active_u_by_col[j] = 0;
            }
        }
    }

    let c_count = c_slots.len();
    let u_count = u_slots.len();
    let o_count = o_slots.len();
    let mut c_theta = vec![0.0; c_count * p];
    let mut u_theta = vec![0.0; u_count * p];
    let mut o_theta = vec![0.0; o_count * p];
    let mut c_mu = vec![0.0; c_count * p];
    let mut u_mu = vec![0.0; u_count * p];
    let mut o_mu = vec![0.0; o_count * p];
    let mut c_sd = vec![1.0; c_count * p];
    let mut u_sd = vec![1.0; u_count * p];
    let mut o_sd = vec![1.0; o_count * p];
    fill_product_space_params(
        &c_slots,
        kernel_codes,
        init_theta,
        k_count,
        p,
        prior_sd,
        &mut c_theta,
        &mut c_mu,
        &mut c_sd,
    )?;
    fill_product_space_params(
        &u_slots,
        ukernel_codes,
        init_theta,
        k_count,
        p,
        prior_sd,
        &mut u_theta,
        &mut u_mu,
        &mut u_sd,
    )?;
    fill_product_space_params(
        &o_slots,
        okernel_codes,
        init_theta,
        k_count,
        p,
        prior_sd,
        &mut o_theta,
        &mut o_mu,
        &mut o_sd,
    )?;

    let cuda = crate::cuda::CudaMscvScore::new_with_score_version(&data, score_version)
        .map_err(|_| -30)?;
    let log_model_count = log_model_count_for_column_kernels(&data, &c_slots, &u_slots, &o_slots);
    let (mut current, _, _, _, _, _) = log_posterior_product_space_state(
        &cuda,
        &data,
        distance_code,
        &c_slots,
        &u_slots,
        &o_slots,
        &active_c_by_col,
        &active_u_by_col,
        &active_o_by_col,
        &c_theta,
        &u_theta,
        &o_theta,
        log_model_count,
        beta,
        prior_mu,
        prior_sd,
    )?;
    if !current.log_post.is_finite() {
        return Err(-12);
    }

    let mut out = ChainRunOutput {
        samples_model: vec![0; n_iter],
        samples_ckernel: vec![0; n_iter * p],
        samples_ukernel: vec![0; n_iter * p],
        samples_okernel: vec![0; n_iter * p],
        samples_theta: vec![0.0; n_iter * p],
        samples_bw: vec![0.0; n_iter * p],
        samples_score: vec![0.0; n_iter],
        samples_log_post: vec![0.0; n_iter],
        accepted: vec![0; n_iter],
        mh_model: vec![0; n_iter],
        acceptance_rate: f64::NAN,
        initialization_attempts: 0,
        initialization_fallback: false,
        invalid_proposals: 0,
        initial_ckernel: Vec::new(),
        initial_ukernel: Vec::new(),
        initial_okernel: Vec::new(),
        initial_theta: Vec::new(),
        initial_score: f64::NAN,
        initial_log_post: f64::NAN,
        final_kernel_proposal_sds: [proposal_sd; 3],
        final_bandwidth_proposal_sds: [proposal_sd; 3],
        final_kernel_proposal_sds_by_col: vec![proposal_sd; p],
        final_bandwidth_proposal_sds_by_col: vec![proposal_sd; p],
        kernel_attempts_by_col: vec![0; p],
        kernel_accepts_by_col: vec![0; p],
        bandwidth_attempts_by_col: vec![0; p],
        bandwidth_accepts_by_col: vec![0; p],
        sampling_kernel_attempts_by_col: vec![0; p],
        sampling_kernel_accepts_by_col: vec![0; p],
        sampling_bandwidth_attempts_by_col: vec![0; p],
        sampling_bandwidth_accepts_by_col: vec![0; p],
    };

    let mut rng = Rng64::new(seed);
    let mut c_log_w = vec![f64::NEG_INFINITY; c_slots.len()];
    let mut u_log_w = vec![f64::NEG_INFINITY; u_slots.len()];
    let mut o_log_w = vec![f64::NEG_INFINITY; o_slots.len()];
    let continuous_cols = type_column_indices(&data, ColumnType::Continuous);
    let unordered_cols = type_column_indices(&data, ColumnType::Unordered);
    let ordered_cols = type_column_indices(&data, ColumnType::Ordered);
    let mut accepted_bw = 0usize;
    let progress_stride = if progress.is_some() {
        (n_iter / 200).max(1)
    } else {
        usize::MAX
    };

    for iter in 0..n_iter {
        refresh_inactive_product_space_thetas(
            &data,
            &active_c_by_col,
            &active_u_by_col,
            &active_o_by_col,
            &mut c_theta,
            &mut u_theta,
            &mut o_theta,
            &c_mu,
            &u_mu,
            &o_mu,
            &c_sd,
            &u_sd,
            &o_sd,
            c_count,
            u_count,
            o_count,
            &mut rng,
        );

        if let Some(col) = sampled_column(&continuous_cols, &mut rng) {
            current = sample_continuous_kernel_product_space_cuda_f32(
                &cuda,
                &data,
                distance_code,
                col,
                &c_slots,
                &u_slots,
                &o_slots,
                &mut active_c_by_col,
                &active_u_by_col,
                &active_o_by_col,
                &c_theta,
                &u_theta,
                &o_theta,
                &c_mu,
                &c_sd,
                log_model_count,
                beta,
                prior_mu,
                prior_sd,
                &mut rng,
                &mut c_log_w,
            )?;
        }

        let mut accepted_mask = 0;
        if propose_type_bandwidth_product_space_cuda_f32(
            &cuda,
            &data,
            distance_code,
            &c_slots,
            &u_slots,
            &o_slots,
            &active_c_by_col,
            &active_u_by_col,
            &active_o_by_col,
            &mut c_theta,
            &mut u_theta,
            &mut o_theta,
            &mut current,
            ColumnType::Continuous,
            log_model_count,
            beta,
            proposal_sd,
            prior_mu,
            prior_sd,
            &mut rng,
        )? {
            accepted_mask |= 1;
            accepted_bw += 1;
        }

        if let Some(col) = sampled_column(&unordered_cols, &mut rng) {
            current = sample_unordered_kernel_product_space_cuda_f32(
                &cuda,
                &data,
                distance_code,
                col,
                &c_slots,
                &u_slots,
                &o_slots,
                &active_c_by_col,
                &mut active_u_by_col,
                &active_o_by_col,
                &c_theta,
                &u_theta,
                &o_theta,
                &u_mu,
                &u_sd,
                log_model_count,
                beta,
                prior_mu,
                prior_sd,
                &mut rng,
                &mut u_log_w,
            )?;
        }

        if propose_type_bandwidth_product_space_cuda_f32(
            &cuda,
            &data,
            distance_code,
            &c_slots,
            &u_slots,
            &o_slots,
            &active_c_by_col,
            &active_u_by_col,
            &active_o_by_col,
            &mut c_theta,
            &mut u_theta,
            &mut o_theta,
            &mut current,
            ColumnType::Unordered,
            log_model_count,
            beta,
            proposal_sd,
            prior_mu,
            prior_sd,
            &mut rng,
        )? {
            accepted_mask |= 2;
            accepted_bw += 1;
        }

        if let Some(col) = sampled_column(&ordered_cols, &mut rng) {
            current = sample_ordered_kernel_product_space_cuda_f32(
                &cuda,
                &data,
                distance_code,
                col,
                &c_slots,
                &u_slots,
                &o_slots,
                &active_c_by_col,
                &active_u_by_col,
                &mut active_o_by_col,
                &c_theta,
                &u_theta,
                &o_theta,
                &o_mu,
                &o_sd,
                log_model_count,
                beta,
                prior_mu,
                prior_sd,
                &mut rng,
                &mut o_log_w,
            )?;
        }

        if propose_type_bandwidth_product_space_cuda_f32(
            &cuda,
            &data,
            distance_code,
            &c_slots,
            &u_slots,
            &o_slots,
            &active_c_by_col,
            &active_u_by_col,
            &active_o_by_col,
            &mut c_theta,
            &mut u_theta,
            &mut o_theta,
            &mut current,
            ColumnType::Ordered,
            log_model_count,
            beta,
            proposal_sd,
            prior_mu,
            prior_sd,
            &mut rng,
        )? {
            accepted_mask |= 4;
            accepted_bw += 1;
        }

        let (
            fresh_current,
            theta,
            bw,
            ckernel_codes_by_col,
            ukernel_codes_by_col,
            okernel_codes_by_col,
        ) = log_posterior_product_space_state(
            &cuda,
            &data,
            distance_code,
            &c_slots,
            &u_slots,
            &o_slots,
            &active_c_by_col,
            &active_u_by_col,
            &active_o_by_col,
            &c_theta,
            &u_theta,
            &o_theta,
            log_model_count,
            beta,
            prior_mu,
            prior_sd,
        )?;
        current = fresh_current;

        let active_model = if ckernel_codes_by_col
            .iter()
            .all(|&code| code == ckernel_codes_by_col[0])
            && ukernel_codes_by_col
                .iter()
                .all(|&code| code == ukernel_codes_by_col[0])
            && okernel_codes_by_col
                .iter()
                .all(|&code| code == okernel_codes_by_col[0])
        {
            first_model_with_codes(
                kernel_codes,
                ukernel_codes,
                okernel_codes,
                ckernel_codes_by_col[0],
                ukernel_codes_by_col[0],
                okernel_codes_by_col[0],
            )
            .map(|idx| (idx + 1) as i32)
            .unwrap_or(0)
        } else {
            0
        };

        out.mh_model[iter] = active_model;
        out.samples_model[iter] = active_model;
        out.samples_score[iter] = current.score as f64;
        out.samples_log_post[iter] = current.log_post;
        out.accepted[iter] = accepted_mask;
        for j in 0..p {
            out.samples_theta[j * n_iter + iter] = theta[j];
            out.samples_bw[j * n_iter + iter] = bw[j];
            out.samples_ckernel[j * n_iter + iter] = ckernel_codes_by_col[j];
            out.samples_ukernel[j * n_iter + iter] = ukernel_codes_by_col[j];
            out.samples_okernel[j * n_iter + iter] = okernel_codes_by_col[j];
        }

        let completed = iter + 1;
        if (completed == 1 || completed == n_iter || completed % progress_stride == 0)
            && progress.is_some()
        {
            if let Some(callback) = progress.as_deref_mut() {
                callback(completed);
            }
        }
    }

    out.acceptance_rate = if n_iter == 0 {
        f64::NAN
    } else {
        accepted_bw as f64 / (3 * n_iter) as f64
    };
    Ok(out)
}

#[cfg(kdml_cuda)]
fn run_mh_switch_cuda_f32_with_progress(
    n: usize,
    p: usize,
    k_count: usize,
    data_values: &[f64],
    type_codes: &[i32],
    distance_code: i32,
    kernel_codes: &[i32],
    ukernel_codes: &[i32],
    okernel_codes: &[i32],
    init_theta: &[f64],
    n_iter: usize,
    adapt_until: usize,
    beta: f64,
    bandwidth_proposal_sd: f64,
    active_init: usize,
    random_init: bool,
    adapt: bool,
    adapt_bandwidth_target: f64,
    prior_mu: f64,
    prior_sd: f64,
    seed: u64,
    score_version: ScoreVersion,
    mut progress: Option<&mut dyn FnMut(usize)>,
) -> Result<ChainRunOutput, i32> {
    let data = KdmlData::new(n, p, data_values, type_codes).ok_or(-2)?;
    DistanceType::from_code(distance_code).ok_or(-3)?;
    if kernel_codes.len() < k_count
        || ukernel_codes.len() < k_count
        || okernel_codes.len() < k_count
        || init_theta.len() < k_count * p
        || active_init == 0
        || active_init > k_count
    {
        return Err(-7);
    }
    if !bandwidth_proposal_sd.is_finite()
        || bandwidth_proposal_sd <= 0.0
        || !prior_sd.is_finite()
        || prior_sd <= 0.0
        || !adapt_bandwidth_target.is_finite()
        || adapt_bandwidth_target <= 0.0
        || adapt_bandwidth_target >= 1.0
    {
        return Err(-8);
    }

    let kernel_codes = &kernel_codes[..k_count];
    let ukernel_codes = &ukernel_codes[..k_count];
    let okernel_codes = &okernel_codes[..k_count];
    let c_slots = unique_continuous_slots(kernel_codes).ok_or(-6)?;
    let u_slots = unique_unordered_slots(ukernel_codes).ok_or(-4)?;
    let o_slots = unique_ordered_slots(okernel_codes).ok_or(-5)?;
    if c_slots.is_empty() || u_slots.is_empty() || o_slots.is_empty() {
        return Err(-7);
    }

    let init_model = active_init - 1;
    let active_c_init = c_slots
        .iter()
        .position(|slot| slot.code == kernel_codes[init_model])
        .ok_or(-7)?;
    let active_u_init = u_slots
        .iter()
        .position(|slot| slot.code == ukernel_codes[init_model])
        .ok_or(-7)?;
    let active_o_init = o_slots
        .iter()
        .position(|slot| slot.code == okernel_codes[init_model])
        .ok_or(-7)?;

    let mut rng = Rng64::new(seed);
    let mut active_c_by_col = vec![active_c_init; p];
    let mut active_u_by_col = vec![active_u_init; p];
    let mut active_o_by_col = vec![active_o_init; p];
    for j in 0..p {
        match data.types[j] {
            ColumnType::Continuous => {
                active_u_by_col[j] = 0;
                active_o_by_col[j] = 0;
            }
            ColumnType::Unordered => {
                active_c_by_col[j] = 0;
                active_o_by_col[j] = 0;
            }
            ColumnType::Ordered => {
                active_c_by_col[j] = 0;
                active_u_by_col[j] = 0;
            }
        }
    }

    let mut theta = vec![0.0; p];
    for j in 0..p {
        theta[j] = init_theta[theta_idx(init_model, j, k_count)];
    }
    let cuda = crate::cuda::CudaMscvScore::new_with_score_version(&data, score_version)
        .map_err(|_| -30)?;
    let log_model_count = log_model_count_for_column_kernels(&data, &c_slots, &u_slots, &o_slots);
    let (anchor_current, _, _, _, _) = log_posterior_mh_switch_state(
        &cuda,
        &data,
        distance_code,
        &c_slots,
        &u_slots,
        &o_slots,
        &active_c_by_col,
        &active_u_by_col,
        &active_o_by_col,
        &theta,
        log_model_count,
        beta,
        prior_mu,
        prior_sd,
    )?;
    if !anchor_current.log_post.is_finite() {
        return Err(-12);
    }

    let anchor_c = active_c_by_col.clone();
    let anchor_u = active_u_by_col.clone();
    let anchor_o = active_o_by_col.clone();
    let anchor_theta = theta.clone();
    let mut current = anchor_current;
    let mut initialization_attempts = 0usize;
    let mut initialization_fallback = false;
    if random_init {
        const MAX_INITIALIZATION_ATTEMPTS: usize = 100;
        let mut initialized = false;
        for attempt in 1..=MAX_INITIALIZATION_ATTEMPTS {
            let mut candidate_c = anchor_c.clone();
            let mut candidate_u = anchor_u.clone();
            let mut candidate_o = anchor_o.clone();
            let mut candidate_theta = anchor_theta.clone();
            let jitter =
                (bandwidth_proposal_sd * 0.5_f64.powf((attempt - 1) as f64 / 25.0)).max(0.01);
            for j in 0..p {
                match data.types[j] {
                    ColumnType::Continuous => {
                        candidate_c[j] = (rng.uniform() * c_slots.len() as f64).floor() as usize;
                        let code = c_slots[candidate_c[j]].code;
                        let model_idx = kernel_codes
                            .iter()
                            .position(|&candidate| candidate == code)
                            .ok_or(-7)?;
                        candidate_theta[j] =
                            init_theta[theta_idx(model_idx, j, k_count)] + jitter * rng.normal();
                    }
                    ColumnType::Unordered => {
                        candidate_u[j] = (rng.uniform() * u_slots.len() as f64).floor() as usize;
                        let code = u_slots[candidate_u[j]].code;
                        let model_idx = ukernel_codes
                            .iter()
                            .position(|&candidate| candidate == code)
                            .ok_or(-7)?;
                        candidate_theta[j] =
                            init_theta[theta_idx(model_idx, j, k_count)] + jitter * rng.normal();
                    }
                    ColumnType::Ordered => {
                        candidate_o[j] = (rng.uniform() * o_slots.len() as f64).floor() as usize;
                        let code = o_slots[candidate_o[j]].code;
                        let model_idx = okernel_codes
                            .iter()
                            .position(|&candidate| candidate == code)
                            .ok_or(-7)?;
                        candidate_theta[j] =
                            init_theta[theta_idx(model_idx, j, k_count)] + jitter * rng.normal();
                    }
                }
            }
            initialization_attempts = attempt;
            match log_posterior_mh_switch_state(
                &cuda,
                &data,
                distance_code,
                &c_slots,
                &u_slots,
                &o_slots,
                &candidate_c,
                &candidate_u,
                &candidate_o,
                &candidate_theta,
                log_model_count,
                beta,
                prior_mu,
                prior_sd,
            ) {
                Ok((candidate_current, _, _, _, _)) if candidate_current.log_post.is_finite() => {
                    active_c_by_col = candidate_c;
                    active_u_by_col = candidate_u;
                    active_o_by_col = candidate_o;
                    theta = candidate_theta;
                    current = candidate_current;
                    initialized = true;
                    break;
                }
                Ok(_) | Err(-12) => continue,
                Err(code) => return Err(code),
            }
        }
        if !initialized {
            active_c_by_col = anchor_c;
            active_u_by_col = anchor_u;
            active_o_by_col = anchor_o;
            theta = anchor_theta;
            current = anchor_current;
            initialization_fallback = true;
        }
    }

    let (_, _, initial_ckernel, initial_ukernel, initial_okernel) = log_posterior_mh_switch_state(
        &cuda,
        &data,
        distance_code,
        &c_slots,
        &u_slots,
        &o_slots,
        &active_c_by_col,
        &active_u_by_col,
        &active_o_by_col,
        &theta,
        log_model_count,
        beta,
        prior_mu,
        prior_sd,
    )?;
    let initial_theta = theta.clone();
    let initial_score = current.score as f64;
    let initial_log_post = current.log_post;

    let mut out = ChainRunOutput {
        samples_model: vec![0; n_iter],
        samples_ckernel: vec![0; n_iter * p],
        samples_ukernel: vec![0; n_iter * p],
        samples_okernel: vec![0; n_iter * p],
        samples_theta: vec![0.0; n_iter * p],
        samples_bw: vec![0.0; n_iter * p],
        samples_score: vec![0.0; n_iter],
        samples_log_post: vec![0.0; n_iter],
        accepted: vec![0; n_iter],
        mh_model: vec![0; n_iter],
        acceptance_rate: f64::NAN,
        initialization_attempts,
        initialization_fallback,
        invalid_proposals: 0,
        initial_ckernel,
        initial_ukernel,
        initial_okernel,
        initial_theta,
        initial_score,
        initial_log_post,
        final_kernel_proposal_sds: [f64::NAN; 3],
        final_bandwidth_proposal_sds: [bandwidth_proposal_sd; 3],
        final_kernel_proposal_sds_by_col: vec![f64::NAN; p],
        final_bandwidth_proposal_sds_by_col: vec![bandwidth_proposal_sd; p],
        kernel_attempts_by_col: vec![0; p],
        kernel_accepts_by_col: vec![0; p],
        bandwidth_attempts_by_col: vec![0; p],
        bandwidth_accepts_by_col: vec![0; p],
        sampling_kernel_attempts_by_col: vec![0; p],
        sampling_kernel_accepts_by_col: vec![0; p],
        sampling_bandwidth_attempts_by_col: vec![0; p],
        sampling_bandwidth_accepts_by_col: vec![0; p],
    };

    let mut accepted_moves = 0usize;
    let mut attempted_moves = 0usize;
    let mut log_bandwidth_sds = vec![bandwidth_proposal_sd.ln(); p];
    let mut bandwidth_adapt_counts = vec![0usize; p];
    let adapt_until = adapt_until.min(n_iter);
    let progress_stride = if progress.is_some() {
        (n_iter / 200).max(1)
    } else {
        usize::MAX
    };

    for iter in 0..n_iter {
        let mut accepted_mask = 0;
        for col in 0..p {
            let bandwidth_sd = log_bandwidth_sds[col].exp();
            let kernel_slot_count = match data.types[col] {
                ColumnType::Continuous => c_slots.len(),
                ColumnType::Unordered => u_slots.len(),
                ColumnType::Ordered => o_slots.len(),
            };
            if kernel_slot_count > 1 {
                attempted_moves += 1;
                out.kernel_attempts_by_col[col] += 1;
                if iter >= adapt_until {
                    out.sampling_kernel_attempts_by_col[col] += 1;
                }
                let kernel_accepted = match data.types[col] {
                    ColumnType::Continuous => {
                        let accepted = sample_continuous_kernel_mh_switch_cuda_f32(
                            &cuda,
                            &data,
                            distance_code,
                            col,
                            &c_slots,
                            &u_slots,
                            &o_slots,
                            &mut active_c_by_col,
                            &active_u_by_col,
                            &active_o_by_col,
                            &mut theta,
                            &mut current,
                            log_model_count,
                            beta,
                            prior_mu,
                            prior_sd,
                            &mut rng,
                            &mut out.invalid_proposals,
                        )?;
                        if accepted {
                            accepted_mask |= 8;
                        }
                        accepted
                    }
                    ColumnType::Unordered => {
                        let accepted = sample_unordered_kernel_mh_switch_cuda_f32(
                            &cuda,
                            &data,
                            distance_code,
                            col,
                            &c_slots,
                            &u_slots,
                            &o_slots,
                            &active_c_by_col,
                            &mut active_u_by_col,
                            &active_o_by_col,
                            &mut theta,
                            &mut current,
                            log_model_count,
                            beta,
                            prior_mu,
                            prior_sd,
                            &mut rng,
                            &mut out.invalid_proposals,
                        )?;
                        if accepted {
                            accepted_mask |= 16;
                        }
                        accepted
                    }
                    ColumnType::Ordered => {
                        let accepted = sample_ordered_kernel_mh_switch_cuda_f32(
                            &cuda,
                            &data,
                            distance_code,
                            col,
                            &c_slots,
                            &u_slots,
                            &o_slots,
                            &active_c_by_col,
                            &active_u_by_col,
                            &mut active_o_by_col,
                            &mut theta,
                            &mut current,
                            log_model_count,
                            beta,
                            prior_mu,
                            prior_sd,
                            &mut rng,
                            &mut out.invalid_proposals,
                        )?;
                        if accepted {
                            accepted_mask |= 32;
                        }
                        accepted
                    }
                };
                if kernel_accepted {
                    accepted_moves += 1;
                    out.kernel_accepts_by_col[col] += 1;
                    if iter >= adapt_until {
                        out.sampling_kernel_accepts_by_col[col] += 1;
                    }
                }
            }

            attempted_moves += 1;
            out.bandwidth_attempts_by_col[col] += 1;
            if iter >= adapt_until {
                out.sampling_bandwidth_attempts_by_col[col] += 1;
            }
            let accepted = propose_column_bandwidth_mh_switch_cuda_f32(
                &cuda,
                &data,
                distance_code,
                &c_slots,
                &u_slots,
                &o_slots,
                &active_c_by_col,
                &active_u_by_col,
                &active_o_by_col,
                &mut theta,
                &mut current,
                col,
                log_model_count,
                beta,
                bandwidth_sd,
                prior_mu,
                prior_sd,
                &mut rng,
                &mut out.invalid_proposals,
            )?;
            if accepted {
                match data.types[col] {
                    ColumnType::Continuous => accepted_mask |= 1,
                    ColumnType::Unordered => accepted_mask |= 2,
                    ColumnType::Ordered => accepted_mask |= 4,
                }
                accepted_moves += 1;
                out.bandwidth_accepts_by_col[col] += 1;
                if iter >= adapt_until {
                    out.sampling_bandwidth_accepts_by_col[col] += 1;
                }
            }
            if adapt && iter < adapt_until {
                adapt_log_scale(
                    &mut log_bandwidth_sds[col],
                    &mut bandwidth_adapt_counts[col],
                    accepted,
                    adapt_bandwidth_target,
                );
            }
        }

        let (fresh_current, bw, ckernel_codes_by_col, ukernel_codes_by_col, okernel_codes_by_col) =
            log_posterior_mh_switch_state(
                &cuda,
                &data,
                distance_code,
                &c_slots,
                &u_slots,
                &o_slots,
                &active_c_by_col,
                &active_u_by_col,
                &active_o_by_col,
                &theta,
                log_model_count,
                beta,
                prior_mu,
                prior_sd,
            )?;
        current = fresh_current;

        let active_model = if ckernel_codes_by_col
            .iter()
            .all(|&code| code == ckernel_codes_by_col[0])
            && ukernel_codes_by_col
                .iter()
                .all(|&code| code == ukernel_codes_by_col[0])
            && okernel_codes_by_col
                .iter()
                .all(|&code| code == okernel_codes_by_col[0])
        {
            first_model_with_codes(
                kernel_codes,
                ukernel_codes,
                okernel_codes,
                ckernel_codes_by_col[0],
                ukernel_codes_by_col[0],
                okernel_codes_by_col[0],
            )
            .map(|idx| (idx + 1) as i32)
            .unwrap_or(0)
        } else {
            0
        };

        out.mh_model[iter] = active_model;
        out.samples_model[iter] = active_model;
        out.samples_score[iter] = current.score as f64;
        out.samples_log_post[iter] = current.log_post;
        out.accepted[iter] = accepted_mask;
        for j in 0..p {
            out.samples_theta[j * n_iter + iter] = theta[j];
            out.samples_bw[j * n_iter + iter] = bw[j];
            out.samples_ckernel[j * n_iter + iter] = ckernel_codes_by_col[j];
            out.samples_ukernel[j * n_iter + iter] = ukernel_codes_by_col[j];
            out.samples_okernel[j * n_iter + iter] = okernel_codes_by_col[j];
        }

        let completed = iter + 1;
        if (completed == 1 || completed == n_iter || completed % progress_stride == 0)
            && progress.is_some()
        {
            if let Some(callback) = progress.as_deref_mut() {
                callback(completed);
            }
        }
    }

    out.acceptance_rate = if attempted_moves == 0 {
        f64::NAN
    } else {
        accepted_moves as f64 / attempted_moves as f64
    };
    for col in 0..p {
        out.final_kernel_proposal_sds_by_col[col] = f64::NAN;
        out.final_bandwidth_proposal_sds_by_col[col] = log_bandwidth_sds[col].exp();
    }
    for type_idx in 0..3 {
        let mut bandwidth_scales = Vec::new();
        for col in 0..p {
            if column_type_index(data.types[col]) == type_idx {
                bandwidth_scales.push(out.final_bandwidth_proposal_sds_by_col[col]);
            }
        }
        if !bandwidth_scales.is_empty() {
            bandwidth_scales.sort_by(f64::total_cmp);
            out.final_kernel_proposal_sds[type_idx] = f64::NAN;
            out.final_bandwidth_proposal_sds[type_idx] =
                bandwidth_scales[bandwidth_scales.len() / 2];
        }
    }
    Ok(out)
}

struct CudaBlockPilotRun {
    summary: CudaBlockPilotSummary,
    mean_theta: Vec<f64>,
}

struct CudaProgressLine {
    label: String,
    total: usize,
    start: Instant,
    last_emit: Instant,
    last_completed: usize,
    display: Arc<CudaProgressDisplay>,
    slot: usize,
}

struct CudaProgressDisplay {
    state: Mutex<CudaProgressDisplayState>,
}

struct CudaProgressDisplayState {
    lines: Vec<String>,
    initialized: bool,
    in_place: bool,
}

impl CudaProgressDisplay {
    fn new(line_count: usize) -> Self {
        Self::with_lines(vec![String::new(); line_count.max(1)])
    }

    fn with_lines(lines: Vec<String>) -> Self {
        let term_is_dumb = std::env::var("TERM")
            .map(|term| term.eq_ignore_ascii_case("dumb"))
            .unwrap_or(false);
        let msys_terminal = std::env::var_os("MSYSTEM").is_some() && !term_is_dumb;
        let force_in_place = std::env::var_os("KDML_PROGRESS_IN_PLACE").is_some();
        Self {
            state: Mutex::new(CudaProgressDisplayState {
                lines: if lines.is_empty() {
                    vec![String::new()]
                } else {
                    lines
                },
                initialized: false,
                in_place: force_in_place || msys_terminal || std::io::stderr().is_terminal(),
            }),
        }
    }

    fn render_initial(&self) {
        match self.state.lock() {
            Ok(mut state) => {
                if state.in_place {
                    state.render();
                }
            }
            Err(_) => {}
        }
    }

    fn update(&self, slot: usize, line: String) {
        match self.state.lock() {
            Ok(mut state) => state.update(slot, line),
            Err(_) => {
                let _ = writeln!(std::io::stderr(), "{line}");
            }
        }
    }
}

impl CudaProgressDisplayState {
    fn update(&mut self, slot: usize, line: String) {
        if slot < self.lines.len() {
            self.lines[slot] = line;
        }
        self.render_line(slot);
    }

    fn render_line(&mut self, slot: usize) {
        let mut stderr = std::io::stderr();
        if !self.in_place {
            let _ = writeln!(stderr, "{}", self.lines[slot.min(self.lines.len() - 1)]);
            return;
        }
        self.render();
    }

    fn render(&mut self) {
        let mut stderr = std::io::stderr();
        if self.initialized {
            let _ = write!(stderr, "\x1B[{}A", self.lines.len());
        } else {
            self.initialized = true;
        }

        for line in &self.lines {
            let _ = write!(stderr, "\r\x1B[2K{}\n", line);
        }
        let _ = stderr.flush();
    }
}

impl CudaProgressLine {
    fn new(label: String, total: usize, display: Arc<CudaProgressDisplay>, slot: usize) -> Self {
        let now = Instant::now();
        let out = Self {
            label,
            total,
            start: now,
            last_emit: now,
            last_completed: 0,
            display,
            slot,
        };
        out.print(0, "running");
        out
    }

    fn tick(&mut self, completed: usize) {
        self.last_completed = completed.min(self.total);
        if self.last_completed >= self.total {
            return;
        }

        let now = Instant::now();
        if now.duration_since(self.last_emit) >= Duration::from_millis(500) {
            self.print(self.last_completed, "running");
            self.last_emit = now;
        }
    }

    fn finish(&mut self) {
        self.print(self.total, "done");
    }

    fn fail(&mut self) {
        self.print(self.last_completed, "failed");
    }

    fn print(&self, completed: usize, status: &str) {
        let line = cuda_progress_line_text(
            &self.label,
            self.total,
            completed,
            self.start.elapsed(),
            status,
        );
        self.display.update(self.slot, line);
    }
}

fn cuda_progress_line_text(
    label: &str,
    total: usize,
    completed: usize,
    elapsed: Duration,
    status: &str,
) -> String {
    let fraction = if total == 0 {
        1.0
    } else {
        completed as f64 / total as f64
    };
    let eta = if completed > 0 && completed < total {
        let elapsed_secs = elapsed.as_secs_f64();
        let remaining_secs = elapsed_secs * (total - completed) as f64 / completed as f64;
        cuda_format_duration(Duration::from_secs_f64(remaining_secs.max(0.0)))
    } else if completed >= total {
        "00:00:00".to_string()
    } else {
        "--:--:--".to_string()
    };
    format!(
        "{}: {:>3.0}%|{}| {}/{} [{}<{}, {:>7}] {}",
        label,
        100.0 * fraction,
        cuda_progress_bar(fraction, 32),
        completed,
        total,
        cuda_format_duration(elapsed),
        eta,
        cuda_format_rate(completed, elapsed),
        status
    )
}

fn cuda_progress_bar(fraction: f64, width: usize) -> String {
    let filled = (fraction.clamp(0.0, 1.0) * width as f64).round() as usize;
    format!(
        "{}{}",
        "#".repeat(filled),
        "-".repeat(width.saturating_sub(filled))
    )
}

fn cuda_format_duration(duration: Duration) -> String {
    let seconds = duration.as_secs();
    let hours = seconds / 3600;
    let minutes = (seconds % 3600) / 60;
    let seconds = seconds % 60;
    format!("{hours:02}:{minutes:02}:{seconds:02}")
}

fn cuda_format_rate(completed: usize, elapsed: Duration) -> String {
    let elapsed_secs = elapsed.as_secs_f64();
    if completed == 0 || elapsed_secs <= 0.0 {
        "--.--it/s".to_string()
    } else {
        format!("{:.2}it/s", completed as f64 / elapsed_secs)
    }
}

fn default_bandwidths(data: &KdmlData<'_>) -> Vec<f64> {
    let mut bw = vec![1.0; data.p];
    for j in 0..data.p {
        bw[j] = match data.types[j] {
            ColumnType::Continuous => data.continuous_scales[j],
            ColumnType::Unordered => 0.35,
            ColumnType::Ordered => 0.45,
        };
    }
    bw
}

fn block_candidate_codes(type_codes: &[i32]) -> (Vec<i32>, Vec<i32>, Vec<i32>) {
    let has_continuous = type_codes.iter().any(|&code| code == 0);
    let has_unordered = type_codes.iter().any(|&code| code == 1);
    let has_ordered = type_codes.iter().any(|&code| code == 2);
    let continuous = if has_continuous {
        vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    } else {
        vec![0]
    };
    let unordered = if has_unordered { vec![0, 1] } else { vec![0] };
    let ordered = if has_ordered {
        vec![0, 1, 2, 3, 4]
    } else {
        vec![0]
    };
    (continuous, unordered, ordered)
}

fn block_model_grid(type_codes: &[i32]) -> (Vec<i32>, Vec<i32>, Vec<i32>) {
    let (continuous, unordered, ordered) = block_candidate_codes(type_codes);
    let mut kernel_codes = Vec::new();
    let mut ukernel_codes = Vec::new();
    let mut okernel_codes = Vec::new();
    for &c_code in &continuous {
        for &u_code in &unordered {
            for &o_code in &ordered {
                kernel_codes.push(c_code);
                ukernel_codes.push(u_code);
                okernel_codes.push(o_code);
            }
        }
    }
    (kernel_codes, ukernel_codes, okernel_codes)
}

fn continuous_kernel_has_compact_support(code: i32) -> bool {
    matches!(code, 1 | 2 | 3 | 4 | 5 | 6 | 7)
}

fn widen_continuous_bandwidths_for_support(data: &KdmlData<'_>, bw: &mut [f64]) {
    for (j, value) in bw.iter_mut().enumerate().take(data.p) {
        if matches!(data.types[j], ColumnType::Continuous) {
            let range = data.maxs[j] - data.mins[j];
            if range.is_finite() && range > 0.0 {
                *value = value.max(range * 1.05).max(1e-6);
            }
        }
    }
}

#[cfg(kdml_cuda)]
fn run_cuda_block_pilot(
    data: &CudaBlockSyntheticData,
    model_id: usize,
    ckernel_code: i32,
    ukernel_code: i32,
    okernel_code: i32,
    init_theta: Vec<f64>,
    config: &CudaBlockSyntheticConfig,
    progress: Option<&mut dyn FnMut(usize)>,
) -> Result<CudaBlockPilotRun, String> {
    let start = std::time::Instant::now();
    let chain = run_mh_switch_cuda_f32_with_progress(
        data.n,
        data.p,
        1,
        &data.values,
        &data.type_codes,
        config.distance_type.code(),
        &[ckernel_code],
        &[ukernel_code],
        &[okernel_code],
        &init_theta,
        config.pilot_iter,
        0,
        config.beta,
        config.bandwidth_proposal_sd,
        1,
        false,
        false,
        config.adapt_bandwidth_target,
        config.prior_mu,
        config.prior_sd,
        config.seed ^ ((model_id as u64 + 1) * 0x9e37_79b9),
        ScoreVersion::Corrected,
        progress,
    )
    .map_err(|code| {
        format!(
            "CUDA block pilot model {} failed with status {code}",
            model_id + 1
        )
    })?;

    let burn = (config.pilot_iter / 2).min(config.pilot_iter.saturating_sub(1));
    let keep_start = burn.min(config.pilot_iter);
    let keep_len = config.pilot_iter.saturating_sub(keep_start).max(1);
    let mut mean_theta = vec![0.0; data.p];
    for iter in keep_start..config.pilot_iter {
        for j in 0..data.p {
            mean_theta[j] += chain.samples_theta[j * config.pilot_iter + iter];
        }
    }
    for value in &mut mean_theta {
        *value /= keep_len as f64;
    }

    let best_score = chain.samples_score[keep_start..]
        .iter()
        .copied()
        .fold(f64::NEG_INFINITY, f64::max);
    let last_score = chain.samples_score.last().copied().unwrap_or(f64::NAN);

    Ok(CudaBlockPilotRun {
        summary: CudaBlockPilotSummary {
            model_id: model_id + 1,
            ckernel_code,
            ukernel_code,
            okernel_code,
            acceptance_rate: chain.acceptance_rate,
            best_score,
            last_score,
            elapsed_ms: start.elapsed().as_secs_f64() * 1000.0,
        },
        mean_theta,
    })
}

#[cfg(kdml_cuda)]
fn failed_cuda_block_pilot(
    model_id: usize,
    ckernel_code: i32,
    ukernel_code: i32,
    okernel_code: i32,
    mean_theta: Vec<f64>,
) -> CudaBlockPilotRun {
    CudaBlockPilotRun {
        summary: CudaBlockPilotSummary {
            model_id: model_id + 1,
            ckernel_code,
            ukernel_code,
            okernel_code,
            acceptance_rate: f64::NAN,
            best_score: f64::NEG_INFINITY,
            last_score: f64::NEG_INFINITY,
            elapsed_ms: 0.0,
        },
        mean_theta,
    }
}

#[cfg(kdml_cuda)]
pub fn run_cuda_block_synthetic(
    data: CudaBlockSyntheticData,
    config: CudaBlockSyntheticConfig,
) -> Result<CudaBlockSyntheticReport, String> {
    let reports = run_cuda_block_synthetic_chains(data, config)?;
    reports
        .into_iter()
        .next()
        .ok_or_else(|| "no CUDA block chain reports were generated".to_string())
}

#[cfg(kdml_cuda)]
pub fn run_cuda_block_synthetic_chains(
    data: CudaBlockSyntheticData,
    config: CudaBlockSyntheticConfig,
) -> Result<Vec<CudaBlockSyntheticReport>, String> {
    if data.n < 2 {
        return Err("n must be at least 2".to_string());
    }
    if data.p == 0 || data.values.len() < data.n * data.p || data.type_codes.len() < data.p {
        return Err("invalid data dimensions".to_string());
    }
    if config.kept_samples == 0 || config.thin == 0 {
        return Err("kept_samples and thin must be positive".to_string());
    }
    if config.chains == 0 {
        return Err("chains must be positive".to_string());
    }

    let kdml = KdmlData::new(data.n, data.p, &data.values, &data.type_codes)
        .ok_or_else(|| "failed to build KDML data".to_string())?;
    let base_bw = default_bandwidths(&kdml);
    let (kernel_codes, ukernel_codes, okernel_codes) = block_model_grid(&data.type_codes);
    let k_count = kernel_codes.len();
    if k_count == 0 {
        return Err("no candidate models were generated".to_string());
    }

    let mut init_theta = vec![0.0; k_count * data.p];
    for k in 0..k_count {
        let ukernel = UnorderedKernel::from_code(ukernel_codes[k])
            .ok_or_else(|| "invalid unordered kernel code".to_string())?;
        let mut model_bw = base_bw.clone();
        if continuous_kernel_has_compact_support(kernel_codes[k]) {
            widen_continuous_bandwidths_for_support(&kdml, &mut model_bw);
        }
        let theta = bandwidth_to_theta(&kdml, ukernel, &model_bw);
        for j in 0..data.p {
            init_theta[theta_idx(k, j, k_count)] = theta[j];
        }
    }

    if config.initial_bandwidths.is_some() && config.mscv_init {
        return Err(
            "use either external initial bandwidths or the Rust MSCV initializer, not both"
                .to_string(),
        );
    }

    let mut mscv_active_init = 1usize;
    if let Some(external_bw) = config.initial_bandwidths.as_ref() {
        if external_bw.len() != data.p
            || external_bw
                .iter()
                .any(|value| !value.is_finite() || *value <= 0.0)
        {
            return Err(format!(
                "external initial bandwidths must contain exactly {} positive finite values",
                data.p
            ));
        }

        // kdml::dkps uses Gaussian, Aitken, and Wang-van Ryzin kernels.
        let target_o = if data.type_codes.iter().any(|&code| code == 2) {
            0
        } else {
            4
        };
        let external_model = (0..k_count)
            .find(|&k| {
                kernel_codes[k] == 0 && ukernel_codes[k] == 0 && okernel_codes[k] == target_o
            })
            .ok_or_else(|| {
                "could not locate the Gaussian/Aitken/Wang-van Ryzin initialization model"
                    .to_string()
            })?;
        let active_ukernel =
            UnorderedKernel::from_code(ukernel_codes[external_model]).ok_or_else(|| {
                "invalid unordered kernel code for external initialization".to_string()
            })?;
        if !kdml.valid_bandwidths(external_bw, active_ukernel) {
            return Err(
                "R KDML package returned bandwidths outside the sampler's valid domain".to_string(),
            );
        }

        // Use the R-package vector for every product-space slot. The transform
        // accounts for the categorical bandwidth bounds of each kernel.
        for k in 0..k_count {
            let ukernel = UnorderedKernel::from_code(ukernel_codes[k])
                .ok_or_else(|| "invalid unordered kernel code".to_string())?;
            let theta = bandwidth_to_theta(&kdml, ukernel, external_bw);
            for j in 0..data.p {
                init_theta[theta_idx(k, j, k_count)] = theta[j];
            }
        }
        mscv_active_init = external_model + 1;
    }
    if config.mscv_init {
        let mut best_mscv_init_score = f64::NEG_INFINITY;
        for k in 0..k_count {
            let ukernel = UnorderedKernel::from_code(ukernel_codes[k])
                .ok_or_else(|| "invalid unordered kernel code".to_string())?;
            let mut opt_bw = base_bw.clone();
            if continuous_kernel_has_compact_support(kernel_codes[k]) {
                widen_continuous_bandwidths_for_support(&kdml, &mut opt_bw);
            }
            match optimize_bw_impl(
                data.n,
                data.p,
                &data.values,
                &data.type_codes,
                config.distance_type.code(),
                kernel_codes[k],
                ukernel_codes[k],
                okernel_codes[k],
                config.mscv_init_starts,
                config.mscv_init_steps,
                config.seed ^ ((k as u64 + 1) * 0x9e37_79b9_7f4a_7c15),
                &mut opt_bw,
            ) {
                Ok(score) => {
                    let theta = bandwidth_to_theta(&kdml, ukernel, &opt_bw);
                    for j in 0..data.p {
                        init_theta[theta_idx(k, j, k_count)] = theta[j];
                    }
                    if score > best_mscv_init_score {
                        best_mscv_init_score = score;
                        mscv_active_init = k + 1;
                    }
                }
                Err(code) => {
                    eprintln!(
                        "MSCV initializer model {} failed with status {}; keeping default init",
                        k + 1,
                        code
                    );
                }
            }
        }
        if !best_mscv_init_score.is_finite() {
            return Err("all MSCV initializer models had non-finite scores".to_string());
        }
    }
    let continuous_reference_scales: Vec<f64> = kdml
        .types
        .iter()
        .enumerate()
        .map(|(col, kind)| {
            if matches!(kind, ColumnType::Continuous) {
                kdml.continuous_scales[col]
            } else {
                f64::NAN
            }
        })
        .collect();
    drop(kdml);

    let (pilot_summaries, active_init) = if config.pilot_iter == 0 {
        (Vec::new(), mscv_active_init)
    } else {
        let pilot_cores = config.pilot_cores.max(1).min(k_count);
        let mut pilot_runs: Vec<Option<CudaBlockPilotRun>> = (0..k_count).map(|_| None).collect();

        for batch_start in (0..k_count).step_by(pilot_cores) {
            let batch_end = (batch_start + pilot_cores).min(k_count);
            let batch_size = batch_end - batch_start;
            let progress_display = if config.progress {
                Some(Arc::new(CudaProgressDisplay::new(batch_size)))
            } else {
                None
            };
            let batch_results = thread::scope(|scope| {
                let mut handles = Vec::with_capacity(batch_size);
                for model_idx in batch_start..batch_end {
                    let mut single_init = vec![0.0; data.p];
                    for j in 0..data.p {
                        single_init[j] = init_theta[theta_idx(model_idx, j, k_count)];
                    }
                    let ckernel_code = kernel_codes[model_idx];
                    let ukernel_code = ukernel_codes[model_idx];
                    let okernel_code = okernel_codes[model_idx];
                    let data_ref = &data;
                    let config_ref = &config;
                    let progress_display = progress_display.clone();
                    let slot = model_idx - batch_start;
                    handles.push(scope.spawn(move || {
                        let result = if let Some(display) = progress_display {
                            let label = format!(
                                "pilot {}/{} c={} u={} o={}",
                                model_idx + 1,
                                k_count,
                                ckernel_code,
                                ukernel_code,
                                okernel_code
                            );
                            let mut progress_line =
                                CudaProgressLine::new(label, config_ref.pilot_iter, display, slot);
                            let result = {
                                let mut callback = |completed| progress_line.tick(completed);
                                run_cuda_block_pilot(
                                    data_ref,
                                    model_idx,
                                    ckernel_code,
                                    ukernel_code,
                                    okernel_code,
                                    single_init,
                                    config_ref,
                                    Some(&mut callback),
                                )
                            };
                            if result.is_ok() {
                                progress_line.finish();
                            } else {
                                progress_line.fail();
                            }
                            result
                        } else {
                            run_cuda_block_pilot(
                                data_ref,
                                model_idx,
                                ckernel_code,
                                ukernel_code,
                                okernel_code,
                                single_init,
                                config_ref,
                                None,
                            )
                        };
                        (model_idx, result)
                    }));
                }

                let mut out = Vec::with_capacity(handles.len());
                for handle in handles {
                    let (model_idx, result) = handle
                        .join()
                        .map_err(|_| "CUDA block pilot thread panicked".to_string())?;
                    out.push((model_idx, result));
                }
                Ok::<_, String>(out)
            })?;

            for (model_idx, result) in batch_results {
                let pilot = match result {
                    Ok(pilot) => pilot,
                    Err(err) => {
                        eprintln!("{err}; keeping model in grid with -inf pilot score");
                        let mut mean_theta = vec![0.0; data.p];
                        for j in 0..data.p {
                            mean_theta[j] = init_theta[theta_idx(model_idx, j, k_count)];
                        }
                        failed_cuda_block_pilot(
                            model_idx,
                            kernel_codes[model_idx],
                            ukernel_codes[model_idx],
                            okernel_codes[model_idx],
                            mean_theta,
                        )
                    }
                };
                pilot_runs[model_idx] = Some(pilot);
            }
        }

        let mut pilot_summaries = Vec::with_capacity(k_count);
        let mut active_init = 1usize;
        let mut best_pilot_score = f64::NEG_INFINITY;
        for model_idx in 0..k_count {
            let pilot = pilot_runs[model_idx]
                .take()
                .ok_or_else(|| format!("missing pilot result for model {}", model_idx + 1))?;
            for j in 0..data.p {
                init_theta[theta_idx(model_idx, j, k_count)] = pilot.mean_theta[j];
            }
            if pilot.summary.best_score > best_pilot_score {
                best_pilot_score = pilot.summary.best_score;
                active_init = model_idx + 1;
            }
            pilot_summaries.push(pilot.summary);
        }
        if !best_pilot_score.is_finite() {
            return Err("all CUDA block pilot models had non-finite scores".to_string());
        }
        (pilot_summaries, active_init)
    };

    let n_iter = config.burn_in + config.kept_samples * config.thin;
    let kept_indices: Vec<usize> = (config.burn_in + config.thin - 1..n_iter)
        .step_by(config.thin)
        .take(config.kept_samples)
        .collect();

    let progress_display = if config.progress {
        let initial_lines = (0..config.chains)
            .map(|chain_idx| {
                let label = if config.chains == 1 {
                    "main chain".to_string()
                } else {
                    format!("main chain {}/{}", chain_idx + 1, config.chains)
                };
                cuda_progress_line_text(&label, n_iter, 0, Duration::ZERO, "running")
            })
            .collect::<Vec<_>>();
        let display = Arc::new(CudaProgressDisplay::with_lines(initial_lines));
        display.render_initial();
        Some(display)
    } else {
        None
    };
    let chain_results = thread::scope(|scope| {
        let mut handles = Vec::with_capacity(config.chains);
        for chain_idx in 0..config.chains {
            let values = &data.values;
            let type_codes = &data.type_codes;
            let kernel_codes_ref = &kernel_codes;
            let ukernel_codes_ref = &ukernel_codes;
            let okernel_codes_ref = &okernel_codes;
            let init_theta_ref = &init_theta;
            let progress_display = progress_display.clone();
            let seed = (config.seed + chain_idx as u64 * 100_000) ^ 0x517c_c1b7_cafe_f00d;
            let chains = config.chains;
            let beta = config.beta;
            let bandwidth_proposal_sd = config.bandwidth_proposal_sd;
            let random_init = config.random_init;
            let adapt = config.adapt;
            let adapt_bandwidth_target = config.adapt_bandwidth_target;
            let burn_in = config.burn_in;
            let prior_mu = config.prior_mu;
            let prior_sd = config.prior_sd;
            let distance_code = config.distance_type.code();
            let n = data.n;
            let p = data.p;

            handles.push(scope.spawn(move || {
                let start = std::time::Instant::now();
                let chain = if let Some(display) = progress_display {
                    let label = if chains == 1 {
                        "main chain".to_string()
                    } else {
                        format!("main chain {}/{}", chain_idx + 1, chains)
                    };
                    let mut progress_line =
                        CudaProgressLine::new(label, n_iter, display, chain_idx);
                    let result = {
                        let mut callback = |completed| progress_line.tick(completed);
                        run_mh_switch_cuda_f32_with_progress(
                            n,
                            p,
                            k_count,
                            values,
                            type_codes,
                            distance_code,
                            kernel_codes_ref,
                            ukernel_codes_ref,
                            okernel_codes_ref,
                            init_theta_ref,
                            n_iter,
                            burn_in,
                            beta,
                            bandwidth_proposal_sd,
                            active_init,
                            random_init,
                            adapt,
                            adapt_bandwidth_target,
                            prior_mu,
                            prior_sd,
                            seed,
                            ScoreVersion::Corrected,
                            Some(&mut callback),
                        )
                    };
                    if result.is_ok() {
                        progress_line.finish();
                    } else {
                        progress_line.fail();
                    }
                    result
                } else {
                    run_mh_switch_cuda_f32_with_progress(
                        n,
                        p,
                        k_count,
                        values,
                        type_codes,
                        distance_code,
                        kernel_codes_ref,
                        ukernel_codes_ref,
                        okernel_codes_ref,
                        init_theta_ref,
                        n_iter,
                        burn_in,
                        beta,
                        bandwidth_proposal_sd,
                        active_init,
                        random_init,
                        adapt,
                        adapt_bandwidth_target,
                        prior_mu,
                        prior_sd,
                        seed,
                        ScoreVersion::Corrected,
                        None,
                    )
                }
                .map_err(|code| {
                    format!(
                        "CUDA block MCMC chain {} failed with status {code}",
                        chain_idx + 1
                    )
                })?;

                Ok::<_, String>((chain_idx, chain, start.elapsed().as_secs_f64() * 1000.0))
            }));
        }

        let mut out = Vec::with_capacity(handles.len());
        for handle in handles {
            out.push(
                handle
                    .join()
                    .map_err(|_| "CUDA block MCMC chain thread panicked".to_string())??,
            );
        }
        Ok::<_, String>(out)
    })?;

    let mut reports = chain_results
        .into_iter()
        .map(|(chain_idx, chain, elapsed_ms)| {
            (
                chain_idx,
                CudaBlockSyntheticReport {
                    n_iter,
                    kept_indices: kept_indices.clone(),
                    active_init,
                    beta: config.beta,
                    distance_type: config.distance_type,
                    initialization_attempts: chain.initialization_attempts,
                    initialization_fallback: chain.initialization_fallback,
                    invalid_proposals: chain.invalid_proposals,
                    initial_ckernel: chain.initial_ckernel,
                    initial_ukernel: chain.initial_ukernel,
                    initial_okernel: chain.initial_okernel,
                    initial_theta: chain.initial_theta,
                    initial_score: chain.initial_score,
                    initial_log_post: chain.initial_log_post,
                    type_codes: data.type_codes.clone(),
                    continuous_reference_scales: continuous_reference_scales.clone(),
                    external_init: config.initial_bandwidths.is_some(),
                    mscv_init: config.mscv_init,
                    mscv_init_starts: config.mscv_init_starts,
                    mscv_init_steps: config.mscv_init_steps,
                    kernel_codes: kernel_codes.clone(),
                    ukernel_codes: ukernel_codes.clone(),
                    okernel_codes: okernel_codes.clone(),
                    pilot_summaries: pilot_summaries.clone(),
                    samples_model: chain.samples_model,
                    samples_ckernel: chain.samples_ckernel,
                    samples_ukernel: chain.samples_ukernel,
                    samples_okernel: chain.samples_okernel,
                    samples_theta: chain.samples_theta,
                    samples_bw: chain.samples_bw,
                    samples_score: chain.samples_score,
                    samples_log_post: chain.samples_log_post,
                    accepted: chain.accepted,
                    acceptance_rate: chain.acceptance_rate,
                    final_bandwidth_proposal_sds: chain.final_bandwidth_proposal_sds,
                    final_bandwidth_proposal_sds_by_col: chain.final_bandwidth_proposal_sds_by_col,
                    kernel_attempts_by_col: chain.kernel_attempts_by_col,
                    kernel_accepts_by_col: chain.kernel_accepts_by_col,
                    bandwidth_attempts_by_col: chain.bandwidth_attempts_by_col,
                    bandwidth_accepts_by_col: chain.bandwidth_accepts_by_col,
                    sampling_kernel_attempts_by_col: chain.sampling_kernel_attempts_by_col,
                    sampling_kernel_accepts_by_col: chain.sampling_kernel_accepts_by_col,
                    sampling_bandwidth_attempts_by_col: chain.sampling_bandwidth_attempts_by_col,
                    sampling_bandwidth_accepts_by_col: chain.sampling_bandwidth_accepts_by_col,
                    elapsed_ms,
                },
            )
        })
        .collect::<Vec<_>>();
    reports.sort_by_key(|(chain_idx, _)| *chain_idx);
    let reports = reports
        .into_iter()
        .map(|(_, report)| report)
        .collect::<Vec<_>>();

    Ok(reports)
}

#[cfg(not(kdml_cuda))]
pub fn run_cuda_block_synthetic_chains(
    _data: CudaBlockSyntheticData,
    _config: CudaBlockSyntheticConfig,
) -> Result<Vec<CudaBlockSyntheticReport>, String> {
    Err("CUDA support was not built; install nvcc/MSVC and rebuild".to_string())
}

#[cfg(not(kdml_cuda))]
pub fn run_cuda_block_synthetic(
    _data: CudaBlockSyntheticData,
    _config: CudaBlockSyntheticConfig,
) -> Result<CudaBlockSyntheticReport, String> {
    Err("CUDA support was not built; install nvcc/MSVC and rebuild".to_string())
}

struct ChainRunOutput {
    samples_model: Vec<i32>,
    samples_ckernel: Vec<i32>,
    samples_ukernel: Vec<i32>,
    samples_okernel: Vec<i32>,
    samples_theta: Vec<f64>,
    samples_bw: Vec<f64>,
    samples_score: Vec<f64>,
    samples_log_post: Vec<f64>,
    accepted: Vec<i32>,
    mh_model: Vec<i32>,
    acceptance_rate: f64,
    initialization_attempts: usize,
    initialization_fallback: bool,
    invalid_proposals: usize,
    initial_ckernel: Vec<i32>,
    initial_ukernel: Vec<i32>,
    initial_okernel: Vec<i32>,
    initial_theta: Vec<f64>,
    initial_score: f64,
    initial_log_post: f64,
    final_kernel_proposal_sds: [f64; 3],
    final_bandwidth_proposal_sds: [f64; 3],
    final_kernel_proposal_sds_by_col: Vec<f64>,
    final_bandwidth_proposal_sds_by_col: Vec<f64>,
    kernel_attempts_by_col: Vec<usize>,
    kernel_accepts_by_col: Vec<usize>,
    bandwidth_attempts_by_col: Vec<usize>,
    bandwidth_accepts_by_col: Vec<usize>,
    sampling_kernel_attempts_by_col: Vec<usize>,
    sampling_kernel_accepts_by_col: Vec<usize>,
    sampling_bandwidth_attempts_by_col: Vec<usize>,
    sampling_bandwidth_accepts_by_col: Vec<usize>,
}

#[cfg(any())]
fn run_mcmc_alloc(
    n: usize,
    p: usize,
    k_count: usize,
    data_values: &[f64],
    type_codes: &[i32],
    distance_code: i32,
    kernel_codes: &[i32],
    ukernel_codes: &[i32],
    okernel_codes: &[i32],
    init_theta: &[f64],
    pseudo_mu: &[f64],
    pseudo_sd: &[f64],
    n_iter: usize,
    beta: f64,
    proposal_sd: f64,
    active_init: usize,
    prior_mu: f64,
    prior_sd: f64,
    seed: u64,
) -> Result<ChainRunOutput, i32> {
    run_mcmc_alloc_with_progress(
        n,
        p,
        k_count,
        data_values,
        type_codes,
        distance_code,
        kernel_codes,
        ukernel_codes,
        okernel_codes,
        init_theta,
        pseudo_mu,
        pseudo_sd,
        n_iter,
        beta,
        proposal_sd,
        active_init,
        prior_mu,
        prior_sd,
        seed,
        None,
    )
}

#[cfg(any())]
fn run_mcmc_alloc_with_progress(
    n: usize,
    p: usize,
    k_count: usize,
    data_values: &[f64],
    type_codes: &[i32],
    distance_code: i32,
    kernel_codes: &[i32],
    ukernel_codes: &[i32],
    okernel_codes: &[i32],
    init_theta: &[f64],
    pseudo_mu: &[f64],
    pseudo_sd: &[f64],
    n_iter: usize,
    beta: f64,
    proposal_sd: f64,
    active_init: usize,
    prior_mu: f64,
    prior_sd: f64,
    seed: u64,
    progress: Option<&mut dyn FnMut(usize)>,
) -> Result<ChainRunOutput, i32> {
    let mut out = ChainRunOutput {
        samples_model: vec![0; n_iter],
        samples_ckernel: vec![0; n_iter * p],
        samples_ukernel: vec![0; n_iter * p],
        samples_okernel: vec![0; n_iter * p],
        samples_theta: vec![0.0; n_iter * p],
        samples_bw: vec![0.0; n_iter * p],
        samples_score: vec![0.0; n_iter],
        samples_log_post: vec![0.0; n_iter],
        accepted: vec![0; n_iter],
        mh_model: vec![0; n_iter],
        acceptance_rate: f64::NAN,
        initialization_attempts: 0,
        initialization_fallback: false,
        invalid_proposals: 0,
        initial_ckernel: Vec::new(),
        initial_ukernel: Vec::new(),
        initial_okernel: Vec::new(),
        initial_theta: Vec::new(),
        initial_score: f64::NAN,
        initial_log_post: f64::NAN,
        final_kernel_proposal_sds: [proposal_sd; 3],
        final_bandwidth_proposal_sds: [proposal_sd; 3],
        final_kernel_proposal_sds_by_col: vec![proposal_sd; p],
        final_bandwidth_proposal_sds_by_col: vec![proposal_sd; p],
        kernel_attempts_by_col: vec![0; p],
        kernel_accepts_by_col: vec![0; p],
        bandwidth_attempts_by_col: vec![0; p],
        bandwidth_accepts_by_col: vec![0; p],
        sampling_kernel_attempts_by_col: vec![0; p],
        sampling_kernel_accepts_by_col: vec![0; p],
        sampling_bandwidth_attempts_by_col: vec![0; p],
        sampling_bandwidth_accepts_by_col: vec![0; p],
    };

    out.acceptance_rate = run_mcmc_impl(
        n,
        p,
        k_count,
        data_values,
        type_codes,
        distance_code,
        kernel_codes,
        ukernel_codes,
        okernel_codes,
        init_theta,
        pseudo_mu,
        pseudo_sd,
        n_iter,
        beta,
        proposal_sd,
        active_init,
        prior_mu,
        prior_sd,
        seed,
        progress,
        &mut out.samples_model,
        &mut out.samples_theta,
        &mut out.samples_bw,
        &mut out.samples_score,
        &mut out.samples_log_post,
        &mut out.accepted,
        &mut out.mh_model,
    )?;

    Ok(out)
}

#[cfg(any())]
fn run_chains_impl(
    n: usize,
    p: usize,
    k_count: usize,
    chain_count: usize,
    data_values: &[f64],
    type_codes: &[i32],
    distance_code: i32,
    kernel_codes: &[i32],
    ukernel_codes: &[i32],
    okernel_codes: &[i32],
    init_theta: &[f64],
    pseudo_mu: &[f64],
    pseudo_sd: &[f64],
    n_iter: usize,
    beta: f64,
    proposal_sd: f64,
    active_inits: &[i32],
    seeds: &[i32],
    prior_mu: f64,
    prior_sd: f64,
    n_cores: usize,
) -> Result<Vec<ChainRunOutput>, i32> {
    if chain_count == 0
        || active_inits.len() < chain_count
        || seeds.len() < chain_count
        || kernel_codes.len() < k_count
        || ukernel_codes.len() < k_count
        || okernel_codes.len() < k_count
        || init_theta.len() < k_count * p
        || pseudo_mu.len() < k_count * p
        || pseudo_sd.len() < k_count * p
    {
        return Err(-20);
    }

    let run_one = |chain_id: usize| {
        run_mcmc_alloc(
            n,
            p,
            k_count,
            data_values,
            type_codes,
            distance_code,
            kernel_codes,
            ukernel_codes,
            okernel_codes,
            init_theta,
            pseudo_mu,
            pseudo_sd,
            n_iter,
            beta,
            proposal_sd,
            active_inits[chain_id] as usize,
            prior_mu,
            prior_sd,
            (seeds[chain_id] as u32 as u64).max(1),
        )
    };

    if n_cores <= 1 || chain_count == 1 {
        let mut outputs = Vec::with_capacity(chain_count);
        for chain_id in 0..chain_count {
            outputs.push(run_one(chain_id)?);
        }
        return Ok(outputs);
    }

    let batch_size = n_cores.min(chain_count).max(1);
    let mut outputs: Vec<Option<ChainRunOutput>> = (0..chain_count).map(|_| None).collect();

    thread::scope(|scope| {
        for batch_start in (0..chain_count).step_by(batch_size) {
            let batch_end = (batch_start + batch_size).min(chain_count);
            let mut handles = Vec::with_capacity(batch_end - batch_start);

            for chain_id in batch_start..batch_end {
                handles.push(scope.spawn(move || (chain_id, run_one(chain_id))));
            }

            for handle in handles {
                let (chain_id, result) = handle.join().map_err(|_| -999)?;
                outputs[chain_id] = Some(result?);
            }
        }

        Ok::<(), i32>(())
    })?;

    let mut finished = Vec::with_capacity(chain_count);
    for output in outputs {
        finished.push(output.ok_or(-21)?);
    }

    Ok(finished)
}

fn sigmoid(x: f64) -> f64 {
    if x >= 0.0 {
        1.0 / (1.0 + (-x).exp())
    } else {
        let ex = x.exp();
        ex / (1.0 + ex)
    }
}

fn logit(x: f64) -> f64 {
    (x / (1.0 - x)).ln()
}

fn bandwidth_to_theta(data: &KdmlData<'_>, _ukernel: UnorderedKernel, bw: &[f64]) -> Vec<f64> {
    let mut theta = vec![0.0; data.p];
    for j in 0..data.p {
        theta[j] = match data.types[j] {
            ColumnType::Continuous => {
                (bw[j].max(f64::MIN_POSITIVE) / data.continuous_scales[j]).ln()
            }
            ColumnType::Unordered | ColumnType::Ordered => logit(bw[j].clamp(1e-8, 1.0 - 1e-8)),
        };
    }
    theta
}

fn theta_to_bandwidth(data: &KdmlData<'_>, _ukernel: UnorderedKernel, theta: &[f64]) -> Vec<f64> {
    let mut bw = vec![1.0; data.p];
    for j in 0..data.p {
        bw[j] = match data.types[j] {
            ColumnType::Continuous => data.continuous_scales[j] * theta[j].exp(),
            ColumnType::Unordered | ColumnType::Ordered => sigmoid(theta[j]),
        };
    }
    bw
}

#[derive(Clone)]
struct SimplexVertex {
    theta: Vec<f64>,
    bw: Vec<f64>,
    score: f64,
}

fn evaluate_simplex_vertex(
    data: &KdmlData<'_>,
    distance: DistanceType,
    ckernel: ContinuousKernel,
    ukernel: UnorderedKernel,
    okernel: OrderedKernel,
    theta: Vec<f64>,
) -> SimplexVertex {
    let bw = theta_to_bandwidth(data, ukernel, &theta);
    let score = mscv_score(data, distance, ckernel, ukernel, okernel, &bw);
    SimplexVertex { theta, bw, score }
}

fn nelder_mead_bandwidth(
    data: &KdmlData<'_>,
    distance: DistanceType,
    ckernel: ContinuousKernel,
    ukernel: UnorderedKernel,
    okernel: OrderedKernel,
    initial_bw: &[f64],
    max_iter: usize,
    mut progress: Option<&mut dyn FnMut(usize)>,
) -> SimplexVertex {
    let p = data.p;
    let initial_theta = bandwidth_to_theta(data, ukernel, initial_bw);
    let mut simplex = Vec::with_capacity(p + 1);
    simplex.push(evaluate_simplex_vertex(
        data,
        distance,
        ckernel,
        ukernel,
        okernel,
        initial_theta.clone(),
    ));

    for j in 0..p {
        let mut theta = initial_theta.clone();
        theta[j] += 0.35;
        simplex.push(evaluate_simplex_vertex(
            data, distance, ckernel, ukernel, okernel, theta,
        ));
    }

    let alpha = 1.0;
    let gamma = 2.0;
    let rho = 0.5;
    let sigma = 0.5;

    for iter in 0..max_iter.max(1) {
        simplex.sort_by(|a, b| b.score.total_cmp(&a.score));

        let best_score = simplex[0].score;
        let score_spread = simplex
            .iter()
            .filter_map(|v| {
                if v.score.is_finite() && best_score.is_finite() {
                    Some((best_score - v.score).abs())
                } else {
                    None
                }
            })
            .fold(0.0_f64, f64::max);
        let theta_spread = simplex
            .iter()
            .flat_map(|v| {
                v.theta
                    .iter()
                    .zip(simplex[0].theta.iter())
                    .map(|(a, b)| (a - b).abs())
            })
            .fold(0.0_f64, f64::max);
        if theta_spread < 1e-4 && score_spread < 1e-7 {
            if let Some(callback) = progress.as_deref_mut() {
                callback(iter + 1);
            }
            break;
        }

        let worst = simplex[p].clone();
        let mut centroid = vec![0.0; p];
        for vertex in simplex.iter().take(p) {
            for j in 0..p {
                centroid[j] += vertex.theta[j];
            }
        }
        for value in &mut centroid {
            *value /= p as f64;
        }

        let reflected_theta: Vec<f64> = centroid
            .iter()
            .zip(worst.theta.iter())
            .map(|(c, w)| c + alpha * (c - w))
            .collect();
        let reflected =
            evaluate_simplex_vertex(data, distance, ckernel, ukernel, okernel, reflected_theta);

        if reflected.score > simplex[0].score {
            let expanded_theta: Vec<f64> = centroid
                .iter()
                .zip(reflected.theta.iter())
                .map(|(c, r)| c + gamma * (r - c))
                .collect();
            let expanded =
                evaluate_simplex_vertex(data, distance, ckernel, ukernel, okernel, expanded_theta);
            simplex[p] = if expanded.score > reflected.score {
                expanded
            } else {
                reflected
            };
        } else if reflected.score > simplex[p - 1].score {
            simplex[p] = reflected;
        } else {
            let contraction_base = if reflected.score > worst.score {
                reflected.theta
            } else {
                worst.theta
            };
            let contracted_theta: Vec<f64> = centroid
                .iter()
                .zip(contraction_base.iter())
                .map(|(c, x)| c + rho * (x - c))
                .collect();
            let contracted = evaluate_simplex_vertex(
                data,
                distance,
                ckernel,
                ukernel,
                okernel,
                contracted_theta,
            );

            if contracted.score > worst.score {
                simplex[p] = contracted;
            } else {
                let best_theta = simplex[0].theta.clone();
                for vertex in simplex.iter_mut().skip(1) {
                    let shrunk_theta: Vec<f64> = best_theta
                        .iter()
                        .zip(vertex.theta.iter())
                        .map(|(b, x)| b + sigma * (x - b))
                        .collect();
                    *vertex = evaluate_simplex_vertex(
                        data,
                        distance,
                        ckernel,
                        ukernel,
                        okernel,
                        shrunk_theta,
                    );
                }
            }
        }

        if let Some(callback) = progress.as_deref_mut() {
            callback(iter + 1);
        }
    }

    simplex.sort_by(|a, b| b.score.total_cmp(&a.score));
    simplex.remove(0)
}

fn optimize_bw_impl(
    n: usize,
    p: usize,
    data_values: &[f64],
    type_codes: &[i32],
    distance_code: i32,
    kernel_code: i32,
    ukernel_code: i32,
    okernel_code: i32,
    n_starts: usize,
    max_steps: usize,
    seed: u64,
    out_bw: &mut [f64],
) -> Result<f64, i32> {
    optimize_bw_impl_with_progress(
        n,
        p,
        data_values,
        type_codes,
        distance_code,
        kernel_code,
        ukernel_code,
        okernel_code,
        n_starts,
        max_steps,
        seed,
        out_bw,
        None,
    )
}

fn optimize_bw_impl_with_progress(
    n: usize,
    p: usize,
    data_values: &[f64],
    type_codes: &[i32],
    distance_code: i32,
    kernel_code: i32,
    ukernel_code: i32,
    okernel_code: i32,
    n_starts: usize,
    max_steps: usize,
    seed: u64,
    out_bw: &mut [f64],
    mut progress: Option<&mut dyn FnMut(usize)>,
) -> Result<f64, i32> {
    let data = KdmlData::new(n, p, data_values, type_codes).ok_or(-2)?;
    let distance = DistanceType::from_code(distance_code).ok_or(-3)?;
    let ckernel = ContinuousKernel::from_code(kernel_code).ok_or(-4)?;
    let ukernel = UnorderedKernel::from_code(ukernel_code).ok_or(-5)?;
    let okernel = OrderedKernel::from_code(okernel_code).ok_or(-6)?;
    if out_bw.len() < p {
        return Err(-7);
    }

    let mut rng = Rng64::new(seed);
    let starts = n_starts.max(1);
    let steps = max_steps.max(1);
    let mut best_bw = vec![1.0; p];
    let mut best_score = f64::NEG_INFINITY;

    for start in 0..starts {
        let mut bw = vec![1.0; p];
        for j in 0..p {
            bw[j] = match data.types[j] {
                ColumnType::Continuous => {
                    let mut mean = 0.0;
                    for i in 0..n {
                        mean += data.at(i, j);
                    }
                    mean /= n as f64;
                    let mut var = 0.0;
                    for i in 0..n {
                        let centered = data.at(i, j) - mean;
                        var += centered * centered;
                    }
                    let sd = if n > 1 {
                        (var / (n as f64 - 1.0)).sqrt()
                    } else {
                        1.0
                    };
                    let scale = if sd.is_finite() && sd > 0.0 { sd } else { 1.0 };
                    if start == 0 {
                        scale
                    } else {
                        let lo = (scale * 0.03).max(1e-4).ln();
                        let hi = (scale * 4.0).max(1e-3).ln();
                        (lo + rng.uniform() * (hi - lo)).exp()
                    }
                }
                ColumnType::Unordered | ColumnType::Ordered => {
                    // Every categorical kernel uses the same logistic
                    // parameterization, so initialization also uses the full
                    // open unit interval regardless of the kernel family.
                    let upper = 0.999;
                    if start == 0 {
                        0.5_f64.min(upper).max(1e-6)
                    } else {
                        1e-6 + rng.uniform() * (upper - 1e-6).max(1e-6)
                    }
                }
            };
        }

        let max_iter = steps.saturating_mul((2 * p).max(1));
        let base_completed = start * max_iter;
        let mut start_progress = |completed: usize| {
            if let Some(callback) = progress.as_deref_mut() {
                callback(base_completed + completed.min(max_iter));
            }
        };
        let optimized = nelder_mead_bandwidth(
            &data,
            distance,
            ckernel,
            ukernel,
            okernel,
            &bw,
            max_iter,
            Some(&mut start_progress),
        );
        let score = optimized.score;
        bw = optimized.bw;
        if let Some(callback) = progress.as_deref_mut() {
            callback((start + 1) * max_iter);
        }

        if score > best_score {
            best_score = score;
            best_bw.copy_from_slice(&bw);
        }
    }

    if !best_score.is_finite() {
        return Err(-8);
    }

    out_bw[..p].copy_from_slice(&best_bw);
    Ok(best_score)
}

#[no_mangle]
pub extern "C" fn kdml_mcmc_score(
    n_ptr: *const i32,
    p_ptr: *const i32,
    data_ptr: *const f64,
    type_ptr: *const i32,
    distance_ptr: *const i32,
    kernel_ptr: *const i32,
    ukernel_ptr: *const i32,
    okernel_ptr: *const i32,
    bw_ptr: *const f64,
    out_score: *mut f64,
    status: *mut i32,
) {
    let result = panic::catch_unwind(|| unsafe {
        let n = *n_ptr as usize;
        let p = *p_ptr as usize;
        let data_values = slice::from_raw_parts(data_ptr, n * p);
        let type_codes = slice::from_raw_parts(type_ptr, p);
        let bw = slice::from_raw_parts(bw_ptr, p);
        let data = KdmlData::new(n, p, data_values, type_codes).ok_or(-2)?;
        let distance = DistanceType::from_code(*distance_ptr).ok_or(-3)?;
        let ckernel = ContinuousKernel::from_code(*kernel_ptr).ok_or(-4)?;
        let ukernel = UnorderedKernel::from_code(*ukernel_ptr).ok_or(-5)?;
        let okernel = OrderedKernel::from_code(*okernel_ptr).ok_or(-6)?;
        Ok::<f64, i32>(mscv_score(&data, distance, ckernel, ukernel, okernel, bw))
    });

    unsafe {
        match result {
            Ok(Ok(score)) => {
                *out_score = finite_or_neg_inf(score);
                *status = 0;
            }
            Ok(Err(code)) => {
                *out_score = f64::NEG_INFINITY;
                *status = code;
            }
            Err(_) => {
                *out_score = f64::NEG_INFINITY;
                *status = -999;
            }
        }
    }
}

#[no_mangle]
pub extern "C" fn kdml_mcmc_distance(
    n_ptr: *const i32,
    p_ptr: *const i32,
    data_ptr: *const f64,
    type_ptr: *const i32,
    distance_ptr: *const i32,
    kernel_ptr: *const i32,
    ukernel_ptr: *const i32,
    okernel_ptr: *const i32,
    bw_ptr: *const f64,
    standardize_ptr: *const i32,
    out_dist: *mut f64,
    status: *mut i32,
) {
    let result = panic::catch_unwind(|| unsafe {
        let n = *n_ptr as usize;
        let p = *p_ptr as usize;
        let data_values = slice::from_raw_parts(data_ptr, n * p);
        let type_codes = slice::from_raw_parts(type_ptr, p);
        let bw = slice::from_raw_parts(bw_ptr, p);
        let out = slice::from_raw_parts_mut(out_dist, n * n);
        let data = KdmlData::new(n, p, data_values, type_codes).ok_or(-2)?;
        let distance = DistanceType::from_code(*distance_ptr).ok_or(-3)?;
        let ckernel = ContinuousKernel::from_code(*kernel_ptr).ok_or(-4)?;
        let ukernel = UnorderedKernel::from_code(*ukernel_ptr).ok_or(-5)?;
        let okernel = OrderedKernel::from_code(*okernel_ptr).ok_or(-6)?;
        if !data.valid_bandwidths(bw, ukernel) {
            return Err(-7);
        }

        for value in out.iter_mut() {
            *value = 0.0;
        }
        for pair_idx in 0..data.pair_count() {
            let i = data.pair_rows_a[pair_idx];
            let j = data.pair_rows_b[pair_idx];
            let d = pair_kdml_distance(&data, pair_idx, distance, ckernel, ukernel, okernel, bw);
            if !d.is_finite() {
                return Err(-8);
            }
            out[j * n + i] = d;
            out[i * n + j] = d;
        }

        if *standardize_ptr != 0 {
            let mut min_value = f64::INFINITY;
            let mut max_value = f64::NEG_INFINITY;
            for &value in out.iter() {
                min_value = min_value.min(value);
                max_value = max_value.max(value);
            }
            let range = max_value - min_value;
            if range.is_finite() && range > 0.0 {
                for value in out.iter_mut() {
                    *value = (*value - min_value) / range;
                }
            }
        }

        Ok::<(), i32>(())
    });

    unsafe {
        *status = match result {
            Ok(Ok(())) => 0,
            Ok(Err(code)) => code,
            Err(_) => -999,
        };
    }
}

#[no_mangle]
pub extern "C" fn kdml_mcmc_optimize_bw(
    n_ptr: *const i32,
    p_ptr: *const i32,
    data_ptr: *const f64,
    type_ptr: *const i32,
    distance_ptr: *const i32,
    kernel_ptr: *const i32,
    ukernel_ptr: *const i32,
    okernel_ptr: *const i32,
    n_starts_ptr: *const i32,
    max_steps_ptr: *const i32,
    seed_ptr: *const i32,
    out_bw: *mut f64,
    out_score: *mut f64,
    status: *mut i32,
) {
    let result = panic::catch_unwind(|| unsafe {
        let n = *n_ptr as usize;
        let p = *p_ptr as usize;
        let data_values = slice::from_raw_parts(data_ptr, n * p);
        let type_codes = slice::from_raw_parts(type_ptr, p);
        let out = slice::from_raw_parts_mut(out_bw, p);
        optimize_bw_impl(
            n,
            p,
            data_values,
            type_codes,
            *distance_ptr,
            *kernel_ptr,
            *ukernel_ptr,
            *okernel_ptr,
            (*n_starts_ptr).max(1) as usize,
            (*max_steps_ptr).max(1) as usize,
            (*seed_ptr as u32 as u64).max(1),
            out,
        )
    });

    unsafe {
        match result {
            Ok(Ok(score)) => {
                *out_score = finite_or_neg_inf(score);
                *status = 0;
            }
            Ok(Err(code)) => {
                *out_score = f64::NEG_INFINITY;
                *status = code;
            }
            Err(_) => {
                *out_score = f64::NEG_INFINITY;
                *status = -999;
            }
        }
    }
}

#[no_mangle]
#[cfg(any())]
pub extern "C" fn kdml_mcmc_run(
    n_ptr: *const i32,
    p_ptr: *const i32,
    k_ptr: *const i32,
    data_ptr: *const f64,
    type_ptr: *const i32,
    distance_ptr: *const i32,
    kernel_ptr: *const i32,
    ukernel_ptr: *const i32,
    okernel_ptr: *const i32,
    init_theta_ptr: *const f64,
    pseudo_mu_ptr: *const f64,
    pseudo_sd_ptr: *const f64,
    n_iter_ptr: *const i32,
    beta_ptr: *const f64,
    proposal_sd_ptr: *const f64,
    active_init_ptr: *const i32,
    prior_mu_ptr: *const f64,
    prior_sd_ptr: *const f64,
    seed_ptr: *const i32,
    samples_model_ptr: *mut i32,
    samples_theta_ptr: *mut f64,
    samples_bw_ptr: *mut f64,
    samples_score_ptr: *mut f64,
    samples_log_post_ptr: *mut f64,
    accepted_ptr: *mut i32,
    mh_model_ptr: *mut i32,
    acceptance_rate_ptr: *mut f64,
    status: *mut i32,
) {
    let result = panic::catch_unwind(|| unsafe {
        let n = *n_ptr as usize;
        let p = *p_ptr as usize;
        let k_count = *k_ptr as usize;
        let n_iter = *n_iter_ptr as usize;
        let data_values = slice::from_raw_parts(data_ptr, n * p);
        let type_codes = slice::from_raw_parts(type_ptr, p);
        let kernel_codes = slice::from_raw_parts(kernel_ptr, k_count);
        let ukernel_codes = slice::from_raw_parts(ukernel_ptr, k_count);
        let okernel_codes = slice::from_raw_parts(okernel_ptr, k_count);
        let init_theta = slice::from_raw_parts(init_theta_ptr, k_count * p);
        let pseudo_mu = slice::from_raw_parts(pseudo_mu_ptr, k_count * p);
        let pseudo_sd = slice::from_raw_parts(pseudo_sd_ptr, k_count * p);
        let samples_model = slice::from_raw_parts_mut(samples_model_ptr, n_iter);
        let samples_theta = slice::from_raw_parts_mut(samples_theta_ptr, n_iter * p);
        let samples_bw = slice::from_raw_parts_mut(samples_bw_ptr, n_iter * p);
        let samples_score = slice::from_raw_parts_mut(samples_score_ptr, n_iter);
        let samples_log_post = slice::from_raw_parts_mut(samples_log_post_ptr, n_iter);
        let accepted = slice::from_raw_parts_mut(accepted_ptr, n_iter);
        let mh_model = slice::from_raw_parts_mut(mh_model_ptr, n_iter);

        run_mcmc_impl(
            n,
            p,
            k_count,
            data_values,
            type_codes,
            *distance_ptr,
            kernel_codes,
            ukernel_codes,
            okernel_codes,
            init_theta,
            pseudo_mu,
            pseudo_sd,
            n_iter,
            *beta_ptr,
            *proposal_sd_ptr,
            *active_init_ptr as usize,
            *prior_mu_ptr,
            *prior_sd_ptr,
            (*seed_ptr as u32 as u64).max(1),
            None,
            samples_model,
            samples_theta,
            samples_bw,
            samples_score,
            samples_log_post,
            accepted,
            mh_model,
        )
    });

    unsafe {
        match result {
            Ok(Ok(rate)) => {
                *acceptance_rate_ptr = rate;
                *status = 0;
            }
            Ok(Err(code)) => {
                *acceptance_rate_ptr = f64::NAN;
                *status = code;
            }
            Err(_) => {
                *acceptance_rate_ptr = f64::NAN;
                *status = -999;
            }
        }
    }
}

#[no_mangle]
#[cfg(any())]
pub extern "C" fn kdml_mcmc_run_chains(
    n_ptr: *const i32,
    p_ptr: *const i32,
    k_ptr: *const i32,
    n_chains_ptr: *const i32,
    data_ptr: *const f64,
    type_ptr: *const i32,
    distance_ptr: *const i32,
    kernel_ptr: *const i32,
    ukernel_ptr: *const i32,
    okernel_ptr: *const i32,
    init_theta_ptr: *const f64,
    pseudo_mu_ptr: *const f64,
    pseudo_sd_ptr: *const f64,
    n_iter_ptr: *const i32,
    beta_ptr: *const f64,
    proposal_sd_ptr: *const f64,
    active_inits_ptr: *const i32,
    seeds_ptr: *const i32,
    prior_mu_ptr: *const f64,
    prior_sd_ptr: *const f64,
    n_cores_ptr: *const i32,
    samples_model_ptr: *mut i32,
    samples_theta_ptr: *mut f64,
    samples_bw_ptr: *mut f64,
    samples_score_ptr: *mut f64,
    samples_log_post_ptr: *mut f64,
    accepted_ptr: *mut i32,
    mh_model_ptr: *mut i32,
    acceptance_rate_ptr: *mut f64,
    status: *mut i32,
) {
    let result = panic::catch_unwind(|| unsafe {
        let n = *n_ptr as usize;
        let p = *p_ptr as usize;
        let k_count = *k_ptr as usize;
        let chain_count = *n_chains_ptr as usize;
        let n_iter = *n_iter_ptr as usize;
        let data_values = slice::from_raw_parts(data_ptr, n * p);
        let type_codes = slice::from_raw_parts(type_ptr, p);
        let kernel_codes = slice::from_raw_parts(kernel_ptr, k_count);
        let ukernel_codes = slice::from_raw_parts(ukernel_ptr, k_count);
        let okernel_codes = slice::from_raw_parts(okernel_ptr, k_count);
        let init_theta = slice::from_raw_parts(init_theta_ptr, k_count * p);
        let pseudo_mu = slice::from_raw_parts(pseudo_mu_ptr, k_count * p);
        let pseudo_sd = slice::from_raw_parts(pseudo_sd_ptr, k_count * p);
        let active_inits = slice::from_raw_parts(active_inits_ptr, chain_count);
        let seeds = slice::from_raw_parts(seeds_ptr, chain_count);
        let samples_model = slice::from_raw_parts_mut(samples_model_ptr, n_iter * chain_count);
        let samples_theta = slice::from_raw_parts_mut(samples_theta_ptr, n_iter * p * chain_count);
        let samples_bw = slice::from_raw_parts_mut(samples_bw_ptr, n_iter * p * chain_count);
        let samples_score = slice::from_raw_parts_mut(samples_score_ptr, n_iter * chain_count);
        let samples_log_post =
            slice::from_raw_parts_mut(samples_log_post_ptr, n_iter * chain_count);
        let accepted = slice::from_raw_parts_mut(accepted_ptr, n_iter * chain_count);
        let mh_model = slice::from_raw_parts_mut(mh_model_ptr, n_iter * chain_count);
        let acceptance_rate = slice::from_raw_parts_mut(acceptance_rate_ptr, chain_count);

        let outputs = run_chains_impl(
            n,
            p,
            k_count,
            chain_count,
            data_values,
            type_codes,
            *distance_ptr,
            kernel_codes,
            ukernel_codes,
            okernel_codes,
            init_theta,
            pseudo_mu,
            pseudo_sd,
            n_iter,
            *beta_ptr,
            *proposal_sd_ptr,
            active_inits,
            seeds,
            *prior_mu_ptr,
            *prior_sd_ptr,
            (*n_cores_ptr).max(1) as usize,
        )?;

        for (chain_id, output) in outputs.into_iter().enumerate() {
            let scalar_offset = chain_id * n_iter;
            let matrix_offset = chain_id * n_iter * p;

            samples_model[scalar_offset..scalar_offset + n_iter]
                .copy_from_slice(&output.samples_model);
            samples_score[scalar_offset..scalar_offset + n_iter]
                .copy_from_slice(&output.samples_score);
            samples_log_post[scalar_offset..scalar_offset + n_iter]
                .copy_from_slice(&output.samples_log_post);
            accepted[scalar_offset..scalar_offset + n_iter].copy_from_slice(&output.accepted);
            mh_model[scalar_offset..scalar_offset + n_iter].copy_from_slice(&output.mh_model);
            samples_theta[matrix_offset..matrix_offset + n_iter * p]
                .copy_from_slice(&output.samples_theta);
            samples_bw[matrix_offset..matrix_offset + n_iter * p]
                .copy_from_slice(&output.samples_bw);
            acceptance_rate[chain_id] = output.acceptance_rate;
        }

        Ok::<(), i32>(())
    });

    unsafe {
        *status = match result {
            Ok(Ok(())) => 0,
            Ok(Err(code)) => code,
            Err(_) => -999,
        };
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn estimation_uses_the_same_continuous_kernels_as_clustering() {
        for distance in [DistanceType::Dkps, DistanceType::Dkss] {
            for kernel in [
                ContinuousKernel::Gaussian,
                ContinuousKernel::Biweight,
                ContinuousKernel::Silverman,
            ] {
                let estimation =
                    continuous_kernel_mscv(0.25, 0.75, distance, kernel, ScoreVersion::Corrected);
                let clustering = continuous_kernel_distance(0.25, 0.75, distance, kernel);
                assert!((estimation - clustering).abs() < 1e-14);
            }
        }
    }

    #[test]
    fn package_aitchison_aitken_uses_number_of_levels_minus_one() {
        let binary = unordered_kernel_mscv(
            1.0,
            0.2,
            2,
            UnorderedKernel::AitchisonAitken,
            ScoreVersion::Corrected,
        );
        let four_level = unordered_kernel_mscv(
            1.0,
            0.3,
            4,
            UnorderedKernel::AitchisonAitken,
            ScoreVersion::Corrected,
        );
        assert!((binary - 0.2).abs() < 1e-12);
        assert!((four_level - 0.1).abs() < 1e-12);
    }

    #[test]
    fn package_biweight_and_dkss_silverman_formulas_are_preserved() {
        let z = 0.5_f64;
        let biweight =
            continuous_kernel_distance(z, 1.0, DistanceType::Dkss, ContinuousKernel::Biweight);
        let expected_biweight = (15.0 / 32.0) * (3.0 - z * z).powi(2);
        assert!((biweight - expected_biweight).abs() < 1e-14);

        let diff = 0.5_f64;
        let h = 2.0_f64;
        let a = (diff / h).abs();
        let silverman =
            continuous_kernel_distance(diff, h, DistanceType::Dkss, ContinuousKernel::Silverman);
        let expected_silverman = 0.5 / h * (-(a / SQRT_2)).exp() * (a / SQRT_2 + PI / 4.0).sin();
        assert!((silverman - expected_silverman).abs() < 1e-14);
    }

    #[test]
    fn transformed_bandwidths_do_not_have_the_old_floor_plateau() {
        let values = [0.0, 1.0];
        let types = [0];
        let data = KdmlData::new(2, 1, &values, &types).expect("valid data");
        let h28 = theta_to_bandwidth_column_kernels(&data, &[0], &[-28.0])
            .expect("theta -28 is supported")[0];
        let h29 = theta_to_bandwidth_column_kernels(&data, &[0], &[-29.0])
            .expect("theta -29 is supported")[0];
        assert!(h29 < h28);
        assert_ne!(h28, h29);
        let h31 = theta_to_bandwidth_column_kernels(&data, &[0], &[-31.0])
            .expect("finite theta is unconstrained")[0];
        assert!(h31 < h29);
        assert!(log_normal_sum(&[-29.0], 0.0, 4.0) < log_normal_sum(&[-28.0], 0.0, 4.0));
    }

    #[test]
    fn bandwidth_theta_round_trip_is_accurate_in_supported_domain() {
        let values = [0.0, 1.0, 1.0, 2.0, 1.0, 3.0];
        let types = [0, 1, 2];
        let data = KdmlData::new(2, 3, &values, &types).expect("valid mixed data");
        let theta = [-3.25, 1.5, -2.0];
        let bw =
            theta_to_bandwidth_column_kernels(&data, &[0, 1, 0], &theta).expect("supported theta");
        let recovered =
            bandwidth_to_theta_column_kernels(&data, &[0, 1, 0], &bw).expect("valid bandwidths");
        for (actual, expected) in recovered.iter().zip(theta) {
            assert!((actual - expected).abs() < 1e-10);
        }
    }

    #[test]
    fn bandwidth_domains_are_strictly_enforced() {
        // Column-major: one continuous, one unordered, and one ordered column.
        let values = [0.0, 1.0, 1.0, 2.0, 1.0, 3.0];
        let types = [0, 1, 2];
        let data = KdmlData::new(2, 3, &values, &types).expect("valid mixed data");

        assert!(data.valid_bandwidths(&[1.0, 0.25, 0.75], UnorderedKernel::Aitken));
        assert!(!data.valid_bandwidths(&[0.0, 0.25, 0.75], UnorderedKernel::Aitken));
        assert!(!data.valid_bandwidths(&[-1.0, 0.25, 0.75], UnorderedKernel::Aitken));
        assert!(!data.valid_bandwidths(&[1.0, 1.0, 0.75], UnorderedKernel::Aitken));
        assert!(!data.valid_bandwidths(&[1.0, 0.25, 1.0], UnorderedKernel::Aitken));

        // Categorical support is kernel-independent: both unordered kernels
        // accept the same bandwidths strictly between zero and one.
        assert!(data.valid_bandwidths(&[1.0, 0.5, 0.75], UnorderedKernel::AitchisonAitken));
        assert!(!data.valid_bandwidths(&[1.0, 1.0, 0.75], UnorderedKernel::AitchisonAitken));
    }

    #[cfg(kdml_cuda)]
    #[test]
    fn every_supported_theta_maps_to_the_required_bandwidth_domain() {
        let values = [0.0, 1.0, 1.0, 2.0, 1.0, 3.0];
        let types = [0, 1, 2];
        let data = KdmlData::new(2, 3, &values, &types).expect("valid mixed data");

        for theta_value in [-31.0, -10.0, 0.0, 10.0, 31.0] {
            let theta = [theta_value; 3];
            for unordered_code in [0, 1] {
                let bw = theta_to_bandwidth_column_kernels(&data, &[0, unordered_code, 0], &theta)
                    .expect("supported theta must produce valid bandwidths");
                assert!(bw[0].is_finite() && bw[0] > 0.0);
                assert!(bw[1].is_finite() && bw[1] > 0.0 && bw[1] < 1.0);
                assert!(bw[2].is_finite() && bw[2] > 0.0 && bw[2] < 1.0);
                assert!(valid_bandwidths_column_kernels(
                    &data,
                    &[0, unordered_code, 0],
                    &bw,
                ));
            }
        }
    }

    #[cfg(kdml_cuda)]
    #[test]
    fn categorical_transform_is_kernel_independent_logistic() {
        let values = [1.0, 2.0];
        let types = [1];
        let data = KdmlData::new(2, 1, &values, &types).expect("valid unordered data");
        for theta in [-10.0, 0.0, 10.0] {
            let aitken = theta_to_bandwidth_column_kernels(&data, &[0], &[theta])
                .expect("valid Aitken transform")[0];
            let aa = theta_to_bandwidth_column_kernels(&data, &[1], &[theta])
                .expect("valid Aitchison--Aitken transform")[0];
            assert!((aitken - sigmoid(theta)).abs() < 1e-14);
            assert!((aa - sigmoid(theta)).abs() < 1e-14);
            assert!((aitken - aa).abs() < 1e-14);
        }
    }

    #[test]
    fn continuous_theta_geometry_is_invariant_to_column_units() {
        let values_a = [0.0, 1.0, 2.0, 3.0];
        let values_b = [0.0, 1000.0, 2000.0, 3000.0];
        let types = [0];
        let data_a = KdmlData::new(4, 1, &values_a, &types).expect("valid data");
        let data_b = KdmlData::new(4, 1, &values_b, &types).expect("valid rescaled data");
        let score_difference = |data: &KdmlData<'_>| {
            let bw_left = theta_to_bandwidth(data, UnorderedKernel::Aitken, &[-0.5]);
            let bw_right = theta_to_bandwidth(data, UnorderedKernel::Aitken, &[0.5]);
            mscv_score_with_version(
                data,
                DistanceType::Dkps,
                ContinuousKernel::Gaussian,
                UnorderedKernel::Aitken,
                OrderedKernel::WangVanRyzin,
                &bw_right,
                ScoreVersion::Corrected,
            ) - mscv_score_with_version(
                data,
                DistanceType::Dkps,
                ContinuousKernel::Gaussian,
                UnorderedKernel::Aitken,
                OrderedKernel::WangVanRyzin,
                &bw_left,
                ScoreVersion::Corrected,
            )
        };
        assert!((score_difference(&data_a) - score_difference(&data_b)).abs() < 1e-10);
    }

    #[cfg(kdml_cuda)]
    #[test]
    fn adaptation_gain_does_not_saturate_after_a_short_acceptance_streak() {
        let mut log_scale = 0.15_f64.ln();
        let mut count = 0;
        for _ in 0..20 {
            adapt_log_scale(&mut log_scale, &mut count, true, 0.44);
        }
        let scale = log_scale.exp();
        assert!(scale > 0.15);
        assert!(
            scale < 0.5,
            "short warmup inflated proposal scale to {scale}"
        );
    }

    #[cfg(kdml_cuda)]
    #[test]
    fn invalid_candidate_state_is_counted_as_a_rejection() {
        let mut invalid = 0usize;
        let rejected = invalid_candidate_is_rejection::<usize>(Err(-12), &mut invalid)
            .expect("invalid state is not fatal");
        assert!(rejected.is_none());
        assert_eq!(invalid, 1);

        let hardware_error = invalid_candidate_is_rejection::<usize>(Err(-30), &mut invalid);
        assert_eq!(hardware_error, Err(-30));
        assert_eq!(invalid, 1);
    }

    #[cfg(kdml_cuda)]
    #[test]
    fn corrected_cuda_matches_cpu_for_categorical_only_data() {
        let values = [1.0, 2.0, 1.0];
        let types = [1];
        let data = KdmlData::new(3, 1, &values, &types).expect("valid categorical data");
        let bw = [0.2];
        let cuda =
            crate::cuda::CudaMscvScore::new_with_score_version(&data, ScoreVersion::Corrected)
                .expect("CUDA workspace");
        for (distance, distance_code) in [(DistanceType::Dkps, 0), (DistanceType::Dkss, 1)] {
            let cpu = mscv_score_with_version(
                &data,
                distance,
                ContinuousKernel::Gaussian,
                UnorderedKernel::Aitken,
                OrderedKernel::WangVanRyzin,
                &bw,
                ScoreVersion::Corrected,
            );
            let gpu = cuda
                .score_f32_with_column_kernels(&[0.2], distance_code, &[0], &[0], &[0])
                .expect("CUDA score") as f64;
            assert!(
                (cpu - gpu).abs() < 1e-5,
                "distance={distance:?} cpu={cpu}, gpu={gpu}"
            );
        }
    }

    #[cfg(kdml_cuda)]
    #[test]
    fn corrected_cuda_matches_cpu_for_mixed_kernel_combinations() {
        let values = [
            0.0, 1.0, 2.0, 3.0, // continuous
            1.0, 2.0, 3.0, 1.0, // unordered
            1.0, 2.0, 3.0, 4.0, // ordered
        ];
        let types = [0, 1, 2];
        let data = KdmlData::new(4, 3, &values, &types).expect("valid mixed data");
        let bw = [0.8, 0.2, 0.4];
        let bw_f32 = [0.8_f32, 0.2, 0.4];
        let cuda =
            crate::cuda::CudaMscvScore::new_with_score_version(&data, ScoreVersion::Corrected)
                .expect("CUDA workspace");
        for (distance, distance_code) in [(DistanceType::Dkps, 0), (DistanceType::Dkss, 1)] {
            for (continuous_code, continuous_kernel) in [
                (0, ContinuousKernel::Gaussian),
                (10, ContinuousKernel::Silverman),
            ] {
                for (unordered_code, unordered_kernel) in [
                    (0, UnorderedKernel::Aitken),
                    (1, UnorderedKernel::AitchisonAitken),
                ] {
                    let cpu = mscv_score_with_version(
                        &data,
                        distance,
                        continuous_kernel,
                        unordered_kernel,
                        OrderedKernel::WangVanRyzin,
                        &bw,
                        ScoreVersion::Corrected,
                    );
                    let gpu = cuda
                        .score_f32_with_column_kernels(
                            &bw_f32,
                            distance_code,
                            &[continuous_code, 0, 0],
                            &[0, unordered_code, 0],
                            &[0, 0, 0],
                        )
                        .expect("CUDA score") as f64;
                    assert!(
                        (cpu - gpu).abs() < 1e-4,
                        "distance={distance:?} codes=({continuous_code},{unordered_code}) cpu={cpu}, gpu={gpu}"
                    );
                }
            }
        }
    }
}
