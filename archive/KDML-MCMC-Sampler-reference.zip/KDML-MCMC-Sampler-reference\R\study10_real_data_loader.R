# Data loader for the ten real data sets described in the study benchmark.
# Used by scripts/run_study10_real_data_mcmc_kdml.R via --data-loader.
#
.study10_require <- function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    cran_repo <- getOption("repos")[["CRAN"]]
    if (is.null(cran_repo) || !nzchar(cran_repo) || identical(cran_repo, "@CRAN@")) {
      cran_repo <- "https://cloud.r-project.org"
    }
    message("Installing missing R package '", pkg, "' from ", cran_repo, "...")
    tryCatch(
      utils::install.packages(pkg, repos = cran_repo, dependencies = TRUE),
      error = function(e) stop("Could not install required package '", pkg, "': ",
                               conditionMessage(e), call. = FALSE)
    )
  }
  if (!requireNamespace(pkg, quietly = TRUE)) {
    stop("Package '", pkg, "' could not be loaded after installation.", call. = FALSE)
  }
}

.study10_factor <- function(x, ordered = FALSE, levels = NULL) {
  x <- trimws(as.character(x)); x[x %in% c("", "?", "NA")] <- NA_character_
  if (is.null(levels)) return(factor(x, ordered = ordered))
  factor(x, levels = levels, ordered = ordered)
}

.study10_numeric <- function(x) suppressWarnings(as.numeric(as.character(x)))

.study10_complete <- function(x, y) {
  keep <- stats::complete.cases(x) & !is.na(y)
  list(data = x[keep, , drop = FALSE], labels = y[keep])
}

.study10_continuous_dataset <- function(x, y, dataset, expected_names) {
  if (ncol(x) != length(expected_names)) {
    stop(dataset, " must contain exactly ", length(expected_names),
         " continuous predictor columns; found ", ncol(x), ".", call. = FALSE)
  }
  names(x) <- expected_names
  if (!all(vapply(x, is.numeric, logical(1)))) {
    stop(dataset, " predictors must all be numeric continuous measurements.", call. = FALSE)
  }
  out <- .study10_complete(x, .study10_factor(y))
  if (!nrow(out$data) || any(!is.finite(as.matrix(out$data)))) {
    stop(dataset, " contains no complete finite predictor rows after cleaning.", call. = FALSE)
  }
  out
}

.study10_uci <- function(id) {
  .study10_require("ucimlrepo")
  dat <- ucimlrepo::fetch_ucirepo(id = id)
  x <- as.data.frame(dat$data$features, stringsAsFactors = FALSE, check.names = FALSE)
  y <- dat$data$targets
  if (is.data.frame(y) || is.matrix(y)) y <- y[[1L]]
  list(x = x, y = y)
}

.study10_set_factor <- function(x, columns, ordered = FALSE) {
  for (j in columns) x[[j]] <- .study10_factor(x[[j]], ordered = ordered)
  x
}

.study10_body <- function() {
  .study10_require("gclus")
  data("body", package = "gclus", envir = environment())
  x <- as.data.frame(body, stringsAsFactors = FALSE, check.names = FALSE)
  label_col <- names(x)[tolower(names(x)) %in% c("sex", "gender")]
  if (length(label_col) != 1L) {
    stop("Could not identify the Body sex/gender label column in gclus::body.", call. = FALSE)
  }
  y <- .study10_factor(x[[label_col]])
  x[[label_col]] <- NULL
  # The study specifies 24 continuous measurements; retain numeric measurements only.
  x[] <- lapply(x, .study10_numeric)
  x <- x[vapply(x, function(z) all(is.finite(z) | is.na(z)), logical(1))]
  .study10_complete(x, y)
}

.study10_wine <- function() {
  z <- .study10_uci(109)
  x <- as.data.frame(lapply(z$x, .study10_numeric), check.names = FALSE)
  .study10_continuous_dataset(
    x, z$y, "Wine",
    c("Alcohol", "Malicacid", "Ash", "Alcalinity_of_ash", "Magnesium",
      "Total_phenols", "Flavanoids", "Nonflavanoid_phenols", "Proanthocyanins",
      "Color_intensity", "Hue", "X0D280_0D315_of_diluted_wines", "Proline")
  )
}

.study10_iris <- function() {
  z <- .study10_uci(53)
  x <- as.data.frame(lapply(z$x, .study10_numeric), check.names = FALSE)
  .study10_continuous_dataset(
    x, z$y, "Iris",
    c("sepal.length", "sepal.width", "petal.length", "petal.width")
  )
}

.study10_soybean <- function(id) {
  z <- .study10_uci(id); x <- .study10_set_factor(z$x, seq_len(ncol(z$x))); .study10_complete(x, .study10_factor(z$y))
}

.study10_breast <- function() {
  z <- .study10_uci(15); x <- z$x
  # UCI Original Breast Cancer: discard sample code number and retain nine ordinal scores.
  id_col <- grep("sample|id", names(x), ignore.case = TRUE, value = TRUE)
  if (length(id_col)) x[id_col] <- NULL
  x <- .study10_set_factor(x, seq_len(ncol(x)), ordered = TRUE)
  .study10_complete(x, .study10_factor(z$y))
}

.study10_vote <- function() {
  z <- .study10_uci(105); x <- .study10_set_factor(z$x, seq_len(ncol(z$x))); .study10_complete(x, .study10_factor(z$y))
}

.study10_zoo <- function() {
  z <- .study10_uci(111); x <- z$x
  name_col <- grep("animal.*name|name", names(x), ignore.case = TRUE, value = TRUE)
  if (length(name_col)) x[name_col] <- NULL
  # UCI marks legs as numeric; model it as ordered. Other retained attributes are unordered.
  legs <- grep("legs", names(x), ignore.case = TRUE, value = TRUE)
  x <- .study10_set_factor(x, setdiff(seq_len(ncol(x)), match(legs, names(x))))
  if (length(legs)) x[[legs[[1]]]] <- .study10_factor(x[[legs[[1]]]], ordered = TRUE)
  .study10_complete(x, .study10_factor(z$y))
}

.study10_credit <- function() {
  z <- .study10_uci(143); x <- z$x
  # Australian Credit Approval: A1,A4:A7,A9,A10,A12 are categorical; remaining six are continuous.
  categorical <- c(1L, 4L, 5L, 6L, 7L, 9L, 10L, 12L)
  x <- .study10_set_factor(x, categorical)
  for (j in setdiff(seq_len(ncol(x)), categorical)) x[[j]] <- .study10_numeric(x[[j]])
  .study10_complete(x, .study10_factor(z$y))
}

.study10_auto <- function() {
  z <- .study10_uci(9); x <- z$x
  mpg_col <- grep("mpg|miles.*gallon", names(x), ignore.case = TRUE, value = TRUE)
  # Depending on the ucimlrepo metadata version, MPG is supplied as either
  # the target column or one of the feature columns.
  mpg <- if (length(mpg_col) == 1L) x[[mpg_col]] else z$y
  if (is.null(mpg)) stop("Could not identify Auto MPG in UCI data.", call. = FALSE)
  y <- factor(ifelse(.study10_numeric(mpg) < 22, "MPG_lt_22", "MPG_ge_22"))
  if (length(mpg_col) == 1L) x[[mpg_col]] <- NULL
  name_col <- grep("car.*name|name", names(x), ignore.case = TRUE, value = TRUE)
  if (length(name_col)) x[name_col] <- NULL
  origin <- grep("origin", names(x), ignore.case = TRUE, value = TRUE)
  ordered_cols <- grep("cylinders|model.*year|year", names(x), ignore.case = TRUE, value = TRUE)
  continuous <- setdiff(names(x), c(origin, ordered_cols))
  for (j in continuous) x[[j]] <- .study10_numeric(x[[j]])
  if (length(origin)) x[[origin[[1]]]] <- .study10_factor(x[[origin[[1]]]])
  for (j in ordered_cols) x[[j]] <- .study10_factor(x[[j]], ordered = TRUE)
  .study10_complete(x, y)
}

load_datasets <- function() {
  all_loaders <- list(
    body = .study10_body, wine = .study10_wine, iris = .study10_iris,
    soybean_large = function() .study10_soybean(90), soybean_small = function() .study10_soybean(91),
    breast = .study10_breast, vote = .study10_vote, zoo = .study10_zoo,
    credit = .study10_credit, auto = .study10_auto
  )
  requested <- if (exists("requested_datasets", inherits = TRUE)) requested_datasets else "all"
  if (identical(requested, "all")) requested <- names(all_loaders)
  unknown <- setdiff(requested, names(all_loaders))
  if (length(unknown)) stop("Unknown study-10 dataset(s): ", paste(unknown, collapse = ", "), call. = FALSE)
  setNames(lapply(all_loaders[requested], function(f) f()), requested)
}
