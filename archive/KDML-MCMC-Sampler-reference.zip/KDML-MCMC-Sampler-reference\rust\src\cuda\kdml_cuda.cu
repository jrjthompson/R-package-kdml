#include <cuda_runtime.h>

#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <vector>

namespace {

constexpr float INV_SQRT_2PI_F = 0.3989423f;
constexpr float PI_F = 3.14159265358979323846f;
constexpr float SQRT_2_F = 1.4142135623730951f;

struct Workspace {
    size_t n = 0;
    size_t p = 0;
    size_t pair_count = 0;
    bool has_continuous = false;
    double* d_pair_diffs = nullptr;
    size_t* d_rows_a = nullptr;
    size_t* d_rows_b = nullptr;
    size_t* h_rows_a = nullptr;
    size_t* h_rows_b = nullptr;
    int* d_type_codes = nullptr;
    double* d_mins = nullptr;
    double* d_maxs = nullptr;
    float* d_bw32 = nullptr;
    int* d_ckernel_codes = nullptr;
    int* d_ukernel_codes = nullptr;
    int* d_okernel_codes = nullptr;
    float* d_pair_logs32 = nullptr;
    float* h_pair_logs32 = nullptr;
    int* d_pair_signs = nullptr;
    int* h_pair_signs = nullptr;
};

int status(cudaError_t err) {
    return err == cudaSuccess ? 0 : -static_cast<int>(err);
}

template <typename T>
int alloc_and_copy(T** dst, const T* src, size_t count) {
    cudaError_t err = cudaMalloc(reinterpret_cast<void**>(dst), count * sizeof(T));
    if (err != cudaSuccess) {
        return status(err);
    }
    err = cudaMemcpy(*dst, src, count * sizeof(T), cudaMemcpyHostToDevice);
    return status(err);
}

void free_workspace(Workspace* ws) {
    if (!ws) {
        return;
    }
    cudaFree(ws->d_pair_diffs);
    cudaFree(ws->d_rows_a);
    cudaFree(ws->d_rows_b);
    delete[] ws->h_rows_a;
    delete[] ws->h_rows_b;
    cudaFree(ws->d_type_codes);
    cudaFree(ws->d_mins);
    cudaFree(ws->d_maxs);
    cudaFree(ws->d_bw32);
    cudaFree(ws->d_ckernel_codes);
    cudaFree(ws->d_ukernel_codes);
    cudaFree(ws->d_okernel_codes);
    cudaFree(ws->d_pair_logs32);
    delete[] ws->h_pair_logs32;
    cudaFree(ws->d_pair_signs);
    delete[] ws->h_pair_signs;
    delete ws;
}

__device__ float continuous_kernel_mscv_f32(
    float diff,
    float lambda,
    int distance_code,
    int kernel_code,
    int score_version);
__device__ float continuous_kernel_log_mscv_f32(
    float diff,
    float lambda,
    int kernel_code,
    int score_version);
__device__ float unordered_kernel_mscv_f32(
    float diff,
    float lambda,
    float max_diff,
    int kernel_code,
    int score_version);
__device__ float ordered_kernel_mscv_f32(
    float diff,
    float lambda,
    float max_diff,
    int kernel_code);
__device__ float logaddexp_f32(float a, float b);

__global__ void mscv_score_kernel_f32(
    size_t pair_count,
    size_t p,
    int distance_code,
    int score_version,
    bool has_continuous,
    const int* __restrict__ ckernel_codes,
    const int* __restrict__ ukernel_codes,
    const int* __restrict__ okernel_codes,
    const double* __restrict__ pair_diffs,
    const size_t* __restrict__ rows_a,
    const size_t* __restrict__ rows_b,
    const int* __restrict__ type_codes,
    const double* __restrict__ mins,
    const double* __restrict__ maxs,
    const float* __restrict__ bw,
    float* __restrict__ pair_logs,
    int* __restrict__ pair_signs) {
    size_t pair_idx = static_cast<size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (pair_idx >= pair_count) {
        return;
    }

    // The exported kdml::dkps() and kdml::dkss() distances both add
    // featurewise kernel contributions. Their difference is in the
    // continuous-kernel normalization, not in product-versus-sum
    // composition. Use the same additive similarity here so estimation and
    // clustering evaluate exactly the same kernels.
    float pair_similarity = 0.0f;
    bool dkss_all_ordered_same = distance_code == 1;
    size_t first_dkss_wang = p;
    if (dkss_all_ordered_same) {
        for (size_t col = 0; col < p; ++col) {
            if (type_codes[col] == 2 && okernel_codes[col] == 0 && first_dkss_wang == p) {
                first_dkss_wang = col;
            }
            if (type_codes[col] == 2 && pair_diffs[pair_idx * p + col] != 0.0) {
                dkss_all_ordered_same = false;
            }
        }
    }

    for (size_t col = 0; col < p; ++col) {
        float diff = static_cast<float>(pair_diffs[pair_idx * p + col]);
        float lambda = bw[col];
        int type_code = type_codes[col];
        if (type_code == 0) {
            pair_similarity += continuous_kernel_mscv_f32(
                diff, lambda, distance_code, ckernel_codes[col], score_version);
        } else if (type_code == 1) {
            float max_diff = static_cast<float>(maxs[col] - mins[col]);
            pair_similarity += unordered_kernel_mscv_f32(
                diff,
                lambda,
                max_diff,
                ukernel_codes[col],
                score_version);
        } else {
            float max_diff = static_cast<float>(maxs[col] - mins[col]);
            if (distance_code == 1 && okernel_codes[col] == 0) {
                if (col == first_dkss_wang) {
                    pair_similarity += dkss_all_ordered_same
                                           ? 1.0f - lambda
                                           : 0.5f * (1.0f - lambda) *
                                                 powf(lambda, fabsf(diff));
                }
            } else {
                pair_similarity += ordered_kernel_mscv_f32(
                    diff, lambda, max_diff, okernel_codes[col]);
            }
        }
    }

    float log_value = -HUGE_VALF;
    int pair_sign = 0;
    if (pair_similarity != 0.0f && isfinite(pair_similarity)) {
        log_value = logf(fabsf(pair_similarity));
        pair_sign = pair_similarity > 0.0f ? 1 : -1;
    }
    pair_logs[pair_idx] = isfinite(log_value) ? log_value : -HUGE_VALF;
    pair_signs[pair_idx] = isfinite(log_value) ? pair_sign : 0;
}

__device__ float choose_float_f32(int n, int k) {
    if (k < 0 || k > n) {
        return 0.0f;
    }
    if (k > n - k) {
        k = n - k;
    }
    float out = 1.0f;
    for (int i = 1; i <= k; ++i) {
        out *= static_cast<float>(n - k + i) / static_cast<float>(i);
    }
    return out;
}

__device__ float continuous_kernel_mscv_f32(
    float diff,
    float lambda,
    int distance_code,
    int kernel_code,
    int score_version) {
    float z = diff / lambda;
    float az = fabsf(z);
    // kdml::dkps scales every continuous kernel by 1 / bandwidth.
    // kdml::dkss omits that scale except for its Silverman kernel.
    float scale = (distance_code == 0 || kernel_code == 10)
                      ? 1.0f / lambda
                      : 1.0f;

    switch (kernel_code) {
        case 0:
            return scale * INV_SQRT_2PI_F * expf(-0.5f * z * z);
        case 1:
            return az <= 1.0f ? scale * 0.75f * (1.0f - z * z) : 0.0f;
        case 2:
            return az <= 1.0f ? scale * 0.5f : 0.0f;
        case 3:
            return az <= 1.0f ? scale * (1.0f - az) : 0.0f;
        case 4:
            return az <= 1.0f ? scale * (15.0f / 32.0f) * powf(3.0f - z * z, 2.0f) : 0.0f;
        case 5:
            return az <= 1.0f ? scale * (35.0f / 32.0f) * powf(1.0f - z * z, 3.0f) : 0.0f;
        case 6:
            return az <= 1.0f
                       ? scale * (70.0f / 81.0f) * powf(1.0f - powf(az, 3.0f), 3.0f)
                       : 0.0f;
        case 7:
            return az <= 1.0f ? scale * (PI_F / 4.0f) * cosf((PI_F / 2.0f) * z) : 0.0f;
        case 8:
            return scale / (expf(z) + 2.0f + expf(-z));
        case 9:
            return scale * 2.0f / (PI_F * (expf(z) + expf(-z)));
        case 10: {
            float ad = az;
            return scale * 0.5f * expf(-(ad / SQRT_2_F)) * sinf(ad / SQRT_2_F + PI_F / 4.0f);
        }
        default:
            return NAN;
    }
}

__device__ float continuous_kernel_log_mscv_f32(
    float diff,
    float lambda,
    int kernel_code,
    int score_version) {
    float safe_lambda = fmaxf(lambda, 1.0e-12f);
    float z = diff / safe_lambda;
    float az = fabsf(z);
    float log_scale = -logf(safe_lambda);

    switch (kernel_code) {
        case 0:
            return log_scale + logf(INV_SQRT_2PI_F) - 0.5f * z * z;
        case 1:
            return az < 1.0f ? log_scale + logf(0.75f) + log1pf(-(z * z)) : -HUGE_VALF;
        case 2:
            return az <= 1.0f ? log_scale + logf(0.5f) : -HUGE_VALF;
        case 3:
            return az < 1.0f ? log_scale + log1pf(-az) : -HUGE_VALF;
        case 4:
            return az < 1.0f
                       ? log_scale + logf(15.0f / 16.0f) + 2.0f * log1pf(-(z * z))
                       : -HUGE_VALF;
        case 5:
            return az < 1.0f
                       ? log_scale + logf(35.0f / 32.0f) + 3.0f * log1pf(-(z * z))
                       : -HUGE_VALF;
        case 6:
            return az < 1.0f
                       ? log_scale + logf(70.0f / 81.0f) +
                             3.0f * log1pf(-powf(az, 3.0f))
                       : -HUGE_VALF;
        case 7: {
            if (az >= 1.0f) {
                return -HUGE_VALF;
            }
            float value = cosf((PI_F / 2.0f) * z);
            return value > 0.0f ? log_scale + logf(PI_F / 4.0f) + logf(value) : -HUGE_VALF;
        }
        case 8: {
            float m = fmaxf(fmaxf(z, -z), 0.0f);
            float log_denom = m + logf(expf(z - m) + 2.0f * expf(-m) + expf(-z - m));
            return log_scale - log_denom;
        }
        case 9: {
            float m = fmaxf(z, -z);
            float log_denom = m + logf(expf(z - m) + expf(-z - m));
            return log_scale + logf(2.0f / PI_F) - log_denom;
        }
        case 10: {
            float ad = score_version == 0 ? fabsf(diff) : az;
            float sine = sinf(ad / SQRT_2_F + PI_F / 4.0f);
            return sine > 0.0f
                       ? log_scale + logf(0.5f) - (ad / SQRT_2_F) + logf(sine)
                       : -HUGE_VALF;
        }
        default:
            return NAN;
    }
}

__device__ float unordered_kernel_mscv_f32(
    float diff,
    float lambda,
    float max_diff,
    int kernel_code,
    int score_version) {
    switch (kernel_code) {
        case 0:
            return diff == 0.0f ? 1.0f : lambda;
        case 1:
            if (diff == 0.0f) {
                return 1.0f - lambda;
            } else {
                float denominator = max_diff;
                return denominator > 0.0f ? lambda / denominator : NAN;
            }
        default:
            return NAN;
    }
}

__device__ float ordered_kernel_mscv_f32(
    float diff,
    float lambda,
    float max_diff,
    int kernel_code) {
    float ad = fabsf(diff);
    switch (kernel_code) {
        case 0:
            return diff == 0.0f ? 1.0f - lambda : 0.5f * (1.0f - lambda) * powf(lambda, ad);
        case 1:
            return powf(lambda, ad * ad);
        case 2:
            return diff == 0.0f ? lambda : (1.0f - lambda) / powf(2.0f, ad);
        case 3: {
            int n = static_cast<int>(roundf(fmaxf(max_diff, 0.0f)));
            int k = static_cast<int>(roundf(ad));
            return choose_float_f32(n, k) * powf(lambda, ad) * powf(1.0f - lambda, max_diff - ad);
        }
        case 4:
            return diff == 0.0f ? 1.0f : powf(lambda, ad);
        default:
            return NAN;
    }
}

__device__ float logaddexp_f32(float a, float b) {
    if (!isfinite(a)) {
        return b;
    }
    if (!isfinite(b)) {
        return a;
    }
    float m = fmaxf(a, b);
    return m + logf(expf(a - m) + expf(b - m));
}

}  // namespace

extern "C" int kdml_cuda_workspace_create(
    size_t n,
    size_t p,
    size_t pair_count,
    const double* pair_diffs,
    const size_t* rows_a,
    const size_t* rows_b,
    const int* type_codes,
    const double* mins,
    const double* maxs,
    Workspace** out_workspace) {
    if (!out_workspace || n < 2 || p == 0 || pair_count == 0) {
        return -10000;
    }
    *out_workspace = nullptr;

    int device_count = 0;
    cudaError_t err = cudaGetDeviceCount(&device_count);
    if (err != cudaSuccess || device_count <= 0) {
        return status(err == cudaSuccess ? cudaErrorNoDevice : err);
    }

    Workspace* ws = new (std::nothrow) Workspace();
    if (!ws) {
        return -10001;
    }
    ws->n = n;
    ws->p = p;
    ws->pair_count = pair_count;
    for (size_t col = 0; col < p; ++col) {
        if (type_codes[col] == 0) {
            ws->has_continuous = true;
            break;
        }
    }

    int rc = alloc_and_copy(&ws->d_pair_diffs, pair_diffs, pair_count * p);
    if (rc != 0) {
        free_workspace(ws);
        return rc;
    }
    rc = alloc_and_copy(&ws->d_rows_a, rows_a, pair_count);
    if (rc != 0) {
        free_workspace(ws);
        return rc;
    }
    ws->h_rows_a = new (std::nothrow) size_t[pair_count];
    if (!ws->h_rows_a) {
        free_workspace(ws);
        return -10001;
    }
    for (size_t idx = 0; idx < pair_count; ++idx) {
        ws->h_rows_a[idx] = rows_a[idx];
    }
    rc = alloc_and_copy(&ws->d_rows_b, rows_b, pair_count);
    if (rc != 0) {
        free_workspace(ws);
        return rc;
    }
    ws->h_rows_b = new (std::nothrow) size_t[pair_count];
    if (!ws->h_rows_b) {
        free_workspace(ws);
        return -10001;
    }
    for (size_t idx = 0; idx < pair_count; ++idx) {
        ws->h_rows_b[idx] = rows_b[idx];
    }
    rc = alloc_and_copy(&ws->d_type_codes, type_codes, p);
    if (rc != 0) {
        free_workspace(ws);
        return rc;
    }
    rc = alloc_and_copy(&ws->d_mins, mins, p);
    if (rc != 0) {
        free_workspace(ws);
        return rc;
    }
    rc = alloc_and_copy(&ws->d_maxs, maxs, p);
    if (rc != 0) {
        free_workspace(ws);
        return rc;
    }

    err = cudaMalloc(reinterpret_cast<void**>(&ws->d_bw32), p * sizeof(float));
    if (err != cudaSuccess) {
        free_workspace(ws);
        return status(err);
    }
    err = cudaMalloc(reinterpret_cast<void**>(&ws->d_ckernel_codes), p * sizeof(int));
    if (err != cudaSuccess) {
        free_workspace(ws);
        return status(err);
    }
    err = cudaMalloc(reinterpret_cast<void**>(&ws->d_ukernel_codes), p * sizeof(int));
    if (err != cudaSuccess) {
        free_workspace(ws);
        return status(err);
    }
    err = cudaMalloc(reinterpret_cast<void**>(&ws->d_okernel_codes), p * sizeof(int));
    if (err != cudaSuccess) {
        free_workspace(ws);
        return status(err);
    }
    err = cudaMalloc(reinterpret_cast<void**>(&ws->d_pair_logs32), pair_count * sizeof(float));
    if (err != cudaSuccess) {
        free_workspace(ws);
        return status(err);
    }

    ws->h_pair_logs32 = new (std::nothrow) float[pair_count];
    if (!ws->h_pair_logs32) {
        free_workspace(ws);
        return -10001;
    }
    err = cudaMalloc(reinterpret_cast<void**>(&ws->d_pair_signs), pair_count * sizeof(int));
    if (err != cudaSuccess) {
        free_workspace(ws);
        return status(err);
    }
    ws->h_pair_signs = new (std::nothrow) int[pair_count];
    if (!ws->h_pair_signs) {
        free_workspace(ws);
        return -10001;
    }

    *out_workspace = ws;
    return 0;
}

extern "C" void kdml_cuda_workspace_destroy(Workspace* ws) {
    free_workspace(ws);
}

extern "C" int kdml_cuda_mscv_score_f32_with_kernels(
    Workspace* ws,
    const float* bw,
    int distance_code,
    int ckernel_code,
    int ukernel_code,
    int okernel_code,
    int score_version,
    float* out_score);

extern "C" int kdml_cuda_mscv_score_f32_with_column_kernels(
    Workspace* ws,
    const float* bw,
    int distance_code,
    const int* ckernel_codes,
    const int* ukernel_codes,
    const int* okernel_codes,
    int score_version,
    float* out_score);

extern "C" int kdml_cuda_mscv_score_f32(
    Workspace* ws,
    const float* bw,
    int score_version,
    float* out_score) {
    return kdml_cuda_mscv_score_f32_with_kernels(
        ws, bw, 0, 0, 0, 4, score_version, out_score);
}

extern "C" int kdml_cuda_mscv_score_f32_with_kernels(
    Workspace* ws,
    const float* bw,
    int distance_code,
    int ckernel_code,
    int ukernel_code,
    int okernel_code,
    int score_version,
    float* out_score) {
    if (!ws) {
        return -10000;
    }
    std::vector<int> ckernel_codes(ws->p, ckernel_code);
    std::vector<int> ukernel_codes(ws->p, ukernel_code);
    std::vector<int> okernel_codes(ws->p, okernel_code);
    return kdml_cuda_mscv_score_f32_with_column_kernels(
        ws,
        bw,
        distance_code,
        ckernel_codes.data(),
        ukernel_codes.data(),
        okernel_codes.data(),
        score_version,
        out_score);
}

extern "C" int kdml_cuda_mscv_score_f32_with_column_kernels(
    Workspace* ws,
    const float* bw,
    int distance_code,
    const int* ckernel_codes,
    const int* ukernel_codes,
    const int* okernel_codes,
    int score_version,
    float* out_score) {
    if (!ws || !bw || !ckernel_codes || !ukernel_codes || !okernel_codes || !out_score) {
        return -10000;
    }

    cudaError_t err = cudaMemcpy(ws->d_bw32, bw, ws->p * sizeof(float), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        return status(err);
    }
    err = cudaMemcpy(
        ws->d_ckernel_codes,
        ckernel_codes,
        ws->p * sizeof(int),
        cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        return status(err);
    }
    err = cudaMemcpy(
        ws->d_ukernel_codes,
        ukernel_codes,
        ws->p * sizeof(int),
        cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        return status(err);
    }
    err = cudaMemcpy(
        ws->d_okernel_codes,
        okernel_codes,
        ws->p * sizeof(int),
        cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        return status(err);
    }
    int block_size = 256;
    int grid_size = static_cast<int>((ws->pair_count + block_size - 1) / block_size);
    mscv_score_kernel_f32<<<grid_size, block_size>>>(
        ws->pair_count,
        ws->p,
        distance_code,
        score_version,
        ws->has_continuous,
        ws->d_ckernel_codes,
        ws->d_ukernel_codes,
        ws->d_okernel_codes,
        ws->d_pair_diffs,
        ws->d_rows_a,
        ws->d_rows_b,
        ws->d_type_codes,
        ws->d_mins,
        ws->d_maxs,
        ws->d_bw32,
        ws->d_pair_logs32,
        ws->d_pair_signs);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        return status(err);
    }
    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        return status(err);
    }
    err = cudaMemcpy(
        ws->h_pair_logs32,
        ws->d_pair_logs32,
        ws->pair_count * sizeof(float),
        cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        return status(err);
    }
    err = cudaMemcpy(
        ws->h_pair_signs,
        ws->d_pair_signs,
        ws->pair_count * sizeof(int),
        cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        return status(err);
    }

    std::vector<double> row_positive_log_sums(ws->n, -HUGE_VAL);
    std::vector<double> row_negative_log_sums(ws->n, -HUGE_VAL);
    for (size_t pair_idx = 0; pair_idx < ws->pair_count; ++pair_idx) {
        float pair_log = ws->h_pair_logs32[pair_idx];
        int pair_sign = ws->h_pair_signs[pair_idx];
        if (!isfinite(pair_log) || pair_sign == 0) {
            continue;
        }
        double value = static_cast<double>(pair_log);
        size_t row_a = ws->h_rows_a[pair_idx];
        size_t row_b = ws->h_rows_b[pair_idx];
        for (size_t row : {row_a, row_b}) {
            double& current = pair_sign > 0 ? row_positive_log_sums[row] : row_negative_log_sums[row];
            if (!isfinite(current)) {
                current = value;
            } else {
                double m = current > value ? current : value;
                current = m + log(exp(current - m) + exp(value - m));
            }
        }
    }

    double log_n_minus_1 = log(static_cast<double>(ws->n - 1));
    double total = 0.0;
    for (size_t row = 0; row < ws->n; ++row) {
        double positive = row_positive_log_sums[row];
        double negative = row_negative_log_sums[row];
        if (!isfinite(positive) || (isfinite(negative) && negative >= positive)) {
            *out_score = -HUGE_VALF;
            return 0;
        }
        double value = isfinite(negative)
                           ? positive + log1p(-exp(negative - positive))
                           : positive;
        total += value - log_n_minus_1;
    }
    *out_score = static_cast<float>(total / static_cast<double>(ws->n));
    return 0;
}
